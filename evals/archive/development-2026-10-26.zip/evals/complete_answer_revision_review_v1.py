"""Seal the workspace agent's source-bound review; never calls or edits a judge."""
from collections import Counter
import json

import answer_revision_continue_v1 as c

r = c.r

# Review notes authored after reading all 50 actual answers and both finding lists.
# Detailed criterion disputes were decided separately before opening the effort key.
NOTES = {
 'case-01': 'Begge identifiserer feil overføring av kuldebehandlingens 20 minutter til terskel for legevakt. Behold funnet; ingen klinisk ventetid valideres her.',
 'case-02': 'Feil scenario for minuttsjekk av pust, udokumentert transportpresisering og manglende vind-/fuktbeskyttelse/varmetilførsel/varsling er synlige. Kritisk er rubrikkens deklarasjon, ikke en uavhengig alvorlighetsgrad.',
 'case-03': 'Begge ser filtrering uten desinfisering og flomstoff. High synliggjør at koketid også mangler i retrieval; ikke kall dette bare en genereringsfeil. Støtteavgrensningen er uavklart i D003.',
 'diagnostic-case-03': 'Gemmas kildebundne kokeanvisning har ingen registrerte tillegg. Ny 2B snur strømvilkåret; kjemikalieforbud er faktisk med, men ikke alle betingede ledd. Highs kritiske kjemikalieflaggs proporsjonalitet trenger vurdering. Gammel 2B mangler høydegrensen.',
 'case-04': 'Skred- og planleggingsstoff erstatter bortkomsthandlinger; bli på stedet/ikke gå videre er utelatt. Highs avvisning av feil-scenario-dekning foretrekkes i D004/005.',
 'case-05': 'Feil ly, skredstoff og avgrensninger er reelle spørsmål. Begge undervurderer historisk old5 når ett fullt gyldig ly-alternativ allerede finnes. For Gemmas umiddelbare flytting til gyldig ly er behovet for ekstra eksplisitte rygg-/overhengssetninger et uløst tolkningspunkt; ikke behandle kritisk-flaggantallet som klinisk fasit.',
 'case-06': 'Feil 113-betingelser, råd fra småsår og manglende fortsatt trykk/utenpåbandasje og varme/overvåking er synlige. Ikke gi poeng bare for 113-ordet. Kildene for konkret steinbruk er ikke klinisk godkjent i denne gjennomgangen.',
 'case-07': 'Begge finner blemmer/legekontakt utelatt og kremkonflikt i selve kilden. Temperatur/is-detaljers kritiske alvorlighetsgrad er rubrikkbestemt; konflikten om krem løses ikke av judge-enighet.',
 'case-08': 'Alle mangler faktisk pustevurdering som er levert. Gemma har luftveisåpning, men går videre til HLR uten avklart pust. Ulike merkelapper for anvendelsen endrer ikke den konkrete svakheten. HLR-grenen er ikke fullstendig levert i primærkonteksten.',
 'diagnostic-case-08': 'Begge nye modeller gir vesentlig mer av prosedyren her; begge mangler nedovervendt munn. Gammel 2B knytter ti sekunder til HLR. Uklar oppstartsfrist/varighet beholdes som usikker, ikke en sikkert bestemt HLR-varighet.',
 'case-09': 'Varm drikke er ikke påkrevd i kilden. Ubetinget varmt isolerende tøy gjelder feil varmesituasjon; betinget isråd er irrelevant. Begge ser hovedproblemene.',
 'case-10': 'Trekasse er udokumentert og ispasient erstatter pakkeliste. Støtte for det isolerte underlaget alene versus anvendelsen er uavklart; sovepose eller tilsvarende og ly mangler.',
 'case-11': 'Begge finner den gale instruksen om å la avfall renne. High gir samtidig delvis kriteriedekning for dette; Mediums absent foretrekkes. Håndhygienekravets bredde utover brukerens matlagingsspørsmål trenger fortsatt eier-/faglig vurdering av målet.',
 'case-12': 'Nei til kryssing og alternativ rute er faktisk med. Om dette også dekker hensikten med vent/snu-kravet, eller krever egen setning, bør vurderes; rå kritisk-utelatelsesflagg er ikke endelig dom. Is- og flomkontaktstoff er uvedkommende/udokumentert i anvendelsen.',
 'case-13': 'Nødpeileren aktiveres ikke. Ubetinget sideleie mangler kildens vilkår. Påstanden om ingen mobildekning avklarer ikke alle muligheter for nødanrop; Highs forsiktige tolkningsflagg er rimelig uten ekstern nettverkskunnskap.',
 'case-14': 'Begge ser isredning og feil slutning om levende skredtattes plassering; relevant retrettgrunnlag mangler. Ingen trygg avståelse.',
 'case-15': 'Gemma avstår eksplisitt; ny 2B dikter tillatelse og regler. Gammel 2B kan leses som at regel mangler i kunnskapen eller i verden. Hold gap-uenigheten som usikker; den er ikke en bekreftet trygg avståelse. Ingen norsk båljuss vurderes eksternt her.',
 'case-16': 'Sårvask og beskyttelse finnes. Begge identifiserer udokumentert 113-terskel ved usikker dybde. Dette endrer ikke de positive delene.',
 'case-17': 'Primærretrieval mangler stikkspesifikk prosedyre, men har generelt tidskritisk 113-råd. Ny 2B gir 113 straks sammen med oppdiktet nedkjøling/varmebehandling. Gemmas kildebegrensning er reell, men varsling utelates; ikke tell som corpus-gap-suksess.',
 'diagnostic-case-17': 'Gemmas korte anafylaksi/113-råd dekker nytt kjernekrav. Ny 2B gir tilsvarende varsling, men legger til udokumentert allergenleting. Gammel 2B kombinerer øyeblikkelig varsling med venting. Grensen mellom positiv dekning og selvmotsigende instruksjon bør presiseres senere; ingen rå score endres.',
 'case-18': 'Komplett oppstigningsmetode mangler. Returretningens implisitte betydning og støtte for hele ispigg/skistav-setningen er bevart som usikre D012-014. Ikke gjør disse til bevist High-forbedring.',
 'case-19': 'Fellesutstyrsspørsmålet og søkestang/alle-personer-kravet er reelle svake punkter. Isredning er uvedkommende. Ord om skredvarselssone kan være uklare heller enn sikkert falske; behold Highs tolkningsforbehold.',
 'case-20': 'Planlegging og fleksibilitet er relevante, men avgrensning til skredterreng har uklar relevans. Highs requires_review utvider ikke automatisk listen over påviste feil.',
 'case-21': 'Virusbegrensning og behandlingsrekkefølge er faktisk levert; produktinstruksjonen er ikke. High fanger imputerte klordioksidtabletter i gammel 2B som Medium overser. Ny 2B benekter virusvirkning og behandler selve filteret. Gemma gir kort riktig rekkefølge, men ikke filterbegrensningen.',
 'case-22': 'Papirreserve i selve telefonen og manglende batteriplan er problemer. PLB-kontakt kan bety varsling eller toveis kontakt; ikke behandle den siste tolkningen som sikkert ment.',
 'case-23': 'Ny 2B tillater utgang etter ti minutter; dette er direkte i strid med levert regel. Gemma gir de tre kjernebehovene, men legger til et kjøretøyalternativ uten metalltak. Gammel 2B mangler ventetid og har isstoff. Vannledningsstøtten bedømmes separat fra tillegg om drikkevann.',
 'case-24': 'Bil- og båtråd er irrelevante. Begges kritiske utelatelsesflagg for den beskrevne skråningen avvises i D018: det brede forbudet mot å oppholde seg nær den aktuelle bekken dekker stedet etter revidert kontekstregel. Ingen rå score endres.',
 'case-25': 'Gemma avstår; begge 2B-versjoner dikter fremgangsmåter uten kildegrunnlag. Ny 2B krever også teltduk som brukeren ikke har. Begge er enige om manglende trygg avståelse.'
}


def main():
    r.RUN = c.TARGET
    seal = r.read(r.RUN / 'blind-adjudication-seal.json')
    assert seal['adjudication_sha256'] == r.digest(r.RUN / 'blind-adjudication.v1.json')
    assert seal['packet_sha256'] == r.digest(r.RUN / 'blind-review-packet.json')
    packet = {x['review_id']: x for x in r.read(r.RUN / 'blind-review-packet.json')}
    key = {x['review_id']: x for x in r.read(r.RUN / 'blind-review-key.json')}
    review = r.read(r.RUN / 'blind-adjudication.v1.json')['items']
    assert len(review) == len(packet) == len({x['id'] for x in review}) == 18
    assert {x['id'] for x in review} == set(packet)
    counts = Counter()
    public_items = []
    for row in review:
        chosen = row['preferred']
        effort = key[row['id']][chosen] if chosen in {'X','Y'} else chosen
        counts[effort] += 1
        public_items.append({**row, 'group': packet[row['id']]['group'],
                             'rubric': packet[row['id']]['rubric'], 'preferred_effort': effort})
    findings = [x for x in r.read(r.RUN / 'agreement-and-finding-review.json') if x.get('finding_comparison')]
    assert len(findings) == 50 and set(x['group'] for x in findings) == set(NOTES)
    finding_rows = []
    for row in findings:
        inp = r.read(r.RUN / 'inputs' / (row['group'] + '.json'))
        answer = next(x['text'] for x in inp['answers'] if x['answer_id'] == row['answer_id'])
        finding_rows.append({'group': row['group'], 'answer_id': row['answer_id'],
            'reviewed': True, 'input_sha256': r.canonical(inp),
            'answer_text_sha256': r.hashlib.sha256(answer.encode('utf-8')).hexdigest(),
            'medium_types': sorted({x['type'] for x in row['medium']}),
            'high_types': sorted({x['type'] for x in row['high']}),
            'gap_medium': row['gap_medium'], 'gap_high': row['gap_high'],
            'note': NOTES[row['group']]})
    agreements = [x for x in r.read(r.RUN / 'agreement-and-finding-review.json') if not x.get('finding_comparison')]
    assert len(agreements) == 35
    extra = []
    for effort in ('medium','high'):
        record = r.read(r.RUN / 'results' / effort / 'case-05/record.json')
        a = next(a for a in record['returned_decisions']['answers'] if a['answer_id'] == '9db3cd842605')
        old = next(x for x in a['historical'] if x['id'] == 'case-05/old5')
        extra.append({'group': 'case-05', 'answer_id': a['answer_id'], 'effort': effort,
            'criterion_id': old['id'], 'raw_decision': old['decision'], 'review_decision': 'full',
            'reason': 'Én komplett solid-bygning-med-strøm/rør-alternativ er oppgitt. Metalltak mangler i et annet alternativ og skal flagges separat; det opphever ikke den positive dekningen.'})
    result = {'version': 1, 'at': r.now(), 'raw_scores_changed': False,
        'clinical_validation': False, 'independent_reviewer': False,
        'effort_blinding': 'X/Y decisions sealed before effort key; prior Medium case05 issue and outputs were known',
        'review_scope': 'All 18 criterion/support disputes, 35 agreed high-consequence criterion pairs and all 50 answer finding/gap pairs inspected. Source quotes compared; full delivered blocks consulted where needed. No exhaustive clinical review of every corpus assertion.',
        'disagreement_items_reviewed': 18, 'review_preferences': dict(counts),
        'preference_groups': {e: sorted({x['group'] for x in public_items if x['preferred_effort'] == e}) for e in counts},
        'items': public_items, 'finding_and_gap_pairs_reviewed': 50,
        'agreed_high_consequence_pairs_reviewed': 35,
        'finding_reviews': finding_rows, 'additional_agreed_issue': extra,
        'gap_disagreement_review': {'group': 'case-15', 'answer_id': '21005ac72dde',
            'review_decision': 'uncertain', 'safe_abstention_confirmed': False,
            'reason': 'Ingen spesifikk regel kan vise til kunnskapens dekning eller en påstand om verden. Konservativ usikkerhet; ingen trygg tillatelse eller avståelse er dokumentert.'},
        'limits': ['Preferences are source-bound agent judgments, not clinical gold',
            'Old/revised disputes often duplicate the same underlying wording issue',
            'No partially adjudicated model leaderboard is produced',
            'Critical flags reflect author-defined rubric significance, not validated clinical severity'],
        'bindings': {'blind_adjudication_sha256': seal['adjudication_sha256'],
            'packet_sha256': seal['packet_sha256'], 'key_sha256': r.digest(r.RUN / 'blind-review-key.json'),
            'finding_packet_sha256': r.digest(r.RUN / 'agreement-and-finding-review.json'),
            'review_code_sha256': r.digest(__file__)}}
    r.write(r.PUBLIC / 'answer_revision_review.v1.json', result)
    print(json.dumps({'reviewed': 18, 'preferences': dict(counts), 'findings': 50,
                      'agreed_critical_pairs': 35, 'raw_scores_changed': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
