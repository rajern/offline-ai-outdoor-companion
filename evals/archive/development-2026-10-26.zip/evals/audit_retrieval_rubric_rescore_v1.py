"""Independent offline audit and recomputation of the locked retrieval assessment."""
from collections import Counter
import json
import subprocess

import rescore_retrieval_locked_v1 as s

r = s.r


def audit():
    frozen = s.check_freeze()
    expected_controls = r.read(s.RUN/'control-expected.json')
    mapping = {x['context_id']:x for x in r.read(s.RUN/'case-map.json')}
    known = Counter()
    core = Counter()
    conditionals = Counter()
    pairs = []
    seals = {}
    source_by_case = {}
    for cid in frozen['controls'] + frozen['primary']:
        out = s.RUN/'results'/cid
        if not (out/'record.json').exists():
            continue
        record = r.read(out/'record.json')
        inp = r.read(s.RUN/'inputs'/(cid+'.json'))
        assert r.read(out/'input.json') == inp
        assert (out/'stdin.json').read_bytes() == json.dumps(inp,ensure_ascii=False).encode('utf-8')
        assert record['input_sha256'] == r.canonical(inp)
        assert record['raw_sha256'] == r.digest(out/'stdout.jsonl')
        assert record['requested']['model'] == s.MODEL
        assert record['requested']['reasoning_effort'] == s.EFFORT
        assert record['requested']['cli_sha256'] == frozen['preflight']['cli_sha256']
        assert record['requested']['prompt_sha256'] == r.digest(s.PROMPT)
        assert record['requested']['schema_sha256'] == r.digest(s.RUN/'schema.json')
        command = r.read(out/'command.json')['argv']
        assert command[command.index('--model')+1] == s.MODEL
        assert command[command.index('--sandbox')+1] == 'read-only'
        for flag in ('--ignore-user-config','--ignore-rules','--ephemeral',
                     'model_reasoning_effort="medium"','features.shell_tool=false',
                     'features.apps=false','forced_login_method="chatgpt"'):
            assert flag in command, flag
        if record['success']:
            assert not s.validate(record['returned_decisions'],inp)
            resources = r.read(out/'resources.json')
            assert resources['peak_rss_bytes'] <= 4*1024**3
            assert resources['minimum_available_bytes'] >= 256*1024**2
            if cid in expected_controls:
                assert not s.control_errors(record['returned_decisions'],expected_controls[cid])
            else:
                classes = {x['id']:x['classification'] for x in inp['criteria']}
                required = {x['id']:x['decision'] for x in record['returned_decisions']['items'] if classes[x['id']]=='required'}
                if inp['expected_result']=='supported_context':
                    core.update(required.values())
                    conditionals.update(x['decision'] for x in record['returned_decisions']['items'] if classes[x['id']]=='conditional')
                    source_by_case[mapping[cid]['case_id']] = required
        known.update(record.get('usage') or {})
        pairs.append({'context_id':cid,'success':record['success'],'errors':record['errors']})
        for p in out.iterdir():
            if p.is_file():
                seals[str(p.relative_to(s.ROOT))] = r.digest(p)
    # Recompute linkage directly from sealed private answer records, not public summary rows.
    answer_meta = {x['answer_id']:x for x in r.read(s.PARENT/'private-answer-map.json')}
    linkage = []
    for cid, sources in source_by_case.items():
        record = r.read(s.PARENT/'results/medium'/cid/'record.json')
        for answer in record['returned_decisions']['answers']:
            aid = answer['answer_id']
            assert not answer_meta[aid]['diagnostic']
            ad = {x['id']:x['decision'] for x in answer['revised']}
            available = sum(d=='full' for d in sources.values())
            preserved = sum(d=='full' and ad[i]=='full' for i,d in sources.items())
            extra = sum(ad[i]=='full' and d!='full' for i,d in sources.items())
            linkage.append({'case_id':cid,'answer_id':aid,'available':available,'preserved':preserved,
                            'answer_full_without_full_source':extra})
    snapshots = sorted(s.PUBLIC.glob('retrieval_rubric_rescore_results.v*.json'), key=lambda p:int(p.stem.split('.v')[-1]))
    assert snapshots, 'Summarize before audit'
    summary = r.read(snapshots[-1])
    assert summary['freeze_sha256'] == r.digest(s.RUN/'freeze.json')
    for decision in ('full','partial','absent','uncertain'):
        assert core[decision] == summary['core_counts'].get(decision,0)
        assert conditionals[decision] == summary['conditional_branch_availability'].get(decision,0)
    assert dict(known) == summary['known_usage']
    by_aid = {x['answer_id']:x for x in summary['paired_answer_retention']}
    assert len(linkage) == len(by_aid)
    for row in linkage:
        for field in ('available','preserved','answer_full_without_full_source'):
            assert row[field] == by_aid[row['answer_id']][field]
    current_tasks = (s.ROOT/'TASKS.md').read_text(encoding='utf-8')
    old_tasks = (s.RUN/'before/TASKS.md').read_text(encoding='utf-8')
    marker = '# Milestone 3 — Safety + Finished MVP'
    assert current_tasks[current_tasks.index(marker):] == old_tasks[old_tasks.index(marker):]
    active = [p.pid for p in r.psutil.process_iter(['name','cmdline'])
        if (p.info['name'] or '').lower()=='codex.exe' and 'exec' in (p.info['cmdline'] or [])]
    complete = (s.RUN/'complete.json').exists()
    if complete:
        assert len(pairs)==28 and all(x['success'] for x in pairs)
        assert sum(core.values())==63 and sum(conditionals.values())==4
        assert len(linkage)==34  # 22 historical supported + 6 each from the two screening models.
        assert not active
    result = {'at':r.now(),'complete':complete,'frozen_and_parent_checks_passed':True,
        'historical_artifacts_preserved':len(r.read(s.RUN/'preserved-parent-files.json')),
        'call_checks':pairs,'core_counts':dict(core),'conditional_counts':dict(conditionals),
        'quote_occurrence_and_schema_checks':True,'semantic_entailment_automatically_proven':False,
        'serialized_stdin_byte_match':True,'independent_summary_recomputation':True,
        'independent_per_criterion_linkage_checks':len(linkage),'M3_unchanged':True,
        'active_judge_processes':active,'new_search_calls':0,'new_product_answers':0,
        'paid_api_calls':0,'free_resets_consumed':0,'holdout_accessed':False,
        'requested_model':s.MODEL,'requested_effort':s.EFFORT,'actual_server_revision_verified':False,
        'known_usage':dict(known),'freeze_sha256':r.digest(s.RUN/'freeze.json'),
        'summary_sha256':r.digest(snapshots[-1]),'audit_code_sha256':r.digest(__file__)}
    n = 1
    while (s.PUBLIC/f'retrieval_rubric_rescore_audit.v{n}.json').exists():
        n += 1
    r.write(s.RUN/f'call-seals.v{n}.json',seals)
    r.write(s.PUBLIC/f'retrieval_rubric_rescore_audit.v{n}.json',result)
    print(json.dumps({'audit_version':n,'complete':complete,'calls':len(pairs),'core':dict(core),
        'conditional':dict(conditionals),'linked_answers':len(linkage),'preserved':result['historical_artifacts_preserved']}),flush=True)


if __name__ == '__main__':
    audit()
