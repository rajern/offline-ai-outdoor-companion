# Controlled continuation after429, 2026-10-25

Owner: "oja fortsett og se om du får fikset." Original failed21 has no completed
turn, final agent message or known usage; it cannot be recovered. Preserve all
five original attempts, frozen code, report v1 and partial closeout. Copy/reuse
four successful sealed answers byte-identically in continuation-v1. Same eight
inputs/system text, CLI, High generator and Medium judge/rubric. No model, prompt,
source, output transformation, seed setting, memory guard or timeout changes.

This explicit continuation permits one new CLI attempt for21, then23/15/25:
four new generation calls, eight eventual successful answers overall, nine total
generation CLI attempts including the retained429 failure. The failed attempt's
usage remains unknown, not zero. Eight Medium judges remain; no baseline regrade.

The adapter spaces actual new CLI starts by at least60 seconds. It does not change
the command or provider/billing configuration. A process-bound watcher may allow
one CLI transport retry with an observed backoff<=300s, ONLY before any generated
agent text, while preserving warning/raw logs. A second retry warning, longer
backoff or retry after text terminates that exact owned CLI tree and stops. No
whole-question retry loop or new inference to replace completed output. The
original1200s deadline,4GiB client RSS and256MiB reserve remain. The new user
instruction authorizes this narrowly bounded transport repair, not parameter
tuning, paid API, resets or attempts to bypass account limits. Account ordinary
use was allowed at15% five-hour/18% weekly usage before continuation;429 cause
and its duration remain unknown. Do not claim the throttle proves the cause.

The watcher wraps subprocess handles only for this run's verified executable
and --cd under its own temp directory. It delegates original commands/stdin and
records PID/transport notes. Existing CLI retry behavior is documented in the
[official configuration reference](https://learn.chatgpt.com/docs/config-file/config-reference).
No global user configuration is edited. Calls stay sequential under the existing
kernel lock; no subagents or parallel judges.

Bind this adapter/note/tests, exact copied inputs and four reused responses,
original partial-closeout files, and both current progress snapshots before new
inference. Preserve original before/ snapshots needed by its frozen preservation
checks as well. Only TASKS.md/evals/AGENTS.md may receive new progress updates.
Generate all eight before freezing judgments; same source review and reporting
requirements. No retrieval/local generations, holdout, production, safety policy
or M3. Stop again if the bounded repair fails, preserving everything.
