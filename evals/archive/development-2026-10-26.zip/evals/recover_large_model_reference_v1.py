"""Fix warning state, recover completed judge19, then judge remaining seven."""
from datetime import datetime
from pathlib import Path
import shutil
import sys
import time
import continue_large_model_reference_v1 as c

r=c.r
PARENT=c.RUN
RUN=c.ORIGINAL/'continuation-v2'
SELF=Path(__file__).resolve()
NOTE=r.PUBLIC/'large_model_reference_transport_recovery.v1.md'
TEST=r.PUBLIC/'test_large_model_reference_recovery_v1.py'
last_start=0.0


def new_warning_policy(stderr,stdout,seen):
    count=sum('retrying sampling request' in line for line in stderr.splitlines())
    return (c.retry_policy(stderr,stdout),count) if count>seen else ('none',seen)


def preservation():
    binding=r.a.read(RUN/'recovery-binding.json')
    for name,value in binding['parent_hashes'].items():
        path=RUN/'recovery-progress-before'/name if name in r.ALLOWED else r.ROOT/name
        assert r.sha(path)==value,name
    for name,value in binding['hashes'].items():assert r.sha(r.ROOT/name)==value,name
    return c.preservation()


def prepare():
    assert not RUN.exists()
    c.install();r.preservation()
    source=PARENT/'judges/case-19'
    old=r.a.read(source/'record.json')
    assert old['errors']==['nonzero CLI exit'] and old['returned_decisions']
    inp=r.a.read(PARENT/'judge-inputs/case-19.json')
    assert not r.a.validate(old['returned_decisions'],inp)
    events,bad,usage=r.a.runtime.events_and_usage(source/'stdout.jsonl')
    assert not bad and any(e.get('type')=='turn.completed' for e in events) and usage==old['usage']
    hashes={str(p.relative_to(r.ROOT)):r.sha(p) for p in PARENT.rglob('*') if p.is_file()}
    for name in r.ALLOWED:hashes[name]=r.sha(r.ROOT/name)
    RUN.mkdir()
    for name in ['inputs','judge-definitions','before','responses','judge-inputs']:
        shutil.copytree(PARENT/name,RUN/name)
    for name in ['freeze.json','baseline.json','reused-control.json','generation-complete.json','judge-freeze.json']:
        shutil.copyfile(PARENT/name,RUN/name)
    for name in r.ALLOWED:
        target=RUN/'recovery-progress-before'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r.ROOT/name,target)
    target=RUN/'judges/case-19';target.mkdir(parents=True)
    for path in source.iterdir():
        if path.is_file():shutil.copyfile(path,target/('record.original.json' if path.name=='record.json' else path.name))
    recovered=r.a.finalize_call(target,inp,returncode=None,error=None)
    assert recovered['success'] and recovered['returned_decisions']==old['returned_decisions']
    r.write(target/'recovery.json',{'at':r.a.now(),'no_new_inference':True,'original_failure':'nonzero CLI exit caused by retry-watcher state bug',
        'original_record_sha256':r.sha(source/'record.json'),'completed_raw_sha256':r.sha(source/'stdout.jsonl'),
        'original_exit_zero':False,'effective_record_basis':'completed turn, valid exact JSON/schema/quotes, same requested model/effort/usage'})
    paths=[p for p in RUN.rglob('*') if p.is_file()]+[SELF,NOTE,TEST]
    r.write(RUN/'recovery-binding.json',{'at':r.a.now(),'parent_hashes':hashes,
        'hashes':{str(p.relative_to(r.ROOT)):r.sha(p) for p in paths},
        'reused_generation_answers':8,'recovered_judge_cases':['case-19'],'new_judge_cases':r.CASES[1:],
        'generation_cli_attempts_total':9,'maximum_total_judge_dispatches':8,'changed_experimental_variables':[]})
    install();r.preservation();print('Completed judge19 recovered without inference; eight answers immutable; seven judges remain.',flush=True)


class FixedWatcher(c.WatchedProcess):
    def __init__(self,*args):
        super().__init__(*args);self.seen=0

    def poll(self):
        code=self.process.poll()
        if code is not None:return code
        status,self.seen=new_warning_policy(self.stderr.read_text(encoding='utf-8',errors='replace'),self.stdout.read_text(encoding='utf-8',errors='replace'),self.seen)
        if status.startswith('allow'):
            path=self.stderr.parent/'transport-retry.json'
            if not path.exists():r.write(path,{'at':r.a.now(),'policy':status,'watcher':'new-warning state correction'})
        if status.startswith('stop'):
            r.write(self.stderr.parent/'transport-stop.json',{'at':r.a.now(),'reason':status,'pid':self.process.pid})
            try:
                for child in reversed(r.a.psutil.Process(self.process.pid).children(recursive=True)):
                    try:child.kill()
                    except r.a.psutil.Error:pass
            except r.a.psutil.Error:pass
            self.process.kill();return self.process.wait()
        return None


def paced_popen(*args,**kwargs):
    global last_start
    command=args[0] if args else kwargs.get('args',[])
    target=Path(command[command.index('--cd')+1]).resolve() if '--cd' in command else None
    if target is None or not target.is_relative_to((RUN/'temp').resolve()):return c.old_popen(*args,**kwargs)
    assert Path(command[0]).resolve()==Path(r.a.read(RUN/'freeze.json')['preflight']['cli']).resolve()
    while time.monotonic()-last_start<60:time.sleep(min(10,60-(time.monotonic()-last_start)))
    process=c.old_popen(*args,**kwargs);last_start=time.monotonic()
    return FixedWatcher(process,kwargs['stderr'].name,kwargs['stdout'].name)


def install():
    global last_start
    stamps=list((RUN/'responses').glob('*/transport-process.json'))+list((RUN/'judges').glob('*/transport-process.json'))
    if stamps:last_start=time.monotonic()-max(0,time.time()-max(datetime.fromisoformat(r.a.read(p)['at']).timestamp() for p in stamps))
    r.RUN=RUN;r.preservation=preservation;r.subprocess.Popen=paced_popen


def main():
    if sys.argv[1]=='prepare':prepare();return
    install()
    if sys.argv[1]=='summarize':
        import summarize_large_model_reference_v1 as summary
        summary.RUN=RUN;summary.main();return
    r.main()


if __name__=='__main__':main()
