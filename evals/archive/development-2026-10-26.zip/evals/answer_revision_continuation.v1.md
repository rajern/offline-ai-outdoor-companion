# Authorized continuation, 2026-10-24

The owner's one-shot 21:15 Europe/Oslo continuation authorizes a technical timeout
repair, sequential Medium then High, and reuse of all successful assessments.
No reset credits or paid APIs are authorized. This addendum supersedes only the
420-second timeout/retry stop, not any rubric, input or safety decision.

Before dispatch, the adapter checks the frozen transport-v3 files and inspects
the failed Medium case-08 stream. It contains startup events only, no completed
turn or final answer; usage is unknown. There is no assessment to recover.
The original failed attempt and every original file remain untouched and hashed.

The new private `continuation-v1` directory copies the nine successful call
directories byte for byte (one control and eight main groups, 12 saved answers).
It reuses their assessments without inference. All 29 frozen input JSON files,
rubrics, schema, instructions, CLI bytes and inference settings are unchanged.

The only inference execution change is a **1,200-second wall-clock timeout for
new calls at both efforts**, rather than 420 seconds. Large grouped assessments
may need longer; the previous timeout is not evidence about answer quality.
The owner's authorization permits one new attempt at the previously timed-out
case-08. Subsequent failed/dispatched calls are never automatically retried.
No new control is run at Medium. High starts only after all Medium groups pass.
There are at most 49 new dispatches: 20 Medium groups and 29 High groups including
its control. Including the earlier timeout, at most 59 total model dispatches
are involved in this paired experiment. Startup failures before dispatch remain
separately documented. Known usage excludes the unknown timed-out usage.

The exclusive judge lock, no-tools/read-only ephemeral CLI, ChatGPT subscription
authentication, 4 GiB process-tree RSS cap and 256 MiB host reserve remain intact.
On a new timeout, quota/access failure, invalid response or resource breach, stop
and preserve output; do not retry or reduce inputs. Hashes bind the adapter,
this addendum, all inherited artifacts and inputs before new judging begins.

Recovered/reused calls retain their original command and temporary path. New
calls retain exact command arguments, input, raw output, resource samples summary,
usage and model/effort request. The CLI does not prove actual server revision.
The unavailable-code-mode warning occurs in successful calls too; it is not a
verified explanation for the timeout. Reports must retain that uncertainty.

Official CLI background: https://learn.chatgpt.com/docs/non-interactive-mode
(`--ephemeral`, JSONL turn completion and usage). No API transport is introduced.
