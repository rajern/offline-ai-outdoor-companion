"""Pinned-runtime/Windows-lock adapter; original frozen implementation is unchanged."""
from __future__ import annotations
import contextlib
import os
from pathlib import Path
import shutil
import sys

import run_generation_improvement_v1 as s

ORIGINAL = s.RUN
RUN = ORIGINAL/'revision-02'
NOTE = s.PUBLIC/'local_generation_improvement_transport.v1.md'
SELF = Path(__file__).resolve()
original_preservation = s.preservation


def prepare():
    assert not RUN.exists(), 'Never overwrite an existing revision'
    frozen = original_preservation()
    assert s.a.read(ORIGINAL/'stop.json')['error'].startswith('[WinError 2]')
    assert not list((ORIGINAL/'responses').glob('**/dispatched.json'))
    assert not list((ORIGINAL/'responses').glob('**/response.json'))
    assert not s.g.q.LOCK.exists(), 'Existing owner must be checked separately'
    pinned = [name for name in frozen['model_runtime_identities'] if name.endswith('llama-server.exe')]
    assert len(pinned) == 1
    runtime = pinned[0]
    assert s.sha(runtime) == frozen['model_runtime_identities'][runtime]
    old_files = {str(p.relative_to(s.ROOT)): s.sha(p) for p in ORIGINAL.rglob('*') if p.is_file()}
    RUN.mkdir()
    for name in ['definitions', 'judge-definitions', 'before']:
        shutil.copytree(ORIGINAL/name, RUN/name)
    for name in ['definitions.json','baseline.json','reused-control.json','system.A.txt','system.B.txt']:
        shutil.copyfile(ORIGINAL/name,RUN/name)
    s.write(RUN/'adapter-binding.json', {
        'at':s.a.now(), 'adapter_sha256':s.sha(SELF), 'note_sha256':s.sha(NOTE),
        'original_files':old_files, 'runtime':runtime,
        'runtime_sha256':frozen['model_runtime_identities'][runtime],
        'previous_completion_dispatches':0, 'previous_completed_responses':0,
        'changes':['select exact already pinned runtime path','close lock before unlink'],
        'changed_experimental_variables':[]})
    install()
    s.preservation()
    print('Startup adapter frozen; original attempt unchanged; zero previous completions.',flush=True)


def verify_adapter():
    binding=s.a.read(RUN/'adapter-binding.json')
    assert s.sha(SELF)==binding['adapter_sha256']
    assert s.sha(NOTE)==binding['note_sha256']
    assert s.sha(binding['runtime'])==binding['runtime_sha256']
    for name,expected in binding['original_files'].items():
        assert s.sha(s.ROOT/name)==expected,name
    assert s.sha(RUN/'definitions.json')==s.sha(ORIGINAL/'definitions.json')
    return binding


def preservation():
    verify_adapter()
    return original_preservation()


def install():
    binding=verify_adapter()
    s.RUN=RUN
    s.g.p.RUNTIME=Path(binding['runtime'])
    s.preservation=preservation


@contextlib.contextmanager
def local_lock():
    path=s.g.q.LOCK
    assert path.resolve().is_relative_to((s.ROOT/'knowledge/local').resolve())
    handle=path.open('x',encoding='utf-8')
    handle.write(str(os.getpid()));handle.flush()
    try:
        yield
    finally:
        handle.close()
        assert path.read_text(encoding='utf-8')==str(os.getpid()),'Lock owner changed'
        path.unlink()


def main():
    action=sys.argv[1]
    if action=='prepare':
        prepare();return
    install()
    if action in ('preflight','generate'):
        assert not (RUN/'stop.json').exists(),'Retained stop; separate review required'
        with local_lock():
            try:
                s.preflight() if action=='preflight' else s.generate()
            except BaseException as exc:
                s.write(RUN/'stop.json',{'at':s.a.now(),'action':action,'error':str(exc),'automatic_retries':0})
                raise
    elif action=='prepare-judges':s.prepare_judges()
    elif action=='judge':s.judge()
    elif action=='check':print({'definitions_verified':len(s.preservation()['spec_ids'])})
    else:raise ValueError(action)


if __name__=='__main__':main()
