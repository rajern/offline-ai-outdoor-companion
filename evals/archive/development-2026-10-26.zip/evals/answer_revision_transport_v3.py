"""Same frozen experiment after sandbox blocked CLI before client initialization.

Requires normal host CLI execution permission. The child judge retains no-tools,
read-only, isolated sessions; neither rubric nor inference input is changed.
"""
from pathlib import Path
import sys

import answer_revision_transport_v2 as transport

r=transport.r
PARENT=transport.TARGET_RUN
TARGET=r.RUN/'transport-v3'


def prepare():
    r.RUN=PARENT
    original=r.check_freeze()
    stopped=PARENT/'results/medium/control-equipment'
    assert (stopped/'stdout.jsonl').read_bytes()==b''
    assert 'failed to initialize in-process app-server client' in (stopped/'stderr.txt').read_text(encoding='utf-8')
    assert not r.read(stopped/'record.json')['success']
    if TARGET.exists():raise RuntimeError('Transport already exists')
    for name in ('private-answer-map.json','control-expected.json','preserved-files.json'):
        r.write(TARGET/name,r.read(PARENT/name))
    for p in (PARENT/'inputs').glob('*.json'):r.write(TARGET/'inputs'/p.name,r.read(p))
    f={**original,'transport_prepared_at':r.now(),'parent_freeze_sha256':r.digest(PARENT/'freeze.json'),
       'parent_dispatched_model_calls':0,'transport_change':'CLI app-server initialization denied in Windows sandbox; same child read-only/no-tools judge with host execution permission'}
    f['hashes']={**original['hashes'],str(Path(__file__).relative_to(r.ROOT)):r.digest(__file__)}
    for p in (TARGET/'inputs').glob('*.json'):f['hashes'][str(p.relative_to(r.ROOT))]=r.digest(p)
    r.write(TARGET/'freeze.json',f)
    print('Prepared v3: zero parent model calls; frozen experiment unchanged.',flush=True)


if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    else:
        r.RUN=TARGET
        transport.TEMP_ROOT=TARGET/'temp'
        r.tempfile.TemporaryDirectory=transport.workspace_temporary_directory
        if sys.argv[1]=='summarize':r.summarize()
        else:r.run(sys.argv[1])
