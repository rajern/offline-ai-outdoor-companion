# Neste lokale forbedringsrunde: forskning og anbefaling

25. oktober 2026. Brukeren ba om en grundig forskningsgjennomgang opp mot dagens
oppsett, og en prioritering av hva som trolig kan gi størst bedring. Dette er en
forsknings- og analyseleveranse. Ingen nye søk i kunnskapsbasen, produktsvar,
dommerkall, modellnedlastinger eller endringer i produksjon er utført.

**Anbefaling:** Test først om modelltilpassede genereringsinnstillinger retter
den tydelige repetisjonsfeilen. Test også en mer kildebevarende svaroppgave med
samme leverte kontekst. Det siste har etter min vurdering størst potensial for
bredere kvalitetsbedring; innstillingene er den billigste konkrete hypotesen å
prøve først. Ingen forventet prosentgevinst kan forsvares før testing.

## 1. Hva vi faktisk vet om Outwise

### Samme vurderingsgrunnlag, ulike utvalg

| Grunnlag | Levert fra retrieval | Fullt gjengitt i svaret | Bevaring av leverte krav |
|---|---:|---:|---:|
| Historisk Qwen, hele 25-settet | 55/63 | 13/63 | 13/55 = 23,6 % |
| Historisk Qwen, åtte screening-spørsmål | 13/15 | 4/15 | 4/13 = 30,8 % |
| Nyere Qwen, samme åtte | 13/15 | 8/15 | 8/13 = 61,5 % |
| Gemma, samme åtte | 13/15 | 6/15 | 6/13 = 46,2 % |

Tallene kommer fra den låste nye rubrikken og Sol Medium. De to nyeste oppsettene
har ikke svar på hele 25-settet. Den gamle fullsett-scoren beskriver derfor ikke
dagens beste testede genereringsoppsett. Nyere Qwen har flere udokumenterte tillegg
enn Gemma, og ingen er kvalifisert som helhetlig god løsning. Bevaringsprosenten
er heller ikke andelen av alle svarpåstander som har kildestøtte.

Begge nye modeller får 7/8 obligatoriske krav på tre særskilt utvalgte
tilstrekkelig-kontekstkontroller. Dette er et nyttig tegn på forbedringsrom, men
ikke et estimat for vanlig bruk: kontrollene endrer både hvilke opplysninger som
finnes, støy, lengde og plassering. De isolerer ikke én årsak.

Alle 25 ordinære kontekster har registrert irrelevant stoff. Det betyr ikke at
all eller mesteparten av teksten er irrelevant. Åtte av 63 obligatoriske krav er
fortsatt bare delvis levert eller fraværende. En god genereringsendring kan bevare
informasjon bedre; den kan ikke pålitelig skape kildebelegg som mangler.

Se [oppdatert retrieval-rapport](retrieval_rubric_rescore_report.v1.md) og
[svarvurderingen](answer_revision_report.v2.md). De gamle resultatene er uendret.

### En ny, konkret observasjon fra de lagrede råloggene

Jeg har lest metadata fra alle 22 nyere, lagrede svar og kontrollert de 110
filhashene i deres eksisterende forseglinger. Ingen inferens ble gjentatt.

| Innstilling/funn | Nyere Qwen 2B | Gemma E2B |
|---|---:|---:|
| Temperatur | 0,2 | 0,2 |
| top-p / top-k | 0,8 / 20 | 0,8 / 20 |
| Faktisk min-p fra runtime | 0,05 | 0,05 |
| Presence penalty / repeat penalty | 0 / 1 | 0 / 1 |
| Maks svartokens | 512 | 512 |
| Svar som stoppet på maksgrensen | 2/11 | 0/11 |
| Outputlengde på åtte primærsvar | 130–512 tokens | 24–218 tokens |

Qwens primære pustesvar går i en lang gjentakelse av telefonråd. Det er en
konkret genereringssvikt, ikke bare en streng fullstendighetsrubrikk. Det andre
svaret som treffer maksgrensen gjelder lynventetid. Gemma avslutter alle sine
svar selv; større tokenbudsjett alene forklarer derfor ikke Gemmas utelatelser.

Begge har fungerende native chat-format, thinking av og input som passer innenfor
4096-konteksten uten registrert avkorting. Å øke runtime-konteksten alene gir ikke
modellen mer tekst når den leverte pakken er uendret. Den faktiske applikasjonen
har fortsatt eldre standarder: høyst tre punkter og 256 svartokens. Den nye
sammenligningen fjernet allerede trepunktsgrensen og økte til 512. Det er ikke
et nytt forbedringstiltak å foreslå disse grepene på nytt.

Etterprøvbare metadata og lokale inputhashverdier ligger i
[evidensfilen](local_generation_improvement_evidence.v1.json). Hele forrige
avslutningsmanifest på 278 filer er kontrollert uendret.

## 2. Hva forskningen støtter, og hvor den ikke passer

### A. Genereringsinnstillingene er en reell, uprøvd variabel

Den nåværende offisielle Qwen3.5-2B-modellbeskrivelsen anbefaler for tekst uten
thinking temperatur 1,0, top-p 1,0, top-k 20, min-p 0 og presence penalty 2,0.
Den advarer også om at høy presence penalty kan gi språkblanding og noe svakere
ytelse. Dette er en produsentanbefaling, ikke dokumentasjon av bedre norsk RAG
på vår GGUF-fil. [Qwens modellkort](https://huggingface.co/Qwen/Qwen3.5-2B#best-practices).

Google oppgir temperatur 1,0, top-p 0,95 og top-k 64 for Gemma 4. Modellkortet
angir ikke en komplett min-p-/repetisjonsprofil for vår runtime. Begge kortene
har støtte for thinking, men gir ingen garanti for bedre kildefølgning i Outwise.
[Gemma 4-modellkortet](https://ai.google.dev/gemma/docs/core/model_card_4#best_practices).

llama.cpp dokumenterer min-p som et ekstra filter relativt til det mest
sannsynlige neste tokenet, med standardverdi 0,05. Det forklarer hvorfor det kan
være aktivt selv om vi bare satte temperatur/top-p/top-k i forespørselen.
[Offisiell serverdokumentasjon](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md).

**Min vurdering:** Lik sampling var et forståelig kontrollvalg i forrige
sammenligning. Den viser hvordan modellene oppfører seg under det valgte felles
oppsettet, men ikke hvor gode hver av dem kan bli. Nå har vi en spesielt konkret
grunn til å teste en annen profil på Qwen: gjentakelsesløkker uten aktiv
repetisjonsstraff. Det er ikke bevist at profilavviket forårsaket feilene.

En profiltest bør endre den dokumenterte parametergruppen samlet og holde resten
fast. Den kan da teste profilen som pakke, men ikke tilskrive forbedringen én
enkelt parameter. Gemmas eventuelle min-p=0 må merkes som vårt eksplisitte
forsøksvalg, ikke som et Google-krav. Andre samplere og penalty-vindu må også
logges; like parameternavn garanterer ikke identisk implementasjon på tvers av
runtime. Høyere temperatur er ikke i seg selv et middel mot oppdiktede råd.

### B. Høy retrieval-dekning garanterer ikke god bruk av konteksten

Sufficient Context skiller mellom om kildene er tilstrekkelige og om modellen
bruker dem riktig. Flere modeller feiler også med tilstrekkelig kontekst; store
modeller kan fortsatt svare feil når konteksten mangler svar. Studien omfatter
blant annet modeller på 7B, 8B og 27B, så «små» betyr ikke våre 2B-oppsett.
Dette støtter skillet i målingen vår, men gir ingen overførbar målprosent.
[Sufficient Context, fulltekst](https://arxiv.org/html/2411.06037v1).

**Min vurdering:** 87,3 % er andelen bestemte krav som finnes fullt i pakkene,
ikke et bevis på at pakkene er lette å lese. Vi kan jobbe med generering og
presentasjon av de allerede hentede kildene uten å starte enda en generell
optimalisering av embeddingmodell eller top-k.

### C. Mer direkte kildeuttak er lovende, men komprimering kan miste innhold

RECOMP trener både uttrekkende og omskrivende komprimering før svarmodellen.
Det gir støtte til å undersøke om vi kan redusere lesebelastningen. Forfatternes
egen gjennomgang viser også at omskrevne sammendrag kan være ufullstendige eller
utro mot kildene. Artikkelen er dermed ikke belegg for at en ekstra fri
sammenfatning automatisk gjør kjeden mer pålitelig.
[RECOMP, særlig analyse av sammendrag](https://arxiv.org/html/2310.04408v1).

Ext2Gen kombinerer uttrekk av bevis med generering og rapporterer forbedringer
også på 3B-modeller. Metoden bruker trening og preferansetilpasning; effekten er
ikke dokumentert som et enkelt promptgrep på en uendret Qwen3.5-2B. Den illustrerer
en lovende arbeidsmåte, men ikke en ferdig gevinst vi kan kopiere.
[Ext2Gen, fulltekst](https://arxiv.org/html/2503.04789v3).

**Min vurdering:** Det mest interessante forsøket er å gi den eksisterende
modellen en smalere oppgave: hente ut relevante, komplette instrukser og gjengi
dem med minst mulig fri omskriving. Det er en tydeligere forskjell fra dagens
generelle «svar ut fra kildene» enn enda flere forbudssetninger i systemprompten.

En slik svarvariant kan bruke interne kilde-IDer ved hvert handlingspunkt, og
enkel forklaring bare når den følger av samme kildegrunnlag. Dette gjelder
forsøksformatet, ikke en besluttet ny brukerflyt. Kilde-IDer beviser ikke at et
punkt er støttet; faktiske vilkår, rekkefølge, tall og situasjon må vurderes.

Start med den samme fulle kildepakken. Ikke legg inn fasitsvaret, rubrikkens
kravliste eller manuelt utvalgte riktige avsnitt. Da undersøker vi om en mer
uttrekkende svaroppgave virker under realistisk støy. En ekstra modellstyrt
filterrunde eller et komprimert mellomledd er en senere mulighet, siden det gir
både en ny feilkilde og mer arbeid per svar.

### D. Ikke fjern støy ukritisk

Ret-Robust finner at irrelevant kontekst kan skade svarene, og at filtrering kan
hjelpe, men også kaste bort relevante passasjer. Deres mer robuste løsning bruker
trening med blandet relevant og irrelevant kontekst. Det støtter behovet for å
kontrollere hva et filter mister, ikke bare om teksten blir kortere.
[Making Retrieval-Augmented Language Models Robust to Irrelevant Context](https://proceedings.iclr.cc/paper_files/paper/2024/hash/8011b23e1dc3f57e1b6211ccad498919-Abstract-Conference.html).

The Power of Noise fant skade fra nærliggende distraktorer, men også bedring fra
tilfeldig tekst i enkelte oppsett. En SIGIR 2026-replikasjon finner at den positive
støyeffekten er sterkt avhengig av prompt og dekodingsgrenser. «Kortere er alltid
bedre» er derfor for sterkt. [Opprinnelig studie](https://arxiv.org/abs/2401.14887v4),
[replikasjon](https://arxiv.org/abs/2607.03615v2).

Lost in the Middle dokumenterer at plassering i lange input kan påvirke ytelsen.
Det gjør rekkefølge til en rimelig hypotese, men studiens modeller og oppgaver er
andre enn våre, og våre input er forholdsvis korte. Den diagnostiserer ikke
Outwise. [Lost in the Middle](https://arxiv.org/abs/2307.03172).

**Min vurdering:** Vi har allerede lokalt motbevis mot blind ompakking: den
tidligere T-packing-varianten falt fra T-rankings 60/72 til 50/72 under gammel
vurdering og mistet tidligere dekkede krav. Eventuell senere filtrering må derfor
bevare hele handlingsenheter med overskrift, betingelse, handling og forbehold.
Det må måles på nytt hva som er tilgjengelig etter filtreringen. Man kan ikke
fortsette å bruke 55 som nevner hvis filteret har fjernet noen av disse kravene.

### E. Det finnes ingen påvist universell grense for små RAG-modeller

Pleias-RAG presenterer spesielt trente modeller rundt 350M og 1B med eksplisitt
kildebruk. Forfatterne rapporterer konkurransedyktige resultater på bestemte
RAG-benchmarker. De flerspråklige målingene som beskrives, er fransk, italiensk,
tysk og spansk i tillegg til engelsk; norsk er ikke demonstrert. Det er heller
ingen førstehjelps- eller mobilgodkjenning.
[Pleias-RAG, fulltekst](https://arxiv.org/html/2504.18225v2).

MiniRAG undersøker blant annet MiniLM sammen med modeller i 1,5B–4B-klassen.
Det foreslår en grafbasert struktur for lette RAG-systemer. Studien viser at
systemutformingen betyr noe, men krever en annen arkitektur og tester andre
datasett. Den er ingen begrunnelse for å erstatte vår kjede nå.
[MiniRAG, fulltekst](https://arxiv.org/html/2501.06713v1).

**Min vurdering:** Det er for tidlig å si «2B er for svak uansett». Det er også
for tidlig å hevde at våre uendrede modeller med en liten promptjustering kan
gjøre det like godt som spesielt trente modeller. Jeg anbefaler ingen ny
modelljakt eller finjustering i denne runden. De ville kreve en egen begrunnelse
og gå ut over de enkleste uprøvde grepene.

### F. Promptstudier må leses med riktig nevner og mål

En preprint fra februar 2026 tester 24 promptvarianter på Qwen2.5-3B og
Gemma3-4B. Metodedelen beskriver 390 ulike HotpotQA/RAGBench-rader; 390 × 24 × 2
forklarer de 18 720 evalueringene i omtalen. Det er ikke 18 720 uavhengige
spørsmål. «Accuracy»-tabellene bruker en egen vektet GPT-4o-mini-vurdering av
blant annet mening, korrekthet og fullstendighet. Den rapporterte scoren rundt
84 % er derfor ikke direkte sammenlignbar med vår fullstendige kravdekning.
Studien er nyttig som støtte for modellavhengige promptvirkninger, ikke som mål
for Outwise. [Original preprint og metode, s. 5–7](https://arxiv.org/pdf/2602.13890).

Nyere arbeid på egenretting finner både gjenopprettede feil og tidligere riktige
svar som blir feil etter revisjon. Derfor bør «be modellen kontrollere seg selv»
behandles som en testbar hypotese, ikke en sikkerhetskontroll.
[Risk-Aware Study of Intrinsic Self-Correction](https://arxiv.org/abs/2609.35832).

**Min vurdering:** Jeg ville ikke brukt en stor promptkonkurranse, lange
resonneringskjeder eller mange automatiske rettingsrunder som neste tiltak.
Thinking kan undersøkes senere dersom konkrete feil krever det. Det vil trenge
et eget budsjett for både resonnering og slutttekst; å slå det på innen samme
512-tokenramme kan ta plass fra selve svaret. Låst Medium gjelder evaluerings-
dommeren og er uavhengig av lokal Qwen-/Gemma-thinking.

## 3. Min prioritering

Dette er begrunnede hypoteser, ikke målte forventningsverdier.

| Tiltak | Hvorfor det passer våre feil | Prioritet / begrensning |
|---|---|---|
| Modelltilpasset sampling, alle filtre eksplisitte | Konkret Qwen-repetisjon; begge modeller testet med en felles profil som avviker fra produsentoppsettene | Først: lav gjennomføringskostnad. Bred kvalitetsgevinst uavklart. |
| Mer direkte uttrekk av komplette kildeinstrukser, mindre fri omskriving | Utelatelser, tapte betingelser og oppdiktede tillegg; særlig Gemmas tidlige, korte avslutninger | Størst antatt potensial for bred bedring. Må teste faktisk kildefølgning. |
| Bedre utvalg/organisering av allerede hentede avsnitt | Kontekstkontrollene er bedre; primærpakkene inneholder distraktorer | Lovende senere dersom uttrekk alene ikke hjelper; risiko for tap av kildekrav. |
| Bare flere svartokens eller større kontekstvindu | To Qwen-svar møter grensen, men minst ett er en løkke; Gemma møter den aldri | Lav prioritet alene. Overvåk stoppårsaker først. |
| Thinking, nye kvantiseringer eller flere modeller | Mulig forbedringsrom, men svakere direkte diagnose og større ressurs-/tolkningskostnad | Utsett. 4B-eksklusjonen er et konkret ressursfunn om ett oppsett. |
| Finjustering, kunnskapsgraf, agentkjede eller egen verifikasjonsmodell | Finnes i lovende forskning | For stor utvidelse før de enkle hypotesene er testet. |

## 4. Forslag til én kontrollert forbedringsrunde

Dette er et forslag, ikke en frosset eller igangsatt kjøreprotokoll.

1. **Bruk siste lagrede åtte-spørsmålsrunde som baseline.** Hold modellfiler,
   runtime, spørsmål, faktiske kildeblokker/rekkefølge og den låste rubrikken
   fast. Gjenbruk gamle svar. Ikke bruk den eldre full25-scoren som om den var
   en ny baseline for disse åtte spørsmålene.
2. **Variant A: endre bare genereringsprofilen.** Bruk én på forhånd spesifisert
   modelltilpasset profil per modell, og samme eksisterende prompt. Kontroller
   de faktisk effektive verdiene, ikke bare forespørselen. Behold 512
   svartokens og thinking av for denne sammenligningen.
3. **Variant B: endre bare svaroppgaven.** Behold de gamle samplingverdiene og
   samme kildepakke, men prøv en kort instruks om uttrekk og nær gjengivelse av
   relevante komplette kildeinstrukser, med sporbare kilde-IDer. Ingen ekstra
   modellrunde, manuell fasitfiltrering eller genererte forkunnskaper. Frys den
   eksakte prompten før svarene lages. Uttrekk innebærer her en svarstil, ikke
   allerede bevist korrekt evidensseleksjon.
4. **Vurder begge varianter samlet.** Åtte spørsmål × to modeller × to varianter
   er høyst 32 nye svar ved én kjøring hver. Det er nok til en målrettet
   utviklingssjekk, ikke et generelt kvalitetstall eller en stabilitetsstudie.
   Ingen automatisk tredje kombinasjon eller parameterjakt.
5. **Gå videre bare ved konkret bedring.** Prioriter færre kritiske feil og
   udokumenterte tillegg, bedre bevaring av leverte krav og riktig avståelse.
   Rapporter også tapte krav, delvis dekning, stoppårsaker, svartid og minne.
   Full25 og forhåndsvalgte gjentakelser/omformuleringer er et separat neste
   beslutningspunkt for en lovende variant. Enkeltseed er ikke robusthet.

Dette skiller innstillingshypotesen fra oppgavehypotesen uten et stort
forsøksopplegg. Eventuelt å kombinere to vinnende grep er fortsatt et nytt
oppsett som må kontrolleres. Hvis ingen variant gir meningsfull bedring, er
det et legitimt stoppresultat; vi trenger ikke utvide til flere og flere grep.

En senere GPT-sammenligning bør få samme spørsmål og leverte kilder, og vurderes
etter samme regler. Den vil gi en praktisk referanse for kapasitet, ikke bevise
at lokale modeller er umulige. Direkte visning av kildeprosedyrer med begrenset
forklaring står fortsatt som et mulig produktvalg dersom fri generering svikter.

## 5. Hva jeg tror kan gi mest bedring

**For Qwens tydelige løkker:** modelltilpasset sampling er den mest konkrete og
rimelige første testen. **For samlet kildebruk og fullstendighet:** en smalere,
uttrekkende svaroppgave er min beste hypotese, eventuelt senere støttet av mer
forsiktig organisering av konteksten. Begge må testes mot feil og tillegg,
ikke bare en høyere dekningsprosent.

Det er ikke grunnlag for å love et tall, konkludere med en fast 2B-grense eller
hevde at rubrikken må senkes. De viktigste forbedringsmulighetene ligger nå i
å gjøre det lettere for den eksisterende modellen å bruke det den allerede får.

## Avgrensning og etterprøving

Dette er en målrettet gjennomgang av primærkilder, ikke en systematisk
litteraturmetaanalyse. Modeller, språk, oppgaver, maskinvare og måltall i studiene
avviker fra Outwise. Produsentanbefalingene er kontrollert på datoen over og kan
endres; de er ikke testet her. Ingen kilde validerer vårt sikkerhetsnivå.

Den nye evidensfilen inneholder metadata og hashverdier, ikke privat kildetekst
eller gjengivelse av rådene. Historiske forsøk, rubrikk, dommerinnstillinger,
produksjon, beslutningsdokument og M3 er uendret. Ingen holdout-filer er åpnet.
Ingen betalt API, gratis tilbakestilling eller ny lokal inferens er brukt.
