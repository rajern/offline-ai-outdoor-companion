"""Reuse four answers; paced unchanged CLI with a bounded pre-text retry watcher."""
import json
from datetime import datetime
from pathlib import Path
import re
import shutil
import sys
import time

import run_large_model_reference_v1 as r

ORIGINAL=r.RUN
RUN=ORIGINAL/'continuation-v1'
SELF=Path(__file__).resolve()
NOTE=r.PUBLIC/'large_model_reference_continuation.v1.md'
TEST=r.PUBLIC/'test_large_model_reference_continuation_v1.py'
old_preservation=r.preservation
old_popen=r.subprocess.Popen
last_start=0.0


def retry_policy(stderr,stdout):
    warnings=[line for line in stderr.splitlines() if 'retrying sampling request' in line]
    if not warnings:return 'none'
    if len(warnings)>1:return 'stop: second transport retry'
    if '429 Too Many Requests' not in warnings[0]:return 'stop: different transport failure'
    wait=re.search(r'in ([0-9.]+)s',warnings[0])
    if not wait or float(wait.group(1))>300:return 'stop: backoff exceeds approved bound'
    for line in stdout.splitlines():
        try:item=json.loads(line).get('item',{})
        except (ValueError,TypeError):continue
        if item.get('type')=='agent_message' and item.get('text'):return 'stop: text already generated'
    return 'allow: one pre-text429 retry'


def prepare():
    assert not RUN.exists()
    old_preservation()
    closeout=r.a.read(ORIGINAL/'partial-closeout.json')
    for name,value in closeout['hashes'].items():assert r.sha(r.ROOT/name)==value,name
    failed=ORIGINAL/'responses/case-21'
    record=r.a.read(failed/'record.json')
    events,malformed,usage=r.a.runtime.events_and_usage(failed/'stdout.jsonl')
    assert not record['success'] and record['answer'] is None and usage is None and not malformed
    assert not any(e.get('type')=='turn.completed' or e.get('item',{}).get('type')=='agent_message' for e in events)
    assert '429 Too Many Requests' in (failed/'stderr.txt').read_text(encoding='utf-8')
    pre=r.a.runtime.preflight();frozen=r.a.read(ORIGINAL/'freeze.json')
    assert r.sha(pre['cli'])==frozen['preflight']['cli_sha256']
    RUN.mkdir()
    for name in ['inputs','judge-definitions','before']:shutil.copytree(ORIGINAL/name,RUN/name)
    for name in ['freeze.json','baseline.json','reused-control.json']:shutil.copyfile(ORIGINAL/name,RUN/name)
    reused=[]
    for cid in r.CASES:
        source=ORIGINAL/'responses'/cid
        if (source/'seal.json').exists():
            r.g.verify_seal(source);shutil.copytree(source,RUN/'responses'/cid);reused.append(cid)
    assert reused==['case-19','case-05','case-08','case-17']
    for name in r.ALLOWED:
        dest=RUN/'progress-before'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r.ROOT/name,dest)
    paths=[p for p in RUN.rglob('*') if p.is_file()]+[SELF,NOTE,TEST]
    r.write(RUN/'continuation-binding.json',{'at':r.a.now(),'authorization':'owner resume/fix429,2026-10-25',
        'parent_closeout_sha256':r.sha(ORIGINAL/'partial-closeout.json'),'parent_hashes':closeout['hashes'],
        'hashes':{str(p.relative_to(r.ROOT)):r.sha(p) for p in paths},
        'reused_cases':reused,'new_generation_cases':['case-21','case-23','case-15','case-25'],
        'generation_cli_attempts_total_limit':9,'new_generation_limit':4,'new_judge_limit':8,
        'minimum_start_interval_seconds':60,'maximum_pretext_retry_warnings':1,'maximum_backoff_seconds':300,
        'failed_prior_usage_known':False,'changed_experimental_variables':[]})
    install();r.preservation();print('Continuation frozen: four reused, four new generations, unchanged eight judges.',flush=True)


def preservation():
    binding=r.a.read(RUN/'continuation-binding.json')
    assert r.sha(ORIGINAL/'partial-closeout.json')==binding['parent_closeout_sha256']
    for name,value in binding['parent_hashes'].items():
        normalized=name.replace('\\','/')
        path=RUN/'progress-before'/normalized if normalized in r.ALLOWED else r.ROOT/name
        assert r.sha(path)==value,name
    for name,value in binding['hashes'].items():assert r.sha(r.ROOT/name)==value,name
    return old_preservation()


class WatchedProcess:
    def __init__(self,process,stderr_path,stdout_path):
        self.process=process;self.stderr=Path(stderr_path);self.stdout=Path(stdout_path)
        r.write(self.stderr.parent/'transport-process.json',{'at':r.a.now(),'pid':process.pid,'minimum_start_interval_seconds':60})

    def __getattr__(self,name):return getattr(self.process,name)

    def poll(self):
        code=self.process.poll()
        if code is not None:return code
        status=retry_policy(self.stderr.read_text(encoding='utf-8',errors='replace'),self.stdout.read_text(encoding='utf-8',errors='replace'))
        if status.startswith('allow'):
            path=self.stderr.parent/'transport-retry.json'
            if not path.exists():r.write(path,{'at':r.a.now(),'policy':status,'no_whole_question_retry':True})
        if status.startswith('stop'):
            r.write(self.stderr.parent/'transport-stop.json',{'at':r.a.now(),'reason':status,'pid':self.process.pid})
            try:
                tree=r.a.psutil.Process(self.process.pid).children(recursive=True)
                for child in reversed(tree):
                    try:child.kill()
                    except r.a.psutil.Error:pass
            except r.a.psutil.Error:pass
            self.process.kill()
            return self.process.wait()
        return None


def paced_popen(*args,**kwargs):
    global last_start
    command=args[0] if args else kwargs.get('args',[])
    target=Path(command[command.index('--cd')+1]).resolve() if '--cd' in command else None
    active=target is not None and target.is_relative_to((RUN/'temp').resolve())
    if not active:return old_popen(*args,**kwargs)
    assert Path(command[0]).resolve()==Path(r.a.read(RUN/'freeze.json')['preflight']['cli']).resolve()
    while time.monotonic()-last_start<60:time.sleep(min(10,60-(time.monotonic()-last_start)))
    process=old_popen(*args,**kwargs);last_start=time.monotonic()
    return WatchedProcess(process,kwargs['stderr'].name,kwargs['stdout'].name)


def install():
    global last_start
    stamps=list((RUN/'responses').glob('*/transport-process.json'))+list((RUN/'judges').glob('*/transport-process.json'))
    if stamps:
        latest=max(datetime.fromisoformat(r.a.read(p)['at']).timestamp() for p in stamps)
        last_start=time.monotonic()-max(0,time.time()-latest)
    r.RUN=RUN;r.preservation=preservation
    r.subprocess.Popen=paced_popen


def main():
    if sys.argv[1]=='prepare':prepare();return
    install()
    if sys.argv[1]=='summarize':
        import summarize_large_model_reference_v1 as summary
        summary.RUN=RUN;summary.main();return
    r.main()


if __name__=='__main__':main()
