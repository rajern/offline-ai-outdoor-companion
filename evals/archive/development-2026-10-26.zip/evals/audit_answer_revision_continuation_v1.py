"""Offline continuation audit; preserve the original partial audit and call files."""
from collections import Counter
import hashlib
import json

import answer_revision_continue_v1 as c

r = c.r


def audit():
    r.RUN = c.TARGET
    frozen = r.check_freeze()
    calls = []
    seals = {}
    length_deviations = []
    usages = {}
    pairs = 0
    recovered = r.read(r.RUN / 'recovery-and-reuse.json')
    for effort in ('medium', 'high'):
        tokens = Counter()
        for group in frozen['controls'] + frozen['groups']:
            out = r.RUN / 'results' / effort / group
            if not (out / 'record.json').exists():
                continue
            record = r.read(out / 'record.json')
            inp = r.read(r.RUN / 'inputs' / f'{group}.json')
            assert r.read(out / 'input.json') == inp
            assert record['input_sha256'] == r.canonical(inp)
            assert record['raw_sha256'] == r.digest(out / 'stdout.jsonl')
            assert record['requested']['model'] == r.MODEL
            assert record['requested']['reasoning_effort'] == effort
            assert record['requested']['cli_sha256'] == frozen['preflight']['cli_sha256']
            cmd = r.read(out / 'command.json')['argv']
            assert cmd[cmd.index('--model') + 1] == r.MODEL
            assert f'model_reasoning_effort="{effort}"' in cmd
            assert '--ignore-user-config' in cmd and '--ignore-rules' in cmd
            assert cmd[cmd.index('--sandbox') + 1] == 'read-only'
            assert 'features.shell_tool=false' in cmd and 'features.apps=false' in cmd
            assert 'forced_login_method="chatgpt"' in cmd
            if record['success']:
                assert not r.validate(record['returned_decisions'], inp)
                for answer in record['returned_decisions']['answers']:
                    for version in ('historical', 'revised'):
                        for item in answer[version]:
                            limits = {'answer_quote': 220, 'source_quote': 220}
                            if item['decision'] in {'partial', 'absent', 'uncertain'}:
                                limits['reason'] = 180
                            for field, maximum in limits.items():
                                if len(item[field]) > maximum:
                                    length_deviations.append({'effort': effort, 'group': group,
                                        'answer_id': answer['answer_id'], 'rubric': version,
                                        'criterion_id': item['id'], 'field': field,
                                        'characters': len(item[field]), 'prompt_limit': maximum})
            reused = effort == 'medium' and group in recovered['reused_groups']
            if reused:
                for p in out.iterdir():
                    assert r.digest(p) == r.digest(c.PARENT / 'results' / effort / group / p.name)
            else:
                assert record['requested']['timeout_seconds'] == c.TIMEOUT_SECONDS
            res = r.read(out / 'resources.json')
            if record['success']:
                assert res['peak_rss'] <= 4 * 1024**3
                assert res['minimum_available_ram'] >= 256 * 1024**2
            tokens.update(record.get('usage') or {})
            # Reconstruct the exact serializer bytes; this is not a captured stdin stream.
            wire = json.dumps(inp, ensure_ascii=False).encode('utf-8')
            calls.append({'effort': effort, 'group': group, 'success': record['success'],
                'reused_without_inference': reused, 'errors': record['errors'],
                'usage_known': record['usage'] is not None,
                'serializer_stdin_sha256': hashlib.sha256(wire).hexdigest(),
                'serializer_stdin_bytes': len(wire), 'resources': res})
            for p in out.iterdir():
                if p.is_file():
                    seals[str(p.relative_to(r.ROOT))] = r.digest(p)
        usages[effort] = dict(tokens)
    for group in frozen['controls'] + frozen['groups']:
        m = r.RUN / 'results/medium' / group / 'input.json'
        h = r.RUN / 'results/high' / group / 'input.json'
        if m.exists() and h.exists():
            assert r.read(m) == r.read(h)
            assert r.digest(m) == r.digest(h)
            pairs += 1
    mapping = r.read(r.RUN / 'private-answer-map.json')
    assert len(mapping) == len({x['answer_id'] for x in mapping}) == 50
    answer_meta = {x['answer_id']: x for x in mapping}
    old_failed = r.read(c.PARENT / 'results/medium/case-08/record.json')
    assert not old_failed['success'] and old_failed['usage'] is None
    delivered = r.read(r.RUN / 'actual-delivered-source-check.json')
    assert delivered['checked_answers'] == 50 and not delivered['mismatches']
    assert delivered['check_code_sha256'] == r.digest(r.PUBLIC / 'check_answer_revision_delivered_sources_v1.py')
    for check in delivered['checks']:
        assert check['sources_equal']
        original_path = r.ROOT / check['original_input_path']
        assert r.digest(original_path) == check['original_input_sha256']
        original_prompt = r.read(original_path)['prompt'] if original_path.suffix == '.json' else original_path.read_text(encoding='utf-8')
        group = answer_meta[check['answer_id']]['group']
        assert r.read(r.RUN / 'inputs' / (group + '.json'))['question'] in original_prompt
    result = {'version': 2, 'at': r.now(),
        'complete': all((r.RUN / f'{e}-complete.json').exists() for e in ('medium', 'high')),
        'frozen_checks_passed': True, 'freeze_sha256': r.digest(r.RUN / 'freeze.json'),
        'historical_preserved_files': len(r.read(r.RUN / 'preserved-files.json')),
        'all_parent_files_verified': True, 'answers_bound': 50,
        'paired_inputs_including_control': pairs, 'expected_paired_inputs_including_control': 29,
        'paired_input_json_byte_hashes_equal': True,
        'per_call_checks': calls, 'usage_known_tokens': usages,
        'successful_calls': sum(x['success'] for x in calls),
        'reused_calls': sum(x['reused_without_inference'] for x in calls),
        'new_dispatched_calls': sum(not x['reused_without_inference'] for x in calls),
        'total_dispatched_attempts_including_parent_timeout': len(calls) + 1,
        'actual_delivered_sources_verified_for_each_saved_answer': 50,
        'actual_product_input_questions_verified_for_each_saved_answer': 50,
        'source_check_sha256': r.digest(r.RUN / 'actual-delivered-source-check.json'),
        'original_timeout_usage': None, 'unknown_usage_is_not_zero': True,
        'new_product_model_calls': 0, 'paid_api_calls': 0, 'free_resets_consumed': 0,
        'server_revision_verified': False, 'requested_model': r.MODEL,
        'requested_efforts': ['medium', 'high'],
        'source_and_answer_quotes_checked_for_occurrence': True,
        'prompt_length_deviations': length_deviations,
        'length_limit_note': 'Prompt guidance, not enforced in the frozen JSON schema; raw assessments unchanged',
        'semantic_entailment_automatically_proven': False,
        'holdout_accessed': False, 'production_changes': False,
        'stdin_capture_limit': 'Exact bytes reconstructed from frozen serializers, not separately captured',
        'audit_code_sha256': r.digest(__file__)}
    n = 2
    while (r.PUBLIC / f'answer_revision_audit.v{n}.json').exists():
        n += 1
    r.write(r.RUN / f'final-record-seals.v{n}.json', seals)
    r.write(r.PUBLIC / f'answer_revision_audit.v{n}.json', result)
    print(json.dumps({'audit_version': n, 'complete': result['complete'],
                      'pairs': pairs, 'successes': sum(x['success'] for x in calls),
                      'failures': [x['group'] for x in calls if not x['success']]}), flush=True)


if __name__ == '__main__':
    audit()
