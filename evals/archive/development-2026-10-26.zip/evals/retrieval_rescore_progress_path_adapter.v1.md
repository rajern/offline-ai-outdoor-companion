# Offline progress-path compatibility adapter

2026-10-25, after all three controls and25 main assessments completed successfully.
The first summary invocation stopped BEFORE writing a result, on `evals\AGENTS.md`.

The protocol/freeze explicitly allow TASKS.md and evals/AGENTS.md progress updates,
with byte-identical pre-task snapshots. Preparation filtered inherited paths using
forward slashes but the parent manifest stores `evals\AGENTS.md` on Windows.
That one permitted status document therefore incorrectly remained in the immutable
path loop. Diagnostic comparison proves zero changed frozen code/input files and
only this allowed status file differing among inherited paths. No judge received
repository instructions or different data; all sessions ignore rules and have no tools.

The adapter normalizes separators only to identify the TWO EXACT already-allowed
progress documents. Their original snapshot bytes must match the parent manifest;
all other parent files and every originally frozen input/code hash still must
match in place. No broad exclusion, new data exception, rubric/score change or
relaxed resource/timeout rule is introduced. Original freeze, code, failure and
raw results are preserved. This is offline analysis only; no new inference.

The adapter itself, this note and explicit verification result receive a separate
binding file before use. It can invoke the unchanged summary and offline audit
after installing only the corrected preservation check for this process.
