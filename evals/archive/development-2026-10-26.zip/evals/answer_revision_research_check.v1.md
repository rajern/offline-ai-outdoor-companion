# Research cross-check for interpreting the retrospective assessment

Checked 2026-10-24 during the authorized continuation. This is an interpretation
note; the frozen rubrics, judge prompt and running experiment are unchanged.

## What the sources support

[HealthBench's official description](https://openai.com/index/healthbench/)
uses conversation-specific, physician-written criteria and importance weights.
Its [published grader](https://raw.githubusercontent.com/openai/simple-evals/main/healthbench_eval.py)
requires all actual conjuncts while exempting illustrative examples from exhaustive
repetition. This supports distinguishing mandatory actions from examples and
explanation. It does not validate our choice of 63 required items: Outwise has
author-created, retrospectively revised criteria and no equivalent expert panel.
The paper's CDN PDF timed out in this cross-check; the official description and
grader were accessible. Earlier protocol research remains separately documented.

[RAGChecker](https://arxiv.org/abs/2408.08067) separates retrieval and generation
diagnostics using fine-grained claims. This supports recording missing information,
answer coverage and contextual support separately. A criterion can be covered in
an answer while unsupported by its delivered sources; a source can supply a fact
that the answer omits. Neither failure should disappear into one combined score.

OpenAI's [August 2026 evaluation discussion](https://deploymentsafety.openai.com/gpt-5-6-august-update)
explicitly warns that open-ended rubric scores can reward answer length without
equivalent gains in usability or safety, and reports length-adjusted results.
Our interpretation: count coverage as a diagnostic, not the sole optimization
target. Outwise does not currently measure whether a person on a trip can find,
understand and act on the important instruction quickly. No length correction
is retroactively introduced into this paired experiment.

## What the sources cannot establish for Outwise

- They do not establish an achievable ceiling for our quantized local models,
  Norwegian questions, source packing, prompt and hardware. Cross-benchmark
  percentages have different populations, rubrics and denominators.
- They do not justify lowering requirements until a chosen model passes, or
  declaring an arbitrary coverage percentage safe for first aid.
- They do not make a High assessment ground truth. Judge agreement, exact quote
  occurrence and schema validity are weaker than correct semantic judgment.
- They do not validate the source corpus's clinical currency or licensing.
  Checking an answer against delivered text is a narrower claim.

The appropriate immediate use of this experiment is to identify how much the
reported result depends on requirement wording and judge interpretation, while
preserving concrete omissions and incorrect additions. Any later product or
safety-policy choice remains an owner decision under M2-06/M3 boundaries.
