"""Verify each assessment's sources against each product answer's actual input."""
from pathlib import Path
import re

import answer_revision_continue_v1 as c

r = c.r


def check():
    rows = []
    newer = r.read(r.PUBLIC / 'local_generation_comparison_results.v1.json')['rows']
    for meta in r.read(c.TARGET / 'private-answer-map.json'):
        inp = r.read(c.TARGET / 'inputs' / (meta['group'] + '.json'))
        folder = r.ROOT / Path(meta['answer_path']).parent
        ids = [b['passage_id'] for b in inp['blocks']]
        if meta['model'] == 'historical-qwen':
            path = folder / 'prompt.txt'
            actual = r.sources_from_prompt(path, ids)
        else:
            path = folder.parents[2] / 'preflight' / meta['model'] / 'inputs' / (meta['group'] + '.json')
            native = r.read(path)
            binding = next(x['binding'] for x in newer if x['id'] == meta['group'] and x['model'] == meta['model'])
            assert r.digest(path) == binding['native_input_sha256']
            request = r.read(folder / 'request.json')
            assert request['prompt'] == native['tokens']
            context = native['prompt'].split('[KILDEUTDRAG]\n', 1)[1].split('\n[/KILDEUTDRAG]', 1)[0]
            assert r.hashlib.sha256(context.encode('utf-8')).hexdigest() == binding['context_sha256']
            blocks = re.findall(r'\[KUNNSKAPSUTDRAG (\d+)\]\n(.*?)(?=\n\[KUNNSKAPSUTDRAG |\Z)', context, re.S)
            assert len(blocks) == len(ids)
            actual = [{'block': int(i), 'passage_id': pid, 'text': body.strip()}
                      for (i, body), pid in zip(blocks, ids)]
        assert actual == inp['blocks'], meta['answer_id']
        rows.append({'answer_id': meta['answer_id'], 'sources_equal': True,
                     'original_input_path': str(path.relative_to(r.ROOT)),
                     'original_input_sha256': r.digest(path)})
    r.write(c.TARGET / 'actual-delivered-source-check.json', {
        'at': r.now(), 'checked_answers': len(rows), 'checks': rows, 'mismatches': [],
        'check_code_sha256': r.digest(__file__)})
    print({'checked_answers': len(rows), 'mismatches': []}, flush=True)


if __name__ == '__main__':
    check()
