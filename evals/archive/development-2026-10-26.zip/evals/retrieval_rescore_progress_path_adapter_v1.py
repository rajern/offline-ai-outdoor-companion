"""Normalize only the two explicitly allowed progress-file identities; no inference."""
from pathlib import Path
import sys

import rescore_retrieval_locked_v1 as s

r = s.r
NOTE = s.PUBLIC / 'retrieval_rescore_progress_path_adapter.v1.md'
BINDING = s.RUN / 'progress-path-adapter-binding.json'


def verify():
    frozen = r.read(s.RUN/'freeze.json')
    assert frozen['allowed_progress_document_changes'] == ['TASKS.md','evals/AGENTS.md']
    for name, expected in frozen['hashes'].items():
        assert r.digest(s.ROOT/name) == expected, name
    parent_seals = r.read(s.PARENT/'closeout-seals.json')['hashes']
    allowed = set(frozen['allowed_progress_document_changes'])
    snapshots = {}
    for name, expected in parent_seals.items():
        normalized = name.replace('\\','/')
        if normalized in allowed:
            snapshot = s.RUN/'before'/Path(normalized)
            assert r.digest(snapshot) == expected, name
            snapshots[normalized] = {'original_sha256':expected,
                'snapshot_sha256':r.digest(snapshot), 'current_sha256':r.digest(s.ROOT/name)}
        else:
            assert r.digest(s.ROOT/name) == expected, name
    assert set(snapshots) == allowed
    # The original check's input/code and denominator validation remain in force.
    required = conditional = gaps = 0
    for meta in r.read(s.RUN/'case-map.json'):
        inp = r.read(s.RUN/'inputs'/(meta['context_id']+'.json'))
        old = r.read(s.PARENT/'inputs'/(meta['case_id']+'.json'))
        assert inp['blocks'] == old['blocks'] and inp['question'] == old['question']
        assert r.canonical(inp) == meta['input_sha256']
        if inp['expected_result']=='supported_context':
            required += sum(x['classification']=='required' for x in inp['criteria'])
            conditional += sum(x['classification']=='conditional' for x in inp['criteria'])
        else:
            gaps += 1
    assert (required,conditional,gaps) == (63,4,3)
    return frozen,snapshots,len(parent_seals)-len(allowed)


def prepare():
    frozen, snapshots, count = verify()
    r.write(BINDING, {'at':r.now(),'freeze_sha256':r.digest(s.RUN/'freeze.json'),
        'adapter_sha256':r.digest(__file__),'note_sha256':r.digest(NOTE),
        'parent_manifest_sha256':r.digest(s.PARENT/'closeout-seals.json'),
        'immutable_parent_files_in_place':count,'allowed_progress_snapshots':snapshots,
        'original_summary_failure':'AssertionError evals\\AGENTS.md; no summary written',
        'new_inference_calls':0,'raw_scores_changed':False})
    print({'adapter_prepared':True,'immutable_parent_files':count,'original_progress_snapshots':2},flush=True)


def check_freeze():
    binding = r.read(BINDING)
    assert r.digest(__file__) == binding['adapter_sha256']
    assert r.digest(NOTE) == binding['note_sha256']
    assert r.digest(s.RUN/'freeze.json') == binding['freeze_sha256']
    frozen, snapshots, count = verify()
    assert count == binding['immutable_parent_files_in_place']
    return frozen


if __name__ == '__main__':
    action = sys.argv[1]
    if action=='prepare':
        prepare()
    else:
        s.check_freeze = check_freeze
        if action=='summarize':
            s.summarize()
        elif action=='audit':
            import audit_retrieval_rubric_rescore_v1 as a
            a.audit()
        elif action=='check':
            check_freeze()
            print('All immutable files and both original progress snapshots verified.')
        else:
            raise ValueError('Offline actions only')
