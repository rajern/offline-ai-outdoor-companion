"""Workspace-only temporary transport; original pre-dispatch stop is preserved.

The Windows sandbox temp root accepted directory creation but denied writing the
instruction file. No CLI command or inference was dispatched. This adapter changes
only the temporary-directory location; all prompts, inputs and judging rules match.
"""
from contextlib import contextmanager
import sys
from pathlib import Path

import answer_rubric_revision_v1 as r

ORIGINAL_RUN = r.RUN
TARGET_RUN = ORIGINAL_RUN / 'transport-v2'
TEMP_ROOT = TARGET_RUN / 'temp'
original_temporary_directory = r.tempfile.TemporaryDirectory


@contextmanager
def workspace_temporary_directory(**kwargs):
    TEMP_ROOT.mkdir(parents=True, exist_ok=True)
    obj = original_temporary_directory(dir=TEMP_ROOT, **kwargs)
    target = Path(obj.name).resolve()
    assert target.is_relative_to(TEMP_ROOT.resolve()) and target != TEMP_ROOT.resolve()
    try:
        yield str(target)
    finally:
        # Resolved cleanup target verified inside the dedicated workspace temp root.
        obj.cleanup()


def prepare():
    original = r.check_freeze()
    stopped = ORIGINAL_RUN/'results/medium/control-equipment'
    assert (stopped/'intent.json').exists()
    assert not (stopped/'command.json').exists()
    assert not (stopped/'stdout.jsonl').exists()
    if TARGET_RUN.exists(): raise RuntimeError('Transport already prepared')
    for name in ('private-answer-map.json','control-expected.json','preserved-files.json'):
        r.write(TARGET_RUN/name, r.read(ORIGINAL_RUN/name))
    for path in (ORIGINAL_RUN/'inputs').glob('*.json'):
        r.write(TARGET_RUN/'inputs'/path.name, r.read(path))
    frozen = {**original, 'transport_prepared_at':r.now(),
              'parent_freeze_sha256':r.digest(ORIGINAL_RUN/'freeze.json'),
              'transport_change':'Windows sandbox temp write denied before dispatch; workspace temp only',
              'parent_dispatched_calls':0}
    frozen['hashes']={**original['hashes'],str(Path(__file__).relative_to(r.ROOT)):r.digest(__file__)}
    for path in (TARGET_RUN/'inputs').glob('*.json'):
        frozen['hashes'][str(path.relative_to(r.ROOT))]=r.digest(path)
    r.write(TARGET_RUN/'freeze.json',frozen)
    print('Prepared workspace-only transport; original pre-dispatch stop retained.',flush=True)


if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare': prepare()
    else:
        r.RUN=TARGET_RUN
        r.tempfile.TemporaryDirectory=workspace_temporary_directory
        if action=='summarize': r.summarize()
        else: r.run(action)
