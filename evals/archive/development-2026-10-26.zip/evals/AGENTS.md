# Retrieval evaluation boundaries

Latest owner reference COMPLETE, 2026-10-25: eight Sol High answers, eight locked
Medium assessments. GPT13/15 core,13/13 fully delivered retained, all13 full
source-supported; two partial match retrieval gaps08/r4 and21/r2. Four of six
core-complete cases, both conditional requirements full, safe gaps2/2. No raw
unsupported/direct-conflict/critical-omission flags; one requires_review for
missing source branch08. All8 texts/17 revised decisions/finding lists reviewed;
raw scores unchanged. Local baselines Qwen8/15 and8/13, Gemma6/15 and6/13 reused.
See large_model_reference_report.v2.md, results/review/audit/execution v1.
Current private run: large-model-reference-v1-2026-10-25/continuation-v2.
Four initial High successes reused byte-identically; four new High successes.
Nine generation CLI attempts total includes original failed21 of unknown usage.
Eight unique judge CLI attempts;19 completed after24s429 but v1 watcher killed
shutdown by re-reading OLD warning. Separate frozen state correction/source/raw
validation recovered19 without inference; original false record/nonzero exit kept.
Judge23 succeeded after one143s429 backoff. Pacing min60.008s; commands/settings
and guards unchanged. Known success usage>=129332 tokens, failed prior usage
unknown; no paid API/reset. Four original plus two transport test methods and
offline checks pass;1270 prior protected files plus continuation bindings intact.
High/CLI versus local thinking-off, absent seed/512 cap, selected screen8 and
same-family judge limit causal/clinical claims. STOP here for owner next-step
decision. No further generation/judges, retrieval, holdout, production integration,
safety-policy change or M3. This does not establish a small-model ceiling or
approve M2-06 quality. Preserve original report v1 and both technical stops.

Latest owner task STOPPED, 2026-10-25: GPT-6.1 Sol High reference has4/8 sealed
answers (19,05,08,17). Fifth CLI attempt21 hit HTTP429; internal retry/backoff
was cancelled by terminating only exact owned High CLI process. No completed21
text/usage to recover.23/15/25 not started, zero new Medium judges, no overall
score. Ordinary subscription use remains allowed (12% five-hour /18% weekly used),
so exhausted quota is NOT established;429 origin/duration unknown. Preserve all
five attempts/raw logs and stopped run. Reuse four sealed answers without new
inference. Any resume needs a separate documented continuation for failed21 and
the original8-call limit; do not silently retry/reset or regenerate successes.
See large_model_reference_report.v1.md, partial_results v1, protocol and runner.
Private run: large-model-reference-v1-2026-10-25. Four tests and offline partial
integrity checks pass;1270 parent files preserved. Known success tokens28842;
interrupted usage unknown, never zero. Same input/prompt, High/CLI wrapper and
unavailable seed/512 cap remain declared limitations; judge remains Medium.
No paid API/reset, retrieval/local regeneration, holdout, full25, production,
safety-policy change or M3. M2-06 quality remains open.

Latest owner task COMPLETE, 2026-10-25: bounded local generation improvement,
32 new answers, eight successful sequential Sol Medium calls/100458 reported
tokens. Latest16 baseline judgments reused; rubric/evaluator/sources unchanged.
Screen8 core/retained: Qwen baseline8/15 and8/13, sampler A2/15 and2/13, prompt
B3/15 and3/13. Gemma baseline/A/B each6/15 and6/13; gap abstention2/2,2/2,0/2.
No clear overall improvement: Gemma A trades filter coverage for electrical-warning
loss; B loses abstention and composes unsafe branches. All32 source-reviewed,
60 core/8 conditional decisions and finding/gap lists checked; raw scores intact.
Four caveats remain separate. Five tests and final audit pass;745 protected files
unchanged, all native-input/setting/hash/resource checks pass. Original WinError2
path and revision-02 WinError10013 loopback stops have zero completion dispatches
and remain immutable; separately frozen adapters, unchanged guards. Private run:
local-generation-improvement-v1-2026-10-25/revision-03. See improvement report,
results/review/audit v1. No paid API/reset, new retrieval, holdout, full25, GPT
generation, production/safety-policy changes or M3. STOP here for owner next-step
decision. No automatic A+B, parameter hunt, new seed/model, integration or larger
model comparison. M2-06 quality remains unapproved.

Latest owner task COMPLETE, 2026-10-25: agreed steps1/2 only. Unchanged answer
rubric v1 locked (63 core), Sol Medium evaluator. All three controls passed before
25 SAVED primary contexts were re-assessed. New raw coverage55/63 (87.3%), four
partial/four absent,16/22 core-complete cases; conditional inventory3full/1absent.
Historical Qwen full25 preserves13/55 available (23.6%); matched-screen8 older
Qwen4/13, newer Qwen8/13, Gemma6/13. These are criterion-coverage measures, not
whole-answer quality or safety. Main69 criterion decisions and25 finding lists
reviewed, raw scores unchanged. Potentially misleading flags08/13 remain uncertain
in applicability; old answer-review caveats remain. No autonomous winner selected.
See evaluation_lock.v1.md, retrieval_rubric_rescore_report/results/review/audit.v1.
Private run: retrieval-rubric-locked-v1-2026-10-25;28 successful sequential calls,
250614 known tokens, no retries/resets/paid API. First offline summary hit an
allowed-progress-path separator bug; use retrieval_rescore_progress_path_adapter_v1.py
for check/summarize/audit. Original freeze/code/logs preserved;485 parent files
unchanged in place, both old progress documents snapshotted. Never rerun inference
to repair metadata. No searches, diagnostic re-scoring, product answers, GPT
generation, holdout, integration, production/safety-policy changes or M3 performed.
STOP here; later local improvement/GPT comparison need separate owner tasks.

Latest owner task COMPLETE, 2026-10-24: retrospective rubric review and paired
gpt-6.1-sol Medium THEN High on all 50 SAVED answers. The owner-authorized one-shot
21:15 continuation documented a 1,200s timeout for new calls before dispatch;
transport-v3's nine successes /12 saved answers were reused byte-identically.
All 58 planned successful calls (29 per effort including control) are sealed;
49 new calls, plus the retained old 420s timeout =59 dispatched attempts total.
Old timeout usage remains unknown. No reset or paid API. One-shot automation deleted.
See answer_revision_report.v2.md, results v3, analysis/review v1 and audit v2.
Current private run is answer-rubric-revision-v1-2026-10-24/continuation-v1;
all parent logs, old gold/rubrics/scores, production and M3 remain unchanged.
All 18 criterion/support disagreements,35 agreed high-consequence pairs and50
finding/gap pairs reviewed; no raw corrections. High preferred in7 points,
Medium5, unresolved5, neither1; not independent clinical gold or a clear winner.
Main historical full25: old12/72 M,11/72 H; new13/63 M,12/63 H, zero core-complete
of22. Matched screen8 both: new Qwen8/15, Gemma6/15 core; Qwen has many more
unsupported additions and no safe gap abstentions, Gemma2/2. Diagnostics7/8 each
new model do not establish full-app quality or a model-size ceiling.
Stop here for owner scope/quality decision. No further judges, rubric/prompt
tuning, retrieval, product generation, integration or M3 are automatically authorized.
Preserve both the original partial report v1 and all unsuccessful attempts.

Current stop: bounded generation comparison COMPLETE, 2026-10-24. 22 new local
responses (11 2B +11 Gemma), all executed generation resource guards passed.
4B is excluded on proven RSS limit, not quality. Source review on identical
screen8 finds 2B 4/19, Gemma 6/19 full; old same subset 2/19. Gemma abstains in
both screened corpus gaps, 2B does not. Both omit delivered critical assessment
in primary08 and are NOT eligible for finalist; no 25-call finalist or tuning.
See report v3, comparison results v1 and final audit v1. Original full25 remains
15/72 answer coverage, 60/72 retrieval; do not mix denominators or claim safety.
Metadata-only adapter recovers original first response without repeat and uses
actual /props to verify n_ctx; original stop/raw/code freeze plus adapter binding
are preserved. No prompt/gold/retrieval changes or paid API/Codex judge calls.
Stop here for owner prototype/model/safety-scope decision. Do not automatically
integrate Gemma, source-procedure policy, production retrieval or M3. No holdout.

Current authorized screening, 2026-10-24: newest explicit retry has host reserve
intact but Qwen 4B + MiniLM RSS >4 GiB, so exclude 4B under the frozen protocol's
existing resource-incompatibility rule. Not a model-quality comparison/result.
2B inherited checks and Gemma official QAT Q4_0 36-input preflight pass. Use
run_eligible_local_generation_v1.py and local-generation-eligible-2026-10-24.
Freeze all eligible models/settings/code/native tokens before any response;
then at most 22 screening calls (11 each). Finalist conditional <=25 remains.
Preserve all prior stops, frozen prompts/gold and actual contexts. No holdout,
paid API, production changes or M3. See execution v1 and original protocol.

Latest explicit retry, 2026-10-24 (owner: "prøv igjen"): inherited and verified
successful 2B checks + 4B download; separate retry again breached available-host
RAM (158.79 MiB <256 MiB; sampled RSS 749.08 MiB). Zero responses; own server
terminated. Earlier partial loading RSS is not the full model footprint. See
local_generation_comparison_retry.v1.md/JSON and continue_local_generation_v1.py.
Keep this stop and the older attempts. No automatic retry or scope reduction.

Latest owner resume/stop, 2026-10-24: successful 2B native-template preflight on
all 36 frozen inputs (777–2,233 actual tokens, slot 4,096, output reserved 512).
Host reserve passed for resident MiniLM + 2B (min 1,087.68 MiB; peak RSS
2,570.20 MiB). Exact approved Qwen 4B Q4_K_M downloaded and SHA verified; its
load hit host RAM 148.07 MiB <256 MiB, peak RSS 3,898.40 MiB <4 GiB. Zero new
generated responses. Preserve the successful 2B checks and 4B stop under
local-generation-comparison-v1-2026-10-11/resume-2026-10-24/revision-02.
No Gemma download or new comparison scores. See comparison report/audit v2 and
resume_local_generation_v1.py. The initial resumed metadata stop is also retained:
runtime props omit training context, so the technical adapter reads actual GGUF
metadata instead, without altering input definitions, prompt or model. Complete
model/runtime freeze and inference execution remain pending after sufficient RAM.
Do not auto-retry after the new host-memory breach, discard logs, exclude 4B as
permanently incompatible, or rerun old answers. No production/holdout/M3 changes.

Current generation-comparison stop, 2026-10-11: owner authorized one bounded
three-model comparison and amended only generation input to 3,200 native-template
tokens (runtime 4,096, output 512). See local_generation_comparison_protocol.v1.md,
prompt v1, preflight launcher and report/audit v1. All 36 planned input definitions
were frozen before any new answer. Existing 2B + resident MiniLM preflight breached
the original 256 MiB host reserve (140.72 MiB observed; RSS 748.72 MiB <4 GiB).
Zero new inference, no downloads or paid API. Runtime/template/token checks and
the comparison are pending; this is a host-memory block, not a quality result or
proof that any candidate cannot fit. Do not automatically retry the failed load.
Preserve original stop and revision-02 input-freeze/logs before owner resume.
Revision-01 technical stop used raw CRLF file hash instead of logical LF CLI-input
hash; revision-02 fixes this and verifies old seals without changing old inputs.
The new protocol supersedes earlier generation restrictions only for this owner
task. Historical retrieval/gold/judge/results stay unchanged; no holdout, new
retrieval experiments, production replacement, final safety policy or M3.

Current system-test stop, 2026-10-11: 25 baseline + three bounded local Qwen
sufficient-context diagnoses complete; all original resource guards passed.
See qwen_rag_system_report/results/audit.v1 and separate answer review. All 25
fresh query/ranking/P3 prompts exactly equal saved T-ranking contexts. Source
metadata matches via the actual API; four current-app probes ran without Qwen.
Answers show critical generation errors even with sufficient source context;
M2-06 quality is not approved. Owner manual review and further bounded generation
work require the next task; do not repeat completed answers, judge T-combined,
start new retrieval experiments, change production, open holdout or start M3.
Case16 historical review remains unchanged; generated-answer findings are separate.
First pre-inference Windows socket stop and its freeze remain preserved; use the
separately frozen qwen_system_windows_adapter_v1.py only for exact sealed reuse.

Current owner task, 2026-10-11: retrieval optimization is paused. Do not judge
T-combined or run additional retrieval experiments. One isolated local Qwen/RAG
system baseline on the existing 25 development questions is authorized within
M2-06, using MiniLM T-ranking/k16/no threshold/original P3 and <=2,000 complete
prompt tokens. Use existing Qwen3.5-2B Q4_K_M ModelService settings and freeze a
separate answer-assessment method before evaluation. Preserve all historical
retrieval results, gold, V3 scorer and source snapshot. Case16 remains
requires_review; it does not block isolated system testing but must be resolved
or explicitly handled before final owner quality approval. Existing RAM guards
apply with retrieval and Qwen concurrently loaded. Bounded sufficient-context
Qwen diagnostics may be recorded separately. No holdout, paid API, production
replacement, final safety policy or M3. Do not mark M2-06 complete. Earlier stops
and generation restrictions below are historical, superseded only within this
new authorized scope. See qwen_rag_system_protocol.v1.md.

Current targeted stop, 2026-10-10: two variants are fully scored (50/75 rows).
T-ranking: 60/72, 83.33% micro, 81.14% macro, 15/22 complete; legacy15
42/51, 79.62% macro, 8/13 complete. T-packing: 50/72, 69.44% micro,
71.89% macro, 12/22 complete; legacy15 34/51, 69.10% macro, 6/13 complete.
Ranking gains only03/5 and loses none. Packing gains13/1-2 and21/2, but loses
01/4,05/3+6,06/4,07/1-3,08/2,10/2,19/1,23/2-3. All gains/losses have
source review. New misleading flags08/16/17 are reviewed separately from raw
counts;16 is not a proven new hazard, because identical source-02-007/008
instructions appear in baseline/ranking without that flag. The significance of
whole-context changes versus judge interpretation remains unresolved under V3.
`retrieval_targeted_review_required.v1.json` records exact three-input bindings
and requires a consistent scope/risk ruling before further scoring/selection.
Stop before T-combined inference; its 25 guarded contexts are already saved.
No new general judge tests, prompt/gold edits or automatic adjudication.
Fifty successful subscription calls, 511,921 tokens, one cached reuse of the
first answer after metadata repair; no quota rejection or paid API. Guarded
judge phases passed RAM/RSS. Shared quota at stop: 84% five-hour /97% weekly; final report snapshot
88% /98%. Additional account usage is not attributed to judge calls.
No final recommendation or holdout readiness. Preserve all frozen records.
After owner resolution and explicit resume, only combined scoring remains;
use targeted_scoring_metadata_v1.py, retaining the 50 results and 75 contexts.

Targeted scoring checkpoint, 2026-10-10: T-ranking is complete, 25/25.
60/72 supported requirements (83.33% micro, 81.14% macro), 15/22 complete;
legacy15: 42/51, 79.62% macro, 8/13 complete. Gain is only case03/5,
confirmed against delivered source-21-009. No covered-item losses or new risk
flags; 22 irrelevant, one misleading (case13), no conflict/geography/review.
Burn07 and cases04/05 remain fully covered. Twelve supported requirements
remain missing, including fracture, boiling times, major-bleeding113, full
breathing/CPR, beacon, anaphylaxis and water-product instruction.
Judge guard passed: min available RAM 3,950.18 MiB / peak RSS 164.24 MiB.
T-packing scoring has started with the same frozen metadata adapter; combined
not scored. Shared quota after ranking: 63% five-hour / 94% weekly used.
This is a partial comparison, not a final selection or holdout readiness.

Technical metadata repair, 2026-10-10: first targeted subscription answer is
sealed, but original merge stopped before saving a score on missing diagnostic
`section_count`. `targeted_scoring_metadata_v1.py` supplies only that count from
actual delivered document/section pairs before the unchanged proof function.
Original rows/contexts, frozen methods, judge inputs/cache identity and scorer
rules remain unchanged. Adapter/tests plus all 75 retrieval inputs are separately
hash-bound under revision-02/scoring-metadata-v1. Seven tests pass, including
old-scorer equivalence and merge of the saved answer; no repeated inference.
Use this compatibility launcher for remaining score commands. Offline audit
installs it only after verifying its binding. Original metadata stop and resource
attempt are preserved. No score-driven changes or new experiments are authorized.

Owner-authorized resume, 2026-10-10: all 75 targeted contexts are now complete
and pass offline source/prompt/blinded-adapter audit. Original 3,193 experiment
files and 4,188 superseded technical files remain unchanged. Ranking reused its
first 22 contexts; packing reused all 25; combined created its 25 contexts.
Resumed ranking minimum available RAM 4,276.43 MiB / peak RSS 183.14 MiB;
combined minimum available RAM 3,824.18 MiB / peak RSS 185.48 MiB. All complete
prompts are <=2,000 tokens. Preserve the earlier failed resource attempt.
Scoring is proceeding sequentially with the frozen subscription judge. No exact
prior cache records match the 75 inputs; shared weekly quota was 90% used before
resume. Stop on quota or scorer disagreement; review source risks before any
recommendation. This status supersedes only the RAM stop below.

Latest targeted stop, 2026-10-10: revision-02 MiniLM window index passed input
checks (568 views, no body truncation) and build guards (279.96 MiB minimum
available RAM). Corrected ranking retrieval saved cases 01–22 before available
RAM fell to 241.41 MiB, below the unchanged 256 MiB reserve; process-tree RSS
peaked at 185.45 MiB, below 4 GiB. Do not relax the guard or auto-retry.
No new judge call was attempted. Packing has 25 exact reused contexts; combined
has none. All 47 current contexts, 3,193 original experiment files and 4,188
superseded pre-scoring files pass offline audit; blinded adapter/context checks
pass on all 47 without inference or new tokenization. See targeted report,
comparison, audit and preflight source-review v1 files. Source review already
finds packing drops burn first-aid source-03-006 and reintroduces P1's generic
GP/anaphylaxis passage source-08-011; no coverage points or new adjudications
were assigned. New variants have no comparable quality scores or recommendation.
After sufficient RAM is available and the owner resumes, use the same frozen
`run_targeted_retrieval_v1.py run`; reuse index/47 contexts, finish three ranking
contexts and all combined contexts, then score only after all input guards pass.
Preserve the failed resource log and review source risks before recommendation.

Owner task, 2026-10-10: after reviewing the proposed targeted improvement round,
the owner explicitly said "implementer det og kjør". This authorizes at most
three separate MiniLM/k16/no-threshold experiments beyond the completed 31:
window-mean ranking with P3, scope-diverse packing with original ranking, and
their preplanned combination. All three are frozen together before evaluation.
See `retrieval_targeted_plan.v2.md`, `retrieval_targeted.v2.json` and
`run_targeted_retrieval_v1.py`. Runtime storage is separate under
`knowledge/local/diagnostics/retrieval-targeted-v1-2026-10-10`.
Technical revision-02 repairs header/body separation before any fresh judgment;
the first revision's 75 unjudged contexts/code snapshots remain unchanged.
Packing-only contexts are reused after identical packing-function checks.
Original 31 contexts, scores and adjudication layers remain immutable. Same gold,
sources, V3 judge, subscription authentication, 2,000-token prompt and resource
limits apply. Check every coverage loss and new safety flag before recommending.
Unresolved scorer/safety/resource/quota blockers stop continuation. No holdout,
production integration, paid API, answer generation or further experiments.
The prior "no additional experiments" status below is superseded only for this
new bounded owner task; it remains the historical end of the original plan.

Final development status, 2026-10-10: all 31 planned configurations / 775 case
judgments completed on 2026-10-09. The owner-authorized resume skipped P1;
P2 reused all 25 exact B16 inputs, P3 used 15 new calls / ten cache hits.
P2/P3 passed unchanged RAM/RSS guards. Historical P1 RAM failure remains failed.
Offline audit v3 passes all 775 inputs, 82 frozen identities, 2,912 A/B files
and 103 unchanged P1 files. See `retrieval_optimization_report.v7.md` and
`retrieval_optimization_final_audit.v3.json`. P3 (59/72, macro 80.23%, 15/22)
is recommended only as a provisional development baseline. P1 has highest
coverage (63/72, 17/22) but loses burn items 07/1-3 and introduces anaphylaxis
conflict. P3 still lacks 13 supported requirements; no control-test readiness,
final production choice or automatic C dominance winner is established.
No additional experiments, holdout access, production change or answer generation
is authorized. Stop after the final report; obtain a separate owner task for
further retrieval development. Prior reports/audits v6/v2 remain unchanged.
To refresh the final report without reading historical v6, use
`report_phase_c_v1.py --version 7 --source evals/retrieval_optimization_results.v7.json`.
The statuses below record earlier stops, not current pending execution.

Current stop, 2026-10-09: the owner explicitly authorized MiniLM/k16/no threshold
for C and a limited B-to-C dominance override. Exact-input review resolved case
13/P70 risk negatives and case 19's inconsistent interpretation of a supplied
ice-rescue sequence; only risk flags change in six B rows / three unique inputs.
See `retrieval_phase_c_safety_review.v1.md` and the separately frozen registry.
`continue_retrieval_phase_c_v1.py` preserved A/B and ran C-P1: all 25 judgments
are saved (24 fresh subscription calls, one cache hit), 63/72 coverage, macro
85.23%, 17/22 complete. Host available RAM fell to 52.42 MiB against the unchanged
256 MiB reserve; peak judge process-tree RSS was 231.53 MiB, below 4 GiB.
Offline integrity audit passed 725 saved case results, 82 frozen identities and
2,912 protected A/B files without inference; see `retrieval_optimization_final_audit.v2.json`.
The post-worker resource guard failed. C-P2/C-P3 have not started; 29/31 are
fully scored, not a completed resource-approved comparison. P1 gains eight
requirements but loses burn items 07/1-3 and introduces anaphylaxis risk/conflict.
See `retrieval_optimization_report.v6.md`. No final winner or control-test
readiness is established. After the RAM blocker is resolved and the owner asks
to resume, use the same C continuation; it verifies/skips C-P1 and never repeats
A/B or completed judge calls. Preserve the failed resource sample. All frozen
gold/prompt/packing and production/holdout/generation restrictions still apply.
Earlier continuation statuses below are history, not present approval gates.

Latest continuation status, 2026-10-09: all 25 MiniLM phase-B configurations
are complete (625 judgments); 28/31 configurations including A. C has not run.
RAM checks passed after owner-authorized resume with unchanged limits. One
quota rejection was retained in a hashed archive and retried only after natural
quota renewal and a new owner resume instruction; completed answers were reused.
The original stage-B dominance gate stopped selection. Source review finds
unresolved case-13 risk negatives at P70 despite unchanged generic 113 advice,
and case-19 risk variability despite identical rescue advice. See
`retrieval_optimization_report.v5.md` and `retrieval_optimization_final_audit.v1.json`.
MiniLM k16/no threshold is recommended provisionally as the experimental C
candidate, not selected or approved for production. Obtain a context-bound risk
resolution and explicit experimental B choice/limited gate override before C.
Do not repeat A/B, change frozen gold/judge/packing, or open holdout. Earlier
progress/stops below are historical; their scope restrictions remain applicable.

Owner task, 2026-10-08: the existing 25 development cases and conditional 31-step
optimization are authorized after the specified scorer/runtime prechecks. This
supersedes the preparation-only scope below; original gold/references remain
immutable. Subsequent bounded diagnostics resolved the Qwen repeatability blocker
with explicit CPU isolation; see `qwen_embedding_stability_report.v1.md`. The
owner subsequently authorized resuming the existing 31 configurations after
technical/resource checks, without intermediate approvals. The resumed task
initially stopped before phase A at the available-RAM guard. After the owner freed
RAM, all three sequential resource/input probes passed with the original limits.
The 25 MiniLM contexts were preserved after a one-line correction for missing
source defaults; see `retrieval_optimization_serialization_correction.v1.json`.
Phase A completed all three configurations / 75 judgments. The integrity audit
passed without inference. Stage selection stopped on real per-item coverage and
safety tradeoffs; case 13 additionally needs semantic review. See
`retrieval_optimization_report.v3.md`. B/C are not run. Do not repeat A or modify
gold/judge based on results; obtain the owner's provisional model decision and
case 13 review before advancing. Finalist review remains unfinished. Holdout,
production changes and answer generation remain excluded.

Owner review task, 2026-10-09: the offline model-selection review is complete;
see `retrieval_embedding_selection_review.v1.md` and its evidence JSON. MiniLM
is recommended only as the experimental phase B candidate. Full breathing/CPR
support in case 08 and anaphylaxis support in case 17 are unreachable with its
frozen top-16/section rules. Case 13 Gemma risk and case 20 MiniLM coverage have
separate proposals in `retrieval_embedding_selection_adjudication.proposed.v1.json`;
they are NOT active scoring rules. Original judgments/gold/cache remain unchanged.
Do not treat the recommendation or proposals as the owner's decision. Stop here
until the owner selects the model and resolves the proposed adjudications; do not
repeat phase A or start B/C from this review alone.

Owner continuation, 2026-10-09: MiniLM is explicitly selected as the experimental
B/C model. Both case 13 Gemma risk and case 20/1 MiniLM semantic coverage are
approved in `retrieval_embedding_selection_adjudication.approved.v1.json`.
Use `continue_retrieval_optimization_v1.py` to resume the remaining 28 planned
configurations; it preserves the original frozen scorer, raw scores and cache,
and writes separate exact-input-bound adjusted summaries. Do not repeat A.
Ordinary B/C phase transitions need no new approval; real resource, review or
per-case safety tradeoffs still block selection. This supersedes the preceding
pending-owner status. No production approval is given.

Continuation stopped after B-k3-none's 25 saved judgments: available host RAM
fell to 5.65 MiB below the unchanged 256 MiB reserve; score-worker process-tree
RSS was only 230.2 MiB. All results/seals and 309 phase-A files pass final audit.
One of 28 B/C configurations is fully scored (40/72, 8/22 complete, two misleading
flags); 27 remain. See `retrieval_optimization_report.v4.md` and the continuation
audit. No B/C winner is selected. After the resource blocker is resolved, resume
the same continuation command; it skips completed A and B-k3-none model calls.

Read `FOUNDATION.md` before future retrieval optimization. Default input is the
25-case development set, never the control set. Do not recursively read/search
`evals/holdout/` or include its files in optimizer context, calibration, debugging
or experiment selection. Its local AGENTS.md defines the final-run approval gate.
The holdout author knew its cases; these are process controls, not true blinding.

This preparation task authorizes source-only gold QA and scoring calibration on
ALREADY SAVED historical contexts, not fresh retrieval runs, model/parameter/
packing experiments or production changes. New cases/scorer are pending owner
approval. Unknown automatic decisions are not semantic failures and must not be
used to choose a winner. Preserve original 15 cases and historical outputs.

Development aggregate comparisons must also retain the unchanged legacy-15 slice;
do not compare a 25-case score with a historical 15-case score as if populations
were equal. Noise, jurisdiction and size remain separate from coverage.
