"""Re-assess saved primary sources only; no search or product generation."""
from collections import Counter
import json
from pathlib import Path
import shutil
import sys
import tempfile

import answer_revision_continue_v1 as parent

r = parent.r
ROOT = r.ROOT
PUBLIC = ROOT / 'evals'
PARENT = parent.TARGET
RUN = ROOT / 'knowledge/local/diagnostics/retrieval-rubric-locked-v1-2026-10-25'
PROMPT = PUBLIC / 'retrieval_rubric_judge.v1.md'
PROTOCOL = PUBLIC / 'retrieval_rubric_rescore_protocol.v1.md'
LOCK = PUBLIC / 'evaluation_lock.v1.md'
TIMEOUT = 1200
MODEL = 'gpt-6.1-sol'
EFFORT = 'medium'


def obj(properties):
    return {'type':'object', 'properties':properties, 'required':list(properties), 'additionalProperties':False}


def schema():
    text = {'type':'string'}
    evidence = obj({'block':{'type':'integer'}, 'quote':{'type':'string','minLength':1,'maxLength':600}})
    item = obj({'id':text, 'decision':{'type':'string','enum':['full','partial','absent','uncertain']},
        'evidence':{'type':'array','items':evidence}, 'missing_components':{'type':'array','items':text},
        'reason':{'type':'string','minLength':1}})
    finding = obj({'type':{'type':'string','enum':['irrelevant','potentially_misleading','direct_conflict','geography','requires_review']},
        'evidence':{'type':'array','items':evidence,'minItems':1}, 'reason':{'type':'string','minLength':1}})
    return obj({'context_id':text, 'items':{'type':'array','items':item}, 'findings':{'type':'array','items':finding}})


def validate(value, inp):
    errors = [x.message for x in r.Draft202012Validator(schema()).iter_errors(value)]
    if errors:
        return errors
    if value['context_id'] != inp['context_id']:
        errors.append('context ID mismatch')
    expected = sorted(x['id'] for x in inp['criteria'])
    if sorted(x['id'] for x in value['items']) != expected:
        errors.append('criterion IDs missing or duplicated')
    sources = {b['block']:b['text'] for b in inp['blocks']}
    for item in value['items']:
        if item['decision'] in {'full','partial'} and not item['evidence']:
            errors.append('positive decision lacks evidence')
        if item['decision'] == 'full' and item['missing_components']:
            errors.append('full has missing components')
        if item['decision'] in {'partial','absent'} and not item['missing_components']:
            errors.append('partial/absent lacks missing components')
    for row in value['items'] + value['findings']:
        for proof in row['evidence']:
            if proof['block'] not in sources or proof['quote'] not in sources[proof['block']]:
                errors.append('source quote absent from numbered block')
    return errors


def criterion(cid, text, classification='required'):
    return {'id':cid, 'classification':classification, 'criterion':text,
            'trigger':'Always for this authored control', 'safety_significance':'author_control'}


def controls():
    base = {'jurisdiction':'NO', 'expected_result':'synthetic_control', 'knowledge_gap':{}, 'optional_information':[], 'case_noise_guidance':[]}
    basic = {**base, 'context_id':'control-basic',
        'question':'I denne oppdiktede øvelsen bruker vi signalenheten Mira. Hva inneholder de leverte instruksene?',
        'criteria':[
            criterion('c1','Åpne låsen før START og hold START inne i fem sekunder.'),
            criterion('c2','Oppbevar Mira i enten tørr boks med lokk eller lukket vanntett pose.'),
            criterion('c3','Ved feil: trykk RESET én gang og vent tretti sekunder før nytt forsøk.'),
            criterion('c4','Kontroller batteristatus hvert tiende minutt.')],
        'blocks':[
            {'block':1,'passage_id':'authored-control-1','text':'Før START skal låsen åpnes. Hold deretter START nedtrykket i fem sekunder.'},
            {'block':2,'passage_id':'authored-control-2','text':'Oppbevar enheten i en tørr boks med lokk.'},
            {'block':3,'passage_id':'authored-control-3','text':'Ved feil trykker du RESET én gang.'}]}
    scope = {**base, 'context_id':'control-scope',
        'question':'Vi har mistet stien. Den løse skråningen vi står ved, ligger helt inntil bekken Bekk1.',
        'criteria':[
            criterion('s1','Hold avstand fra den beskrevne løse skråningen ved Bekk1.'),
            criterion('s2','Stopp og vurder situasjonen som bortkommet.')],
        'blocks':[
            {'block':1,'passage_id':'authored-control-4','text':'Ikke opphold dere noe sted i nærheten av Bekk1. Erosjon langs bekken kan utløse skred.'},
            {'block':2,'passage_id':'authored-control-5','text':'Ved en snøskredulykke: Vurder snødekket og søk etter den skredtatte.'}]}
    conflict = {**base, 'context_id':'control-conflict',
        'question':'Vi bruker Mira i sone A. Hva sier kildene om START?',
        'criteria':[criterion('f1','I sone A: åpne låsen før START og hold START inne i fem sekunder.')],
        'blocks':[
            {'block':1,'passage_id':'authored-control-6','text':'I sone A skal låsen åpnes før START. Hold START inne i fem sekunder.'},
            {'block':2,'passage_id':'authored-control-7','text':'I sone A skal låsen åpnes før START. Hold START inne i sju sekunder.'}]}
    expected = {
        'control-basic':{'labels':{'c1':'full','c2':'full','c3':'partial','c4':'absent'}, 'required_flags':[], 'forbidden_flags':['direct_conflict','potentially_misleading','geography']},
        'control-scope':{'labels':{'s1':'full','s2':'absent'}, 'required_flags':['irrelevant'], 'forbidden_flags':['direct_conflict','potentially_misleading','geography']},
        'control-conflict':{'labels':{'f1':'full'}, 'required_flags':['direct_conflict'], 'forbidden_flags':['geography']}}
    return [basic,scope,conflict], expected


def parent_check():
    r.RUN = PARENT
    r.check_freeze()
    seals = r.read(PARENT / 'closeout-seals.json')['hashes']
    for name, expected in seals.items():
        assert r.digest(ROOT / name) == expected, name
    return seals


def prepare():
    assert not RUN.exists(), 'Run already prepared; refuse replacement'
    seals = parent_check()
    rubric = r.read(PUBLIC / 'answer_rubric.v1.json')
    assert r.digest(PUBLIC / 'answer_rubric.v1.json') == '6333f84d343c529009b0f319a1119edb9437f8b6a047c07325bd4201658b5d1f'
    gold = r.yaml.safe_load((PUBLIC / 'retrieval_development.v2.yaml').read_text(encoding='utf-8'))
    noise = {x['id']:x['irrelevant_or_potentially_misleading_information'] for x in gold['cases']}
    cases = {x['id']:x for x in rubric['cases']}
    specs = []
    for i in range(1,26):
        cid = f'case-{i:02}'
        old = r.read(PARENT / 'inputs' / (cid + '.json'))
        case = cases[cid]
        assert old['question'] == case['question']
        inp = {'context_id':f'R{i:02}', 'question':old['question'], 'jurisdiction':old['jurisdiction'],
            'expected_result':old['expected_result'], 'knowledge_gap':old['knowledge_gap'],
            'criteria':old['revised_criteria'],
            'optional_information':case['unchanged_optional'] + [x['criterion'] for x in case['criteria'] if x['classification']=='optional'],
            'case_noise_guidance':noise[cid], 'blocks':old['blocks']}
        inp['criteria'] = [x for x in inp['criteria'] if x['classification'] != 'optional']
        assert not {'answers','historical_criteria','historical_alternatives'} & inp.keys()
        r.write(RUN / 'inputs' / (inp['context_id'] + '.json'), inp)
        specs.append({'context_id':inp['context_id'], 'case_id':cid,
            'expected_result':inp['expected_result'], 'input_sha256':r.canonical(inp),
            'parent_input_sha256':r.digest(PARENT/'inputs'/(cid+'.json'))})
    authored, expected = controls()
    for inp in authored:
        r.write(RUN / 'inputs' / (inp['context_id'] + '.json'), inp)
    r.write(RUN / 'control-expected.json', expected)
    r.write(RUN / 'case-map.json', specs)
    for name in ('TASKS.md','evals/AGENTS.md'):
        dest = RUN / 'before' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, dest)
    immutable = {k:v for k,v in seals.items() if k not in {'TASKS.md','evals/AGENTS.md'}}
    r.write(RUN / 'preserved-parent-files.json', immutable)
    pre = r.runtime.preflight()
    pre['cli_sha256'] = r.digest(pre['cli'])
    assert pre['cli_sha256'] == r.read(PARENT/'freeze.json')['preflight']['cli_sha256']
    r.write(RUN / 'schema.json', schema())
    paths = [Path(__file__).resolve(), PROMPT, PROTOCOL, LOCK,
        PUBLIC/'answer_rubric.v1.json', PUBLIC/'codex_judge_runtime.py', PUBLIC/'retrieval_judge_pilot.py',
        PUBLIC/'answer_rubric_revision_v1.py', PUBLIC/'answer_revision_continue_v1.py',
        PUBLIC/'answer_revision_transport_v2.py', PUBLIC/'answer_revision_results.v3.json',
        PUBLIC/'answer_revision_review.v1.json', PUBLIC/'test_retrieval_rubric_rescore_v1.py']
    paths += [p for p in RUN.rglob('*') if p.is_file()]
    r.write(RUN / 'freeze.json', {'at':r.now(), 'authorization':'2026-10-25 owner execute steps1/2',
        'model':MODEL, 'effort':EFFORT, 'preflight':pre, 'timeout_seconds':TIMEOUT,
        'rss_limit_bytes':4*1024**3, 'host_reserve_bytes':256*1024**2,
        'controls':[x['context_id'] for x in authored], 'primary':[x['context_id'] for x in specs],
        'primary_cases':25, 'required_supported_denominator':63,
        'conditional_inventory_denominator':4, 'corpus_gap_cases':3,
        'maximum_successful_calls':28, 'automatic_retries':0,
        'parent_closeout_sha256':r.digest(PARENT/'closeout-seals.json'),
        'allowed_progress_document_changes':['TASKS.md','evals/AGENTS.md'],
        'hashes':{str(p.relative_to(ROOT)):r.digest(p) for p in paths}})
    check_freeze()
    print(json.dumps({'prepared':True,'primary_contexts':25,'controls':3,'required':63,'model':MODEL,'effort':EFFORT}),flush=True)


def check_freeze():
    frozen = r.read(RUN / 'freeze.json')
    for name, expected in frozen['hashes'].items():
        assert r.digest(ROOT / name) == expected, name
    for name, expected in r.read(RUN / 'preserved-parent-files.json').items():
        assert r.digest(ROOT / name) == expected, name
    mapping = r.read(RUN / 'case-map.json')
    total = conditional = gaps = 0
    for meta in mapping:
        inp = r.read(RUN / 'inputs' / (meta['context_id'] + '.json'))
        old = r.read(PARENT / 'inputs' / (meta['case_id'] + '.json'))
        assert inp['blocks'] == old['blocks'] and inp['question'] == old['question']
        assert meta['input_sha256'] == r.canonical(inp)
        if inp['expected_result'] == 'supported_context':
            total += sum(x['classification']=='required' for x in inp['criteria'])
            conditional += sum(x['classification']=='conditional' for x in inp['criteria'])
        else:
            gaps += 1
    assert (total,conditional,gaps) == (63,4,3)
    return frozen


def finalize(out, inp, rc=None, error=None):
    if (out/'record.json').exists():
        return r.read(out/'record.json')
    events, malformed, usage = r.runtime.events_and_usage(out/'stdout.jsonl')
    errors = []
    if malformed:
        errors.append('malformed stream')
    if not any(e.get('type')=='turn.completed' for e in events):
        errors.append('turn incomplete; no automatic retry')
    if any(e.get('item',{}).get('type') not in {None,'agent_message','reasoning','error'} for e in events):
        errors.append('tool use forbidden')
    if rc not in (0,None):
        errors.append('nonzero CLI exit')
    if error:
        errors.append(error)
    output = None
    try:
        messages = [e['item']['text'] for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message']
        output = json.loads(messages[-1])
        errors += validate(output,inp)
    except (ValueError,IndexError,TypeError):
        errors.append('final JSON unavailable')
    value = {'at':r.now(), 'success':not errors, 'errors':errors, 'input_sha256':r.canonical(inp),
        'raw_sha256':r.digest(out/'stdout.jsonl'), 'usage':usage, 'requested':r.read(out/'intent.json'),
        'server_model_revision':None, 'returned_decisions':output}
    r.write(out/'record.json', value)
    return value


def call(context_id, pre):
    inp = r.read(RUN/'inputs'/(context_id+'.json'))
    out = RUN/'results'/context_id
    if (out/'record.json').exists():
        return r.read(out/'record.json')
    if (out/'intent.json').exists():
        return finalize(out,inp)
    if r.psutil.virtual_memory().available < 256*1024**2:
        raise RuntimeError('Host reserve failed before dispatch')
    r.write(out/'intent.json', {'at':r.now(),'model':MODEL,'reasoning_effort':EFFORT,
        'input_sha256':r.canonical(inp),'cli_sha256':pre['cli_sha256'],
        'prompt_sha256':r.digest(PROMPT),'schema_sha256':r.digest(RUN/'schema.json'),
        'timeout_seconds':TIMEOUT})
    r.write(out/'input.json',inp)
    wire = json.dumps(inp,ensure_ascii=False).encode('utf-8')
    (out/'stdin.json').write_bytes(wire)
    started = r.time.monotonic()
    error = None
    samples = []
    temp_root = RUN/'temp'
    temp_root.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='retrieval-judge-',dir=temp_root) as tmp:
        temp = Path(tmp)
        assert temp.resolve().is_relative_to(temp_root.resolve()) and temp.resolve()!=temp_root.resolve()
        (temp/'instructions.md').write_bytes(PROMPT.read_bytes())
        shutil.copyfile(RUN/'schema.json',temp/'schema.json')
        cmd = r.legacy.codex_command(pre['cli'],temp,{'codex_model':MODEL},output=False)
        assert 'model_reasoning_effort="medium"' in cmd
        r.write(out/'command.json',{'argv':cmd})
        with (out/'stdout.jsonl').open('xb') as stdout, (out/'stderr.txt').open('xb') as stderr:
            proc = r.subprocess.Popen(cmd,cwd=temp,env=r.legacy.codex_environment(),stdin=r.subprocess.PIPE,stdout=stdout,stderr=stderr)
            proc.stdin.write(wire)
            proc.stdin.close()
            while proc.poll() is None:
                try:
                    tree = [r.psutil.Process(proc.pid)] + r.psutil.Process(proc.pid).children(recursive=True)
                    rss = sum(p.memory_info().rss for p in tree if p.is_running())
                    available = r.psutil.virtual_memory().available
                    samples.append((rss,available))
                    if rss > 4*1024**3 or available < 256*1024**2:
                        error = 'historical memory guard'
                        proc.kill()
                        break
                except r.psutil.Error:
                    pass
                if r.time.monotonic()-started > TIMEOUT:
                    error = 'timeout; no automatic retry'
                    proc.kill()
                    break
                r.time.sleep(.1)
            rc = proc.wait()
            stdout.flush()
            stderr.flush()
            r.os.fsync(stdout.fileno())
            r.os.fsync(stderr.fileno())
    r.write(out/'resources.json', {'elapsed_seconds':r.time.monotonic()-started,
        'peak_rss_bytes':max((x for x,y in samples),default=None),
        'minimum_available_bytes':min((y for x,y in samples),default=None), 'sample_interval':.1})
    return finalize(out,inp,rc,error)


def control_errors(value, expected):
    labels = {x['id']:x['decision'] for x in value['items']}
    flags = {x['type'] for x in value['findings']}
    errors = []
    if labels != expected['labels']:
        errors.append({'labels':labels,'expected':expected['labels']})
    if not set(expected['required_flags']) <= flags:
        errors.append({'required_flags_missing':sorted(set(expected['required_flags'])-flags)})
    if flags & set(expected['forbidden_flags']):
        errors.append({'unexpected_flags':sorted(flags & set(expected['forbidden_flags']))})
    return errors


def run():
    frozen = check_freeze()
    pre = frozen['preflight']
    assert r.digest(pre['cli']) == pre['cli_sha256']
    expected = r.read(RUN/'control-expected.json')
    with r.runtime.JudgeLock():
        for cid in frozen['controls'] + frozen['primary']:
            record = call(cid,pre)
            if not record['success']:
                r.write(RUN/'stop.json',{'at':r.now(),'context_id':cid,'errors':record['errors']})
                print(json.dumps({'stopped':cid,'errors':record['errors']},ensure_ascii=False),flush=True)
                return
            if cid in expected:
                errors = control_errors(record['returned_decisions'],expected[cid])
                if errors:
                    r.write(RUN/'stop.json',{'at':r.now(),'context_id':cid,'control_errors':errors})
                    print(json.dumps({'control_failed':cid,'errors':errors},ensure_ascii=False),flush=True)
                    return
                print(json.dumps({'control_passed':cid,'usage':record['usage']}),flush=True)
            else:
                print(json.dumps({'completed':cid,'labels':dict(Counter(x['decision'] for x in record['returned_decisions']['items'])),'usage':record['usage']}),flush=True)
        r.write(RUN/'complete.json',{'at':r.now(),'primary':25,'controls':3})


def retention(source_decisions, answer_decisions):
    ids = set(source_decisions)
    available = {i for i in ids if source_decisions[i]=='full'}
    answered = {i for i in ids if answer_decisions[i]=='full'}
    return {'available':len(available), 'preserved':len(available & answered),
        'answer_full_total':len(answered), 'answer_full_without_full_source':len(answered-available),
        'retention':len(available & answered)/len(available) if available else None}


def summarize():
    frozen = check_freeze()
    mapping = r.read(RUN/'case-map.json')
    counter = Counter()
    conditions = Counter()
    rows = []
    tokens = Counter()
    for cid in frozen['controls'] + frozen['primary']:
        path = RUN/'results'/cid/'record.json'
        if path.exists():
            tokens.update(r.read(path).get('usage') or {})
    source_maps = {}
    for meta in mapping:
        cid = meta['context_id']
        path = RUN/'results'/cid/'record.json'
        if not path.exists() or not r.read(path)['success']:
            continue
        value = r.read(path)['returned_decisions']
        inp = r.read(RUN/'inputs'/(cid+'.json'))
        classes = {x['id']:x['classification'] for x in inp['criteria']}
        required = {x['id']:x['decision'] for x in value['items'] if classes[x['id']]=='required'}
        conditional = [x for x in value['items'] if classes[x['id']]=='conditional']
        gap = meta['expected_result'] != 'supported_context'
        if not gap:
            counter.update(required.values())
            counter['cases'] += 1
            counter['all_core_full'] += all(x=='full' for x in required.values())
            conditions.update(x['decision'] for x in conditional)
            source_maps[meta['case_id']] = required
        rows.append({'case_id':meta['case_id'],'context_id':cid,'corpus_gap':gap,
            'required':required,'conditional':{x['id']:x['decision'] for x in conditional},
            'finding_types':sorted({x['type'] for x in value['findings']}),
            'items':[{k:x[k] for k in ('id','decision','missing_components','reason')} for x in value['items']],
            'findings':[{k:x[k] for k in ('type','reason')} for x in value['findings']]})
    # Link only primary-context answers. Diagnostic source contexts were not assessed.
    old_map = {x['answer_id']:x for x in r.read(PARENT/'private-answer-map.json')}
    paired = []
    by_slice = {}
    raw = r.read(PUBLIC/'answer_revision_results.v3.json')
    for answer in raw['rows']:
        if answer['effort']!='medium' or answer['diagnostic']:
            continue
        meta = old_map[answer['answer_id']]
        if meta['case_id'] not in source_maps:
            continue
        source = source_maps[meta['case_id']]
        ad = {x['id']:x['decision'] for x in answer['revised']}
        values = retention(source,ad)
        pair = {'case_id':meta['case_id'],'model':meta['model'],'answer_id':answer['answer_id'],**values,
            'items':{i:{'source':d,'answer':ad[i]} for i,d in source.items()}}
        paired.append(pair)
        slices = ['full25'] if meta['model']=='historical-qwen' else []
        if meta['case_id'] in {'case-19','case-05','case-08','case-17','case-21','case-23'}:
            slices.append('matched-screen8')
        for name in slices:
            key = name+'|'+meta['model']
            acc = by_slice.setdefault(key,Counter())
            for field in ('available','preserved','answer_full_total','answer_full_without_full_source'):
                acc[field] += values[field]
            acc['supported_answers'] += 1
    for values in by_slice.values():
        values['retention'] = values['preserved']/values['available'] if values['available'] else None
    complete = (RUN/'complete.json').exists()
    result = {'version':1,'at':r.now(),'complete':complete,'freeze_sha256':r.digest(RUN/'freeze.json'),
        'rubric_sha256':r.digest(PUBLIC/'answer_rubric.v1.json'),'model':MODEL,'effort':EFFORT,
        'primary_records':len(rows),'core_denominator':63,'core_counts':dict(counter),
        'confirmed_micro_coverage':counter['full']/63,
        'uncertainty_upper_bound':(counter['full']+counter['uncertain'])/63,
        'supported_cases_observed':counter['cases'],
        'macro_confirmed_coverage':sum(sum(d=='full' for d in m.values())/len(m) for m in source_maps.values())/len(source_maps) if source_maps else None,
        'conditional_branch_availability':dict(conditions),'rows':rows,'paired_answer_retention':paired,
        'retention_slices':{k:dict(v) for k,v in by_slice.items()},'known_usage':dict(tokens),
        'new_search_calls':0,'new_product_answers':0,'paid_api_calls':0,'free_resets_consumed':0,
        'raw_scores_unchanged':True,'historical_coverage':'60/72 old rubric; different definition, unchanged search',
        'known_answer_review_caveats':'Sealed answer_revision_review.v1.json; raw Medium reused, not silently corrected',
        'judgments_are_not_clinical_validation':True}
    n = 1
    while (PUBLIC/f'retrieval_rubric_rescore_results.v{n}.json').exists():
        n += 1
    r.write(PUBLIC/f'retrieval_rubric_rescore_results.v{n}.json',result)
    print(json.dumps({'version':n,'complete':complete,'records':len(rows),'counts':dict(counter),'conditional':dict(conditions),'retention_slices':result['retention_slices'],'usage':dict(tokens)},ensure_ascii=False),flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
    elif action == 'run':
        run()
    elif action == 'summarize':
        summarize()
    elif action == 'check':
        check_freeze()
        print('Frozen and inherited files verified without inference.')
    else:
        raise ValueError(action)
