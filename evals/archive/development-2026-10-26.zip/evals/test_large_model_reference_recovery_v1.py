import json
import unittest
from recover_large_model_reference_v1 import new_warning_policy


class WatcherRecoveryTest(unittest.TestCase):
    def test_success_after_old_warning_does_not_trigger_new_failure(self):
        warning='retrying sampling request (1/5 in 24s)... 429 Too Many Requests'
        status,seen=new_warning_policy(warning,'',0)
        self.assertTrue(status.startswith('allow'))
        text=json.dumps({'item':{'type':'agent_message','text':'completed answer'}})
        status,seen=new_warning_policy(warning,text,seen)
        self.assertEqual(status,'none')
        status,seen=new_warning_policy(warning+'\n'+warning,text,seen)
        self.assertTrue(status.startswith('stop'))


if __name__=='__main__':unittest.main()
