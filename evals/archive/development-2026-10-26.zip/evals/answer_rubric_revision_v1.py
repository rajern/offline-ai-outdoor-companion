"""Retrospective, source-bound assessment of saved answers. No answer generation.

prepare writes a new run; run medium then run high; summarize is inference-free.
Historical scorers and all existing inputs/results are read-only dependencies.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'knowledge/local/judge-pilot-deps'))
sys.path.insert(0, str(ROOT / 'backend/.venv/Lib/site-packages'))
sys.path.insert(0, str(ROOT / 'knowledge/local/optimization-env/Lib/site-packages'))
import yaml
from jsonschema import Draft202012Validator
import psutil
import codex_judge_runtime as runtime
import retrieval_judge_pilot as legacy

RUN = ROOT / 'knowledge/local/diagnostics/answer-rubric-revision-v1-2026-10-24'
OLD = ROOT / 'knowledge/local/diagnostics/qwen-rag-system-v1-2026-10-11/revision-02'
NEW = ROOT / 'knowledge/local/diagnostics/local-generation-eligible-2026-10-24/responses'
PUBLIC = ROOT / 'evals'
MODEL = 'gpt-6.1-sol'


def now():
    return datetime.now(timezone.utc).isoformat()


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def canonical(v):
    return hashlib.sha256(json.dumps(v, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def write(p, v):
    runtime.write(Path(p), v)


# Entries correspond 1:1 to historical requirements. R=required, C=conditional,
# O=optional; ! marks source-grounded safety importance, not clinical validation.
# Deliberately retained composites keep actions with decisive qualifications.
REVISIONS = {
1: [
 ('R','Ta høyde for mulig brudd når personen ikke kan stå på foten.','Uten bruddmistanke kan situasjonen behandles som ukomplisert forstuing.'),
 ('O','Forstuing og brudd kan være vanskelig å skille.','Forklarer bruddmistanken; handling og legevurdering dekker det umiddelbare behovet.'),
 ('R!','Anbefal vurdering av lege eller legevakt ved mulig brudd.','Uten vurdering blir mulig brudd stående uten relevant oppfølging.'),
 ('R','Hold skaden i ro og unngå belastning eller unødvendig bevegelse.','Avlastning er handlingen; forklaring om mer smerte/skade er utdyping.')],
2: [
 ('R!','Begrens varmetap ved å få bort vått tøy og få personen tørr.','Vedvarende vått tøy motvirker oppvarmingen.'),
 ('R!','Isoler personen og beskytt mot vind og fukt med tilgjengelig egnet utstyr.','Sovepose/fjellduk kan beskrive funksjonene uten ordrett vind- og damptett terminologi.'),
 ('R!','Tilfør varme; eventuelle eksterne varmekilder skal ikke ligge direkte på huden.','Oppvarming og beskyttelse mot direkte varmekilde må bevares samlet.'),
 ('R!','Følg med på bevissthet og pust.','Forverring må kunne oppdages.'),
 ('R!','Ring 113 for hjelp ved denne beskrevne nedkjølingen, slik den frosne kilden anbefaler.','Beholder kildeanbefalt varsling; eksplisitt forklaring av operatørens rolle kreves ikke.')],
3: [
 ('O','Rent utseende beviser ikke at vann er mikrobiologisk trygt.','Nyttig forklaring; en klar beskjed om behandling før drikking kan besvare spørsmålet uten å gjenta mekanismen.'),
 ('R!','Behandle det usikre bekkevannet før det drikkes.','Besvarer om vannet kan brukes uten behandling.'),
 ('R!','For klart vann til og med 6500 fot: fosskok i ett minutt; riktig omregning til omtrent 2000 meter godtas.','Metode, varighet og høydegrense er handlingsrelevant, ikke valgfrie detaljer.'),
 ('R!','Over 6500 fot: fosskok klart vann i tre minutter.','Høyde er ikke oppgitt; behold det kildeangitte unntaket uten å anta lav høyde.'),
 ('C!','Ved mistanke om kjemikalier/giftstoffer: koking/desinfisering gjør ikke vannet trygt; velg annen kilde.','Viktig begrensning når forurensning diskuteres eller svaret lover generell trygghet; ingen kjemisk mistanke er oppgitt.')],
4: [
 ('R!','Ikke fortsett inn i ukjent terreng for å lete etter veien.','Hindrer fortsatt ukontrollert vandring.'),
 ('R','Stopp og vurder situasjonen.','Gir første handling; kan være dekket av tydelig beskjed om å bli der man er.'),
 ('R!','Bli der dere er når dere ikke er sikre på veien ut.','Knytt handlingen til den oppgitte usikkerheten.'),
 ('R','Ivareta sikkerhet og varme, og søk eller lag ly ved behov.','Utsatt gruppe må kunne vente uten fortsatt nedkjøling.'),
 ('R','Søk hjelp og gjør dere synlige.','Gir hjelp/synlighet som alternativ til å vandre videre.')],
5: [
 ('O','Hørbar torden betyr at farlig lyn er nær nok.','Fareforklaring; kan utelates når umiddelbar, riktig handling allerede gis.'),
 ('C!','Utendørstiltak gjør ikke stedet lynsikkert.','Kreves når svaret foreslår å vente/finne sikkerhet utendørs, ikke som ekstra setning etter utelukkende korrekt innendørsråd.'),
 ('R!','Forlat rygger/topper og annet eksponert høyt terreng.','Spørsmålet plasserer gruppen på en rygg; den konkrete faren må håndteres.'),
 ('R!','Ikke bruk klippeoverhenget som trygt ly mot lyn.','Besvarer det konkrete foreslåtte lyet; en uttrykkelig universell advarsel som dekker overheng kan også oppfylle behovet.'),
 ('R!','Søk minst ett gyldig ly-alternativ: egnet solid bygning med strøm/røranlegg ELLER lukket bil med metalltak og vinduer oppe.','Én komplett alternativrute er nok. Et annet feilaktig alternativ flagges separat, ikke skjult av positiv dekning.'),
 ('C!','Hvis trygt ly ikke kan nås, kan utendørstiltak bare redusere risiko; de garanterer ikke trygghet.','Aktivt hvis svaret gir utendørs reserveløsning. Ikke obligatorisk å beskrive alle hypotetiske reserveplaner.')],
6: [
 ('R!','Ring 113 ved den beskrevne store blødningen.','Alvorlig pågående blødning må eskaleres.'),
 ('R!','Press rent tøy/bandasje direkte og hardt mot blødningen.','Den primære umiddelbare handlingen må kunne utføres.'),
 ('R!','Ved gjennomblødning: legg ny bandasje utenpå og øk trykket; ikke fjern den første.','Brukeren beskriver gjennomblødning; riktig videre handling er nødvendig.'),
 ('R!','Hold personen varm og følg med på tilstanden; varsle 113 om forverring.','Behold oppfølging; sløvhet er eksempel, ikke det eneste ordet som godtas.')],
7: [
 ('R!','Avkjøl voksnes skadested med rennende litt kjølig vann, omtrent 20 grader, i inntil 20 minutter.','Beholder kildeangitt metode, temperatur og tidsgrense; ingen klinisk nytolkning.'),
 ('R!','Unngå is og iskaldt vann på skaden.','Negasjonen må bevares; forklaring om ytterligere hudskade er utdyping.'),
 ('R!','Ikke stikk hull på blemmene.','Brukeren har blemmer; en direkte forebyggende instruksjon.'),
 ('R!','Kontakt lege siden hånden er brannskadet.','Beholder det aktuelle kildekriteriet, ikke et vilkårlig alvorlighetskrav.')],
8: [
 ('R!','Ring 113 nå for den bevisstløse personen.','Varsling er nødvendig; hjelp/veiledning trenger ikke omtales separat for positiv dekning.'),
 ('R!','Åpne luftveien med hake frem og hode litt bakover, og vurder normal pust ved brystbevegelser og luftstrøm i inntil 10 sekunder.','Beholder konkret vurdering og tidsgrense. En sammenhengende beskrivelse av kinn nær munn/nese og luftstrøm kan dekke sansevurderingen uten eksakte verb.'),
 ('R!','Ved bevisstløshet med normal pust: sideleie, fri luftvei og munnen vendt nedover.','Beholder munnstilling fordi kilden angir den; utilstrekkelig faglig grunnlag for å erklære den unødvendig.'),
 ('R!','Overvåk normal pust; ved ingen/unormal pust start HLR.','Beholder overvåking og korrekt forgrening. Egen gjentakelse om usikkerhet til 113 er utdyping når 113 allerede er varslet.')],
9: [
 ('R','Drikk godt med vann eller annen alkoholfri drikke.','Besvarer forebygging av varmesykdom.'),
 ('R','Reduser fysisk aktivitet i varmen.','Aktivitetsendring er en annen handling enn bare å drikke.'),
 ('R','Sørg for avkjøling eller kjøligere omgivelser.','Én passende kildebeskrevet avkjølingsmåte er nok; alle eksemplene kreves ikke.')],
10: [
 ('R','Ta med varmt tøy for dårlig vær og uventet natt ute.','Spørsmålet gjelder beredskap, ikke akutt behandling.'),
 ('R','Ta med sovepose eller tilsvarende kildebeskrevet isolasjons-/overlevelsesutstyr.','Alternativene er reelle alternativer, ikke en samlet handleliste.'),
 ('R','Ta med nødly, telt eller tilsvarende kildebeskrevet beskyttelse.','Ingen bestemt produsent eller alle lytyper kreves.')],
11: [
 ('R','Uten toalett: grav ned avføring minst cirka 20 cm dypt og minst cirka 60 m fra naturlig vann, etter den frosne kilden.','Beholder metode/avstander; omtrentlige korrekte enheter godtas.'),
 ('R','Plasser toalettavfall nedstrøms steder der dere eller andre henter vann.','Retningen kan ikke erstattes av bare avstand.'),
 ('R','Før matlaging/spising og etter toalett: håndhygiene; når såpe/vann mangler, hånddesinfeksjon med minst 60 prosent alkohol.','Beholder eksplisitt spørsmål om alternativ til såpe/vann og produktgrense.')],
12: [
 ('O','Brunt/misfarget vann er et faresignal for utrygg elv.','Nyttig begrunnelse; direkte nei til kryssing i situasjonen kan være tilstrekkelig uten å gjenta hvert observert tegn.'),
 ('R!','Ikke forsøk kryssing av denne flomstore elva med oppgitt usikkerhet/manglende erfaring.','Konkret nei i denne situasjonen kan uttrykke vilkårene uten ordrett gjentakelse.'),
 ('R!','Vent eller snu i stedet for å presse gjennom kryssingen.','Gir minst ett kildebasert alternativ; begge må ikke listes hvis ett er tydelig anbefalt.')],
13: [
 ('R!','Aktiver nødpeileren nå ved den beskrevne livstruende situasjonen; ikke vent for å se.','Tidlig handling er kjernen; mekanismen om rask forverring/tidligere hjelp er utdyping.'),
 ('C!','Ved uttrykt tvil om aktivering: aktiver og få hjelp fremfor å vente.','Aktiv hvis svaret lar beslutningen avhenge av fortsatt tvil; entydig aktiver nå trenger ikke en ekstra tvilssetning.')],
14: [
 ('R','Faretegn kan bety skredfare og kreve endret plan.','Støttet delinformasjon; dette fyller ikke det konkrete kunnskapshullet om drønn/sprekker og sikker utgang.'),
 ('R','Unngå/begrens skredterreng uten tilstrekkelig kunnskap og erfaring.','Støttet kompetansebegrensning; ingen sikker returretning kan utledes.')],
15: [],
16: [
 ('R','Rengjør såret og huden rundt med lunkent vann eller sårvann; hvis såpe anbefales, må den være mild, nøytral og uparfymert.','Vask er obligatorisk. Såpe er en betinget metode, ikke et krav om at hvert godt svar anbefaler såpe.'),
 ('R','Dekk med plaster/bandasje for å beskytte mot ny skitt.','Direkte relevant når turen skal fortsette.')],
17: [
 ('O','Forklar at rask reaksjon etter stikk med utslett/hevelse/trang hals kan være anafylaksi.','Brukeren spør om det kan vente. Detaljert symptom- og triggergjentakelse er utdyping; en kort mistankebetegnelse kan være nyttig, men erstatter ikke handling.'),
 ('R!','Ring 113 øyeblikkelig for akutt hjelp i denne situasjonen; ikke vent til dere er nede.','Entydig øyeblikkelig 113 er tilstrekkelig handling. En annen feil diagnose/behandling flagges separat.')],
18: [
 ('R!','Hold hodet over vann og forsøk opp der du kom fra.','Beholder to kildeangitte egenredningshandlinger.'),
 ('R!','Bryt svak kant inn til solid is før oppstigning.','Håndterer konkret at kanten brister.'),
 ('R!','Ved solid kant: én komplett kildebeskrevet oppstigningsmetode med armer/ispigger og ben.','Svømmetak-metoden ELLER den kildebeskrevne albue/kne-metoden godtas; begge kreves ikke.')],
19: [
 ('R!','Hver person trenger sender/mottaker, spade og søkestang; det beskrevne fellesutstyret er ikke nok.','Aktør og alle tre utstyrstyper er kjernen i spørsmålet.'),
 ('R','Øv på å bruke utstyret, slik at ferdighetene fungerer i praksis.','Øv til rutinene sitter er en dekkende formulering; egen setning om krevende forhold kreves ikke.')],
20: [
 ('R','Undersøk ruten og om gruppens ferdigheter er tilstrekkelige.','Rute/ferdigheter må knyttes sammen.'),
 ('R','Sjekk værmeldingen og tilpass/endre planen ved behov.','Rask værendring er forklaring; handlingene må med.')],
21: [
 ('R!','Det beskrevne filteret fjerner bakterier/parasitter, men ikke virus; det er ikke nok alene mot alle mikrober.','Porestørrelsen er allerede gitt i spørsmålet og trenger ikke gjentas. Virusbegrensningen kan ikke utelates.'),
 ('R!','Filtrer først, desinfiser deretter, og følg produktets bruksanvisning.','Rekkefølge og produktavhengighet er nødvendige; dose/virketid må ikke finnes på.')],
22: [
 ('R','Bruk egnet offline topografisk kartapp som dekker NZ-terreng og stier.','Rett karttype og geografisk dekning er nødvendige; ikke bare ordet kart.'),
 ('R','Last ned kart og sjekk at de virker offline før avreise.','Nedlasting alene dokumenterer ikke at offlinefunksjonen er kontrollert.'),
 ('R','Sørg for batteritid og papirkart som reserve.','To ulike sårbarheter må håndteres; hvorfor telefonen kan svikte er allerede gitt.')],
23: [
 ('R!','Vent i ordentlig ly minst 30 minutter etter siste hørbare torden; ti minutter er ikke nok.','Tidsgrense og startpunkt er avgjørende.'),
 ('R!','Unngå ledningstilkoblet elektrisk utstyr som gir direkte kontakt med elektrisitet.','En klar overordnet kategori kan dekke telefon/datamaskin-eksemplene uten uttømmende liste.'),
 ('R!','Unngå kontakt med røranlegg/rørført vann, for eksempel vask, bad og kraner.','Kategorien må være tydelig; de tre illustrerende objektene trenger ikke alle gjentas.')],
24: [
 ('R!','Hold avstand fra elver/bekker med stor vannføring.','Relevant unngåelseshandling.'),
 ('R!','Hold avstand fra bratte skråninger med løsmasser ved den eroderte bekken.','Unngåelsen er obligatorisk; årsaksforklaring om erosjon/skred er utdyping.')],
25: [],
}

CONDITIONS = {
 (3,5): 'Aktiv hvis spørsmålet/svaret omtaler kjemikalier/giftstoffer eller lover vannet trygt mot all forurensning. Ellers not_applicable.',
 (5,2): 'Aktiv når svaret anbefaler utendørs opphold/tiltak som en løsning eller omtaler trygghet utendørs.',
 (5,6): 'Aktiv når svaret gir en utendørs reserveplan fordi gyldig ly ikke kan nås.',
 (13,2): 'Aktiv når svaret gjør aktivering avhengig av ytterligere vurdering/tvil fremfor entydig aktiver nå.'
}


def rubric():
    old = yaml.safe_load((PUBLIC/'retrieval_development.v2.yaml').read_text(encoding='utf-8'))
    corpus = read(ROOT/'knowledge/local/knowledge.json')['items']
    rows=[]
    for c in old['cases']:
        n=int(c['id'][-2:]); rules=REVISIONS[n]
        assert len(rules)==len(c['must_have_information'])
        criteria=[]
        for i,(level,text,reason) in enumerate(rules,1):
            kind={'R':'required','C':'conditional','O':'optional'}[level[0]]
            criteria.append({'id':f'{c["id"]}/r{i}', 'old_item':i,
              'historical_text':c['must_have_information'][i-1],
              'classification':kind,'criterion':text,'omission_rationale':reason,
              'trigger':CONDITIONS.get((n,i),'Always for this question' if kind=='required' else 'Not core scored'),
              'safety_significance':'source_grounded_high_consequence' if '!' in level else 'not_declared_critical',
              'reviewer':'current workspace agent; model/effort not programmatically exposed',
              'review_needed': n in {7,8,11,14,18},
              'uncertainty': 'Evaluation convention, not independent clinical validation. Preserve existing source scope; do not certify minimal sufficiency.' if n in {7,8,11,14,18} else 'Necessity is an author judgment supported by the stated omission consequence, not a measured fact.'})
        docs={s['source_id'] for s in c['preferred_source_sections']}
        evidence=[{'id':x['id'],'section':x.get('section'),'source_url':x['source_url'],'sha256':canonical(x)} for x in corpus if x['document_id'] in docs]
        rows.append({'id':c['id'],'question':c['question'],'jurisdiction':c['jurisdiction'],
          'expected_result':c['expected_result'],'criteria':criteria,
          'historical_alternatives':c['acceptable_source_sections_or_chunks'],
          'unchanged_optional':c['optional_useful_information'],
          'knowledge_gap':c['knowledge_gap'],'source_evidence':evidence,
          'authored_at':now(),'decision_status':'owner-authorized retrospective development convention; not safety approval'})
    return {'version':1,'historical_gold_sha256':digest(PUBLIC/'retrieval_development.v2.yaml'),
       'corpus_sha256':digest(ROOT/'knowledge/local/knowledge.json'),
       'retrospective':True,'independent_clinical_review':False,'cases':rows}


def object_schema(props):
    return {'type':'object','properties':props,'required':list(props),'additionalProperties':False}


def schema():
    string={'type':'string'}
    item=object_schema({'id':string,'decision':{'type':'string','enum':['full','partial','absent','uncertain','not_applicable']},
      'answer_quote':string,'reason':string,'support':{'type':'string','enum':['full','partial','absent','uncertain','not_assessed']},
      'source_block':{'type':'integer'},'source_quote':string})
    finding=object_schema({'type':{'type':'string','enum':['unsupported','irrelevant','direct_conflict','critical_omission','requires_review']},
      'answer_quote':string,'source_block':{'type':'integer'},'source_quote':string,'reason':string})
    row=object_schema({'answer_id':string,'historical':{'type':'array','items':item},
       'revised':{'type':'array','items':item},'findings':{'type':'array','items':finding},
       'gap_behavior':{'type':'string','enum':['not_gap','safe_abstention','unsafe_or_missing_abstention','uncertain']}})
    return object_schema({'answers':{'type':'array','items':row}})


def sources_from_prompt(p, ids):
    text=p.read_text(encoding='utf-8')
    blocks=re.findall(r'\[KUNNSKAPSUTDRAG (\d+)\]\n(.*?)(?=\n\[KUNNSKAPSUTDRAG |\n\[BRUKERSPØRSMÅL\])',text,re.S)
    assert len(blocks)==len(ids),(p,len(blocks),len(ids))
    return [{'block':int(i),'passage_id':pid,'text':body.strip()} for (i,body),pid in zip(blocks,ids)]


def prepare():
    if RUN.exists(): raise RuntimeError('Run already exists; refuse replacement')
    historical=read(PUBLIC/'qwen_rag_system_results.v1.json')
    new=read(PUBLIC/'local_generation_comparison_results.v1.json')
    rb=rubric(); groups=[]; mapping=[]; originals={}
    for c in rb['cases']:
        for diagnostic in (False,True):
            if diagnostic and c['id'] not in {'case-03','case-08','case-17'}: continue
            groupid=('diagnostic-' if diagnostic else '')+c['id']
            folder=OLD/('diagnostic-sufficient-context' if diagnostic else 'baseline')/c['id']
            row=next(x for x in (historical['diagnostics_separate'] if diagnostic else historical['rows']) if x['case_id']==c['id'])
            if diagnostic: ids=row['input']['source_ids']
            else: ids=read(folder/'result.json')['retrieval']['source_ids']
            blocks=sources_from_prompt(folder/'prompt.txt',ids)
            variants=[('historical-qwen',folder,row['requirements'])]
            variants += [(x['model'],NEW/x['model']/x['id'],x['decisions']) for x in new['rows'] if x['id']==groupid]
            answers=[]
            for model,path,prior in variants:
                answer=path/'answer.txt'; aid=canonical({'model':model,'group':groupid})[:12]
                sealed=read(path/'seal.json')
                # Both historical and screening seals store original file hashes.
                if isinstance(sealed,dict) and 'answer.txt' in sealed:
                    assert digest(answer)==sealed['answer.txt']
                binding=next((x['binding'] for x in new['rows'] if x['model']==model and x['id']==groupid),None)
                if binding:
                    assert digest(answer)==binding['answer_sha256']
                    assert ids==binding['delivered_passage_ids']
                answers.append({'answer_id':aid,'text':answer.read_text(encoding='utf-8')})
                mapping.append({'answer_id':aid,'group':groupid,'case_id':c['id'],'model':model,
                  'diagnostic':diagnostic,'answer_path':str(answer.relative_to(ROOT)),
                  'answer_sha256':digest(answer),'historical_agent_decisions':prior})
                for name in ('answer.txt','seal.json','prompt.txt','response.json'):
                    f=path/name
                    if f.exists(): originals[str(f.relative_to(ROOT))]=digest(f)
            answers.sort(key=lambda x:x['answer_id'])
            groups.append({'group_id':groupid,'question':c['question'],'jurisdiction':c['jurisdiction'],
              'expected_result':c['expected_result'],'knowledge_gap':c['knowledge_gap'],
              'historical_criteria':[{'id':f'{c["id"]}/old{i+1}','criterion':t['historical_text']} for i,t in enumerate(c['criteria'])],
              'historical_alternatives':c['historical_alternatives'],
              'revised_criteria':[{k:v for k,v in t.items() if k in {'id','classification','criterion','trigger','safety_significance'}} for t in c['criteria']],
              'blocks':blocks,'answers':answers})
    assert len(mapping)==50 and len(groups)==28
    # Source-bound author controls: known equivalent wording, omissions and scope.
    base=next(g for g in groups if g['group_id']=='case-19')
    controls=[{**base,'group_id':'control-equipment','answers':[
      {'answer_id':'control-good','text':'Nei. Hver av dere må ha sender/mottaker, spade og søkestang. Øv med utstyret til rutinene sitter.'},
      {'answer_id':'control-missing','text':'Alle må ha sender/mottaker og spade. Øv til rutinene sitter.'},
      {'answer_id':'control-wrong','text':'Én felles sender/mottaker og spade er nok. Dere trenger ikke øve.'}]}]
    control_expected={'control-good':['full','full'],'control-missing':['partial','full'],'control-wrong':['absent','absent']}
    protected=[PUBLIC/'retrieval_development.v2.yaml',PUBLIC/'local_generation_comparison_results.v1.json',PUBLIC/'qwen_rag_system_results.v1.json',ROOT/'knowledge/local/knowledge.json',PUBLIC/'retrieval_judge_prompt.v3.md']
    protected += list((ROOT/'backend/outwise').rglob('*.py'))
    originals.update({str(p.relative_to(ROOT)):digest(p) for p in protected})
    write(PUBLIC/'answer_rubric.v1.json',rb)
    write(PUBLIC/'answer_revision_schema.v1.json',schema())
    write(RUN/'private-answer-map.json',mapping)
    write(RUN/'control-expected.json',control_expected)
    write(RUN/'preserved-files.json',originals)
    for group in controls+groups: write(RUN/'inputs'/f'{group["group_id"]}.json',group)
    artifacts=[PUBLIC/'answer_rubric.v1.json',PUBLIC/'answer_revision_schema.v1.json',PUBLIC/'answer_revision_judge.v1.md',PUBLIC/'answer_rubric_revision.v1.md',Path(__file__),PUBLIC/'codex_judge_runtime.py',PUBLIC/'retrieval_judge_pilot.py']
    artifacts += list((RUN/'inputs').glob('*.json'))+[RUN/'private-answer-map.json',RUN/'control-expected.json',RUN/'preserved-files.json']
    pre=runtime.preflight()
    catalog=read(Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))/'models_cache.json')
    model=next(m for m in catalog['models'] if m['slug']==MODEL)
    assert {'medium','high'} <= {v['effort'] for v in model['supported_reasoning_levels']}
    pre['cli_sha256']=digest(pre['cli'])
    freeze={'prepared_at':now(),'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
      'authorization':'2026-10-24 user: execute all steps; medium then high; historical preservation',
      'settings':{'model':MODEL,'efforts':['medium','high'],'temperature':'CLI default, not overridden','seed':'not exposed; not specified','timeout_seconds':420,'api_calls':0},
      'preflight':pre,'groups':[g['group_id'] for g in groups],'controls':[g['group_id'] for g in controls],
      'hashes':{str(p.relative_to(ROOT)):digest(p) for p in artifacts},'answer_count':50,'maximum_calls':58,
      'no_holdout':True,'retrospective':True,'grouping_limit':'same-context answers and both rubrics in a call; no fully independent rubric factor; fixed order'}
    write(RUN/'freeze.json',freeze)
    print(json.dumps({'prepared':True,'answers':50,'groups':28,'rubric_requirements':Counter(t['classification'] for c in rb['cases'] if c['expected_result']=='supported_context' for t in c['criteria'])},ensure_ascii=False),flush=True)


def validate(output, inp):
    errors=[]
    errors += [e.message for e in Draft202012Validator(schema()).iter_errors(output)]
    if errors: return errors
    expected={a['answer_id']:a['text'] for a in inp['answers']}
    if sorted(x['answer_id'] for x in output['answers']) != sorted(expected): return ['answer ID mismatch']
    source={b['block']:b['text'] for b in inp['blocks']}
    oldids={x['id'] for x in inp['historical_criteria']}
    revised={x['id']:x for x in inp['revised_criteria'] if x['classification']!='optional'}
    for row in output['answers']:
        text=expected[row['answer_id']]
        for key,ids in [('historical',oldids),('revised',set(revised))]:
            if sorted(x['id'] for x in row[key])!=sorted(ids): errors.append(key+' criterion IDs mismatch')
            for x in row[key]:
                if x['answer_quote'] and x['answer_quote'] not in text: errors.append('answer quote mismatch')
                if x['source_quote'] and x['source_quote'] not in source.get(x['source_block'],''): errors.append('source quote mismatch')
                if x['decision'] in {'full','partial'} and not x['answer_quote']: errors.append('missing positive evidence')
                if key=='historical' and x['decision']=='not_applicable': errors.append('historical not applicable')
                if key=='revised' and x['id'] in revised:
                    if revised[x['id']]['classification']=='required' and x['decision']=='not_applicable': errors.append('required not applicable')
                    if x['support'] in {'full','partial'} and not x['source_quote']: errors.append('missing source evidence')
        for f in row['findings']:
            if f['answer_quote'] and f['answer_quote'] not in text: errors.append('finding answer quote mismatch')
            if f['source_quote'] and f['source_quote'] not in source.get(f['source_block'],''): errors.append('finding source quote mismatch')
    return errors


def check_freeze():
    f=read(RUN/'freeze.json')
    for p,h in f['hashes'].items():
        if digest(ROOT/p)!=h: raise RuntimeError('Frozen input/code changed: '+p)
    for p,h in read(RUN/'preserved-files.json').items():
        if digest(ROOT/p)!=h: raise RuntimeError('Historical artifact changed: '+p)
    return f


def command(pre,temp,effort):
    cmd=legacy.codex_command(pre['cli'],temp,{'codex_model':MODEL},output=False)
    cmd=[s.replace('model_reasoning_effort="medium"',f'model_reasoning_effort="{effort}"') for s in cmd]
    assert f'model_reasoning_effort="{effort}"' in cmd
    return cmd


def finalize_call(out,inp,returncode=None,error=None):
    if (out/'record.json').exists(): return read(out/'record.json')
    events,malformed,usage=runtime.events_and_usage(out/'stdout.jsonl')
    msgs=[e['item']['text'] for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message']
    tools=[e for e in events if e.get('item',{}).get('type') not in {None,'agent_message','reasoning','error'}]
    errs=[]
    if malformed: errs.append('malformed stream')
    if tools: errs.append('tool use forbidden')
    if not any(e.get('type')=='turn.completed' for e in events): errs.append('turn incomplete; no automatic retry')
    if returncode not in (0,None): errs.append('nonzero CLI exit')
    if error: errs.append(error)
    output=None
    try:
        output=json.loads(msgs[-1]);errs+=validate(output,inp)
    except (ValueError,IndexError,TypeError): errs.append('final JSON unavailable')
    record={'finished_at':now(),'input_sha256':canonical(inp),'success':not errs,'errors':errs,'usage':usage,
      'raw_sha256':digest(out/'stdout.jsonl'),'requested':read(out/'intent.json'),
      'server_model_revision':None,'returned_decisions':output}
    write(out/'record.json',record)
    return record


def call(group,effort,pre):
    inp=read(RUN/'inputs'/f'{group}.json');out=RUN/'results'/effort/group
    if (out/'record.json').exists(): return read(out/'record.json')
    if (out/'intent.json').exists():
        # Complete raw turn may be recovered, but dispatched failed calls never retried.
        return finalize_call(out,inp)
    write(out/'intent.json',{'started_at':now(),'model':MODEL,'reasoning_effort':effort,'input_sha256':canonical(inp),'cli_sha256':pre['cli_sha256']})
    write(out/'input.json',inp)
    started=time.monotonic();error=None;rc=None
    with tempfile.TemporaryDirectory(prefix='outwise-answer-judge-') as tmp:
        temp=Path(tmp)
        (temp/'instructions.md').write_text((PUBLIC/'answer_revision_judge.v1.md').read_text(encoding='utf-8'),encoding='utf-8')
        write(temp/'schema.json',schema())
        cmd=command(pre,temp,effort);write(out/'command.json',{'argv':cmd})
        with (out/'stdout.jsonl').open('xb') as stdout,(out/'stderr.txt').open('xb') as stderr:
            proc=subprocess.Popen(cmd,cwd=temp,env=legacy.codex_environment(),stdin=subprocess.PIPE,stdout=stdout,stderr=stderr)
            proc.stdin.write(json.dumps(inp,ensure_ascii=False).encode('utf-8'));proc.stdin.close()
            samples=[]
            while proc.poll() is None:
                try:
                    tree=[psutil.Process(proc.pid)]+psutil.Process(proc.pid).children(recursive=True)
                    rss=sum(p.memory_info().rss for p in tree if p.is_running())
                    avail=psutil.virtual_memory().available
                    samples.append((rss,avail))
                    if rss>4*1024**3 or avail<256*1024**2:
                        error='historical memory guard';proc.kill();break
                except psutil.Error: pass
                if time.monotonic()-started>420:
                    error='timeout; no automatic retry';proc.kill();break
                time.sleep(.1)
            rc=proc.wait()
            stdout.flush();stderr.flush();os.fsync(stdout.fileno());os.fsync(stderr.fileno())
    write(out/'resources.json',{'elapsed_seconds':time.monotonic()-started,'peak_rss':max((r for r,a in samples),default=None),'minimum_available_ram':min((a for r,a in samples),default=None),'sample_interval':.1})
    return finalize_call(out,inp,rc,error)


def run(effort):
    f=check_freeze();pre=f['preflight']
    if effort=='high' and not (RUN/'medium-complete.json').exists(): raise RuntimeError('Medium must complete before High')
    if digest(pre['cli'])!=pre['cli_sha256']: raise RuntimeError('CLI binary changed')
    with runtime.JudgeLock():
        for group in f['controls']+f['groups']:
            r=call(group,effort,pre)
            if not r['success']:
                print(json.dumps({'stopped':True,'effort':effort,'group':group,'errors':r['errors']},ensure_ascii=False),flush=True);return
            if group in f['controls']:
                expected=read(RUN/'control-expected.json');diff=[]
                for row in r['returned_decisions']['answers']:
                    labels=[x['decision'] for x in sorted(row['revised'],key=lambda x:x['id'])]
                    if labels!=expected[row['answer_id']]: diff.append({'id':row['answer_id'],'expected':expected[row['answer_id']],'actual':labels})
                write(RUN/f'control-{effort}.json',{'differences':diff,'agent_authored_control':True})
                if diff: print(json.dumps({'control_failed':diff,'effort':effort}),flush=True);return
            print(json.dumps({'completed':group,'effort':effort,'answers':len(r['returned_decisions']['answers']),'usage':r['usage']},ensure_ascii=False),flush=True)
        write(RUN/f'{effort}-complete.json',{'at':now(),'groups':len(f['groups']),'controls':len(f['controls'])})


def summarize():
    f=check_freeze();rb=read(PUBLIC/'answer_rubric.v1.json');cases={c['id']:c for c in rb['cases']}
    mapping={x['answer_id']:x for x in read(RUN/'private-answer-map.json')}
    totals={}; disagreements=[];allrows=[];usages={};errors=[]
    records={}
    for effort in ('medium','high'):
        usage=Counter();resources=[]
        for group in f['controls']+f['groups']:
            p=RUN/'results'/effort/group/'record.json'
            if not p.exists(): continue
            r=read(p);usage.update(r.get('usage') or {})
            if not r['success']: errors.append({'effort':effort,'group':group,'errors':r['errors']});continue
            res=p.with_name('resources.json')
            if res.exists():resources.append(read(res))
            if group in f['controls']:continue
            for a in r['returned_decisions']['answers']:
                meta=mapping[a['answer_id']];c=cases[meta['case_id']]
                rc={x['id']:x for x in c['criteria']}
                records[(effort,a['answer_id'])]=a
                clean={'answer_id':a['answer_id'],'group':group,'model':meta['model'],'effort':effort,
                  'diagnostic':meta['diagnostic'],'corpus_gap':c['expected_result']=='insufficient_coverage',
                  'historical_agent_decisions':meta['historical_agent_decisions'],
                  'historical':[{k:x[k] for k in ('id','decision','reason')} for x in a['historical']],
                  'revised':[{k:x[k] for k in ('id','decision','reason','support')} for x in a['revised']],
                  'findings':[{k:x[k] for k in ('type','reason')} for x in a['findings']], 'gap_behavior':a['gap_behavior']}
                allrows.append(clean)
                # Fixed core denominator; conditional and gap results separate.
                slice_='diagnostic' if meta['diagnostic'] else 'full25' if meta['model']=='historical-qwen' else 'screen8'
                keys=[(slice_,meta['model'],effort)]
                if not meta['diagnostic'] and meta['case_id'] in {'case-19','case-05','case-08','case-17','case-21','case-23','case-15','case-25'}:
                    keys.append(('matched-screen8',meta['model'],effort))
                for key in keys:
                    t=totals.setdefault('|'.join(key),Counter())
                    t['answers']+=1
                    if clean['corpus_gap']:
                        t['gaps']+=1;t['safe_abstention']+=a['gap_behavior']=='safe_abstention'
                    else:
                        t['supported_answers']+=1
                        for x in a['historical']:t['old_'+x['decision']]+=1;t['old_total']+=1
                        required=[x for x in a['revised'] if rc[x['id']]['classification']=='required']
                        for x in required:t['new_'+x['decision']]+=1;t['new_total']+=1
                        t['new_complete']+=all(x['decision']=='full' for x in required)
                        for x in a['revised']:
                            if rc[x['id']]['classification']=='conditional':t['conditional_'+x['decision']]+=1
                    for kind in {x['type'] for x in a['findings']}:t['flag_'+kind]+=1
        usages[effort]={'tokens':dict(usage),'elapsed_seconds':sum(x['elapsed_seconds'] for x in resources),'calls':len(resources)}
    for aid,meta in mapping.items():
        m=records.get(('medium',aid));h=records.get(('high',aid))
        if not m or not h:continue
        for version in ('historical','revised'):
            md={x['id']:x for x in m[version]};hd={x['id']:x for x in h[version]}
            for cid in md:
                if md[cid]['decision']!=hd[cid]['decision'] or (version=='revised' and md[cid]['support']!=hd[cid]['support']):
                    disagreements.append({'answer_id':aid,'group':meta['group'],'model':meta['model'],'rubric':version,'criterion_id':cid,
                     'medium':md[cid],'high':hd[cid]})
    private={'disagreements':disagreements,'records_available':len(records)}
    public={'version':1,'created_at':now(),'complete':all((RUN/f'{e}-complete.json').exists() for e in ('medium','high')),
      'freeze_sha256':digest(RUN/'freeze.json'),'rubric_sha256':digest(PUBLIC/'answer_rubric.v1.json'),
      'aggregates':{k:dict(v) for k,v in totals.items()},'usage':usages,'rows':allrows,
      'medium_high_disagreements':len(disagreements),'technical_errors':errors,
      'limitations':f['grouping_limit'],'independent_clinical_accuracy':False,'new_answer_generation':0,'paid_api_calls':0}
    # Summaries are versioned snapshots; never overwrite an existing summary.
    n=1
    while (PUBLIC/f'answer_revision_results.v{n}.json').exists():n+=1
    write(PUBLIC/f'answer_revision_results.v{n}.json',public)
    write(RUN/f'disagreements.v{n}.json',private)
    print(json.dumps({'summary_version':n,'complete':public['complete'],'aggregates':public['aggregates'],'disagreements':len(disagreements),'errors':errors},ensure_ascii=False),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['prepare','run','summarize']);ap.add_argument('--effort',choices=['medium','high']);args=ap.parse_args()
    if args.action=='prepare':prepare()
    elif args.action=='run':run(args.effort)
    else:summarize()
