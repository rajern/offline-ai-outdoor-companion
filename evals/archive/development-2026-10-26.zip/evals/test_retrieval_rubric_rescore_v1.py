"""Behavioral checks for evidence validation and source-conditioned retention."""
import copy
import unittest

import rescore_retrieval_locked_v1 as s


class RetrievalRubricTests(unittest.TestCase):
    def setUp(self):
        self.inp = {'context_id':'test','criteria':[{'id':'r1'}],
                    'blocks':[{'block':1,'text':'Åpne låsen. Hold START inne i fem sekunder.'}]}
        self.value = {'context_id':'test','items':[{'id':'r1','decision':'full',
            'evidence':[{'block':1,'quote':'Åpne låsen.'},{'block':1,'quote':'Hold START inne i fem sekunder.'}],
            'missing_components':[],'reason':'Begge ledd er levert.'}], 'findings':[]}

    def test_full_combined_exact_evidence(self):
        self.assertEqual(s.validate(self.value,self.inp),[])
        altered = copy.deepcopy(self.value)
        altered['items'][0]['evidence'][1]['quote'] = 'Hold START inne i sju sekunder.'
        self.assertTrue(s.validate(altered,self.inp))

    def test_ids_cannot_be_omitted_or_duplicated(self):
        missing = {**self.value,'items':[]}
        duplicate = {**self.value,'items':self.value['items']*2}
        self.assertTrue(s.validate(missing,self.inp))
        self.assertTrue(s.validate(duplicate,self.inp))

    def test_positive_and_negative_proof_contract(self):
        altered = copy.deepcopy(self.value)
        altered['items'][0]['evidence'] = []
        self.assertTrue(s.validate(altered,self.inp))
        altered = copy.deepcopy(self.value)
        altered['items'][0]['missing_components'] = ['Ventetid']
        self.assertTrue(s.validate(altered,self.inp))
        for decision in ('partial','absent'):
            altered = copy.deepcopy(self.value)
            altered['items'][0]['decision'] = decision
            self.assertTrue(s.validate(altered,self.inp))

    def test_no_applicability_guess_or_empty_gap_pass(self):
        altered = copy.deepcopy(self.value)
        altered['items'][0]['decision'] = 'not_applicable'
        self.assertTrue(s.validate(altered,self.inp))
        empty_input = {**self.inp,'criteria':[]}
        self.assertEqual(s.validate({'context_id':'test','items':[],'findings':[]},empty_input),[])
        self.assertIsNone(s.retention({}, {})['retention'])

    def test_retention_requires_the_same_criterion(self):
        result = s.retention({'a':'full','b':'absent'},{'a':'absent','b':'full'})
        self.assertEqual(result['available'],1)
        self.assertEqual(result['answer_full_total'],1)
        self.assertEqual(result['preserved'],0)
        self.assertEqual(result['answer_full_without_full_source'],1)
        self.assertEqual(result['retention'],0)
        uncertain = s.retention({'a':'uncertain'},{'a':'full'})
        self.assertEqual(uncertain['available'],0)
        self.assertIsNone(uncertain['retention'])

    def test_control_contract_preserves_conflict_with_coverage(self):
        inputs, expected = s.controls()
        control = inputs[2]
        value = {'items':[{'id':'f1','decision':'full'}],
                 'findings':[{'type':'direct_conflict'}]}
        self.assertEqual(s.control_errors(value,expected[control['context_id']]),[])
        value['items'][0]['decision'] = 'uncertain'
        self.assertTrue(s.control_errors(value,expected[control['context_id']]))


if __name__ == '__main__':
    unittest.main()
