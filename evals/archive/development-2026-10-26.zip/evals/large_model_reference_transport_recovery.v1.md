# Retry watcher correction and completed-output recovery

2026-10-25, within the explicit owner request to continue/fix the reference.
All eight High answers are complete: four reused and four new, no new generation
retry warning. First Medium judge19 encountered one429, waited23.9999151s and
then completed a valid turn/schema/quote-validated judgment with usage8729.

The v1 watcher incorrectly re-evaluated the retained old warning after the final
agent message appeared, treating successful retry output as pre-existing text.
It killed the process during shutdown (nonzero exit), although raw JSONL already
contained the final message AND turn.completed. The raw record's only failure
is nonzero CLI exit. Preserve this failure/raw/code/stop unchanged.

continuation-v2 fixes only watcher state: evaluate policy on newly observed retry
warnings, not the same old warning every poll. Preserve the same commands and
at-least60s spacing, one pre-text429 retry<=300s,1200s/4GiB/256MiB bounds.
Tests cover an allowed retry followed by successful text, then a second warning.
No model/rubric/prompt/source/billing change and no new19 inference.

Copy all eight sealed answers and frozen inputs unchanged. Copy19 raw streams,
intent/input/command/resources and original false record to record.original.json.
Reparse its completed turn and exact schema/quotes, then create an effective
record with recovery metadata: valid completed inference accepted despite
watcher-caused process cancellation. Do not falsely report original exit0.
Remaining seven Medium calls only; total judge CLI dispatches still8. Original
generation attempts total9 (eight answer-producing, one retained failure of
unknown usage). Keep both old stops, partial report, bindings and progress
snapshots; freeze this technical adapter before further inference.
