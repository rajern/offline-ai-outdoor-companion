"""Offline audit and source-free summaries of the frozen, bounded experiment."""
from collections import Counter
import json
from pathlib import Path
import statistics
import generation_improvement_host_transport_v1 as h

s=h.s
ROOT=s.ROOT
PUBLIC=s.PUBLIC
RUN=h.RUN


def coverage(required, assessment, available):
    items={x['id']:x for x in assessment['revised']}
    assert set(required).issubset(items)
    full={key for key in required if items[key]['decision']=='full'}
    return {'core_denominator':len(required),
        'core_counts':dict(Counter(items[key]['decision'] for key in required)),
        'full_ids':sorted(full), 'available_ids':sorted(available),
        'retained_ids':sorted(full & set(available)),
        'fully_supported_full_ids':sorted(key for key in full if items[key]['support']=='full'),
        'core_complete':bool(required) and len(full)==len(required)}


def main():
    h.install();f=s.check_runtime()
    assert s.a.read(RUN/'generation-complete.json')['new_answers']==32
    assert s.a.read(RUN/'judging-complete.json')['new_answers_assessed']==32
    j=s.a.read(RUN/'judge-freeze.json')
    for name,expected in j['hashes'].items():assert s.sha(ROOT/name)==expected,name
    rubrics={x['id']:x for x in s.a.read(PUBLIC/'answer_rubric.v1.json')['cases']}
    retrieval={x['case_id']:x for x in s.a.read(PUBLIC/'retrieval_rubric_rescore_results.v1.json')['rows']}
    specs=[s.a.read(RUN/'definitions'/f'{key}.json') for key in f['spec_ids']]
    by_id={x['anonymous_id']:x for x in specs}
    records={};calls=[]
    for cid in s.CASES:
        folder=RUN/'judges'/cid
        record=s.a.read(folder/'record.json')
        assert record['success'] and not record['errors']
        inp=s.a.read(RUN/'judge-inputs'/f'{cid}.json')
        assert not s.a.validate(record['returned_decisions'],inp)
        wire=json.dumps(inp,ensure_ascii=False).encode('utf-8')
        assert (folder/'stdin.json').read_bytes()==wire
        assert s.a.read(folder/'input.json')==inp
        assert len(record['returned_decisions']['answers'])==4
        for answer in record['returned_decisions']['answers']:
            item=by_id[answer['answer_id']]
            assert item['case_id']==cid
            records[item['id']]=answer
        calls.append({'case_id':cid,'usage':record['usage'],
            'resources':s.a.read(folder/'resources.json'),
            'record_sha256':s.sha(folder/'record.json')})
    assert len(records)==32
    rows=[]
    baseline=s.a.read(RUN/'baseline.json')
    for model in s.MODELS:
        for arm in ['baseline','A','B']:
            for cid in s.CASES:
                if arm=='baseline':
                    entry=next(x for x in baseline if x['model']==model and x['case_id']==cid)
                    answer=entry['assessment'];folder=Path(ROOT/entry['answer_path']).parent
                    assert s.sha(folder/'answer.txt')==entry['answer_sha256']
                else:
                    key=f'{model}-{arm}-{cid}';answer=records[key];folder=RUN/'responses'/key
                s.verify_seal(folder)
                raw=s.a.read(folder/'response.json')
                criteria=rubrics[cid]['criteria']
                required=[x['id'] for x in criteria if x['classification']=='required']
                available=[key for key,value in retrieval[cid]['required'].items() if value=='full']
                core=coverage(required,answer,available)
                row={'model':model,'arm':arm,'case_id':cid,**core,
                    'conditional':[{k:x[k] for k in ['id','decision','support']} for x in answer['revised']
                        if next(c['classification'] for c in criteria if c['id']==x['id'])=='conditional'],
                    'finding_types':sorted(set(x['type'] for x in answer['findings'])),
                    'gap_behavior':answer['gap_behavior'], 'output_tokens':raw['tokens_predicted'],
                    'stop_type':raw['stop_type'],
                    'decisions':[{k:x[k] for k in ['id','decision','support']} for x in answer['revised']],
                    'response_sha256':s.sha(folder/'response.json')}
                rows.append(row)
    groups={}
    for model in s.MODELS:
        for arm in ['baseline','A','B']:
            selected=[x for x in rows if x['model']==model and x['arm']==arm]
            counts=Counter();flags=Counter();gaps=Counter();conditional=Counter()
            for row in selected:
                counts.update(row['core_counts']);flags.update(row['finding_types'])
                if row['gap_behavior']!='not_gap':gaps.update([row['gap_behavior']])
                conditional.update(x['decision'] for x in row['conditional'])
            values={'answers':8,'supported_cases':6,'core_denominator':sum(x['core_denominator'] for x in selected),
                'core_counts':dict(counts),'available':sum(len(x['available_ids']) for x in selected),
                'retained':sum(len(x['retained_ids']) for x in selected),
                'core_complete_cases':sum(x['core_complete'] for x in selected),
                'fully_supported_full':sum(len(x['fully_supported_full_ids']) for x in selected),
                'answers_with_finding':dict(flags),'gap_behavior':dict(gaps),'conditional':dict(conditional),
                'output_tokens':sum(x['output_tokens'] for x in selected),
                'median_output_tokens':statistics.median(x['output_tokens'] for x in selected),
                'stops':dict(Counter(x['stop_type'] for x in selected))}
            assert values['core_denominator']==15 and values['available']==13
            if arm!='baseline':
                gains=[];losses=[]
                for row in selected:
                    before=next(x for x in rows if x['model']==model and x['arm']=='baseline' and x['case_id']==row['case_id'])
                    gains+=sorted(set(row['full_ids'])-set(before['full_ids']))
                    losses+=sorted(set(before['full_ids'])-set(row['full_ids']))
                values.update(gained_full_ids=gains,lost_full_ids=losses)
            groups[f'{model}|{arm}']=values
    usage=Counter()
    for call in calls:
        if isinstance(call['usage'],dict):
            usage.update({k:v for k,v in call['usage'].items() if isinstance(v,int)})
    resources={model:s.a.read(RUN/'runtime'/model/'resources.json') for model in s.MODELS}
    for resource in list(resources.values())+[s.a.read(RUN/'preflight'/m/'resources.json') for m in s.MODELS]:
        assert resource['peak_process_tree_rss_bytes']<=4*1024**3
        assert resource['minimum_available_ram_bytes']>=256*1024**2
    new_dispatches=list((RUN/'responses').glob('*/dispatched.json'))
    assert len(new_dispatches)==32 and len(list((RUN/'judges').glob('*/intent.json')))==8
    assert not (RUN/'stop.json').exists() and not s.g.q.LOCK.exists()
    result={'version':1,'at':s.a.now(),'complete':True,'groups':groups,'rows':rows,
        'new_product_answers':32,'new_judge_calls':8,'reused_baseline_answers':16,
        'judge_model':s.a.MODEL,'reasoning_effort':'medium','known_judge_usage':dict(usage),
        'judge_calls':calls,'local_resources':resources,
        'rubric_sha256':s.sha(PUBLIC/'answer_rubric.v1.json'),
        'limitations':['selected development eight; one seed; no independent clinical gold',
            'baseline judges previously grouped up to three versus four new answers',
            'B is a prompt package; individual wording effects and A+B interaction unmeasured',
            'generation order differs by model; not a causal latency comparison']}
    s.write(PUBLIC/'local_generation_improvement_results.v1.json',result)
    print(json.dumps({'groups':groups,'usage':dict(usage),'resources':resources},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
