"""Use authorized host loopback transport; preserve both zero-dispatch stops."""
from pathlib import Path
import shutil
import sys
import continue_generation_improvement_v1 as c

s=c.s
PARENT=c.RUN
RUN=c.ORIGINAL/'revision-03'
SELF=Path(__file__).resolve()
NOTE=s.PUBLIC/'local_generation_improvement_host_transport.v1.md'


def prepare():
    assert not RUN.exists()
    c.install();s.preservation()
    assert s.a.read(PARENT/'stop.json')['error']=='Local model loading exceeded 120s; no inference'
    assert not list((PARENT/'responses').glob('**/dispatched.json'))
    assert not list((PARENT/'responses').glob('**/response.json'))
    assert not s.g.q.LOCK.exists()
    assert 'model loaded' in (PARENT/'preflight/qwen-2b/stderr.txt').read_text(encoding='utf-8')
    resources=s.a.read(PARENT/'preflight/qwen-2b/resources.json')
    assert resources['minimum_available_ram_bytes']>=256*1024**2
    assert resources['peak_process_tree_rss_bytes']<=4*1024**3
    hashes={str(p.relative_to(s.ROOT)):s.sha(p) for p in PARENT.rglob('*') if p.is_file()}
    RUN.mkdir()
    for name in ['definitions','judge-definitions','before']:
        shutil.copytree(PARENT/name,RUN/name)
    for name in ['definitions.json','baseline.json','reused-control.json','system.A.txt','system.B.txt']:
        shutil.copyfile(PARENT/name,RUN/name)
    s.write(RUN/'host-transport-binding.json',{'at':s.a.now(),'adapter_sha256':s.sha(SELF),
        'note_sha256':s.sha(NOTE),'parent_files':hashes,'previous_completion_dispatches':0,
        'transport':'host permission for local loopback; same Python external-socket denial',
        'changed_experimental_variables':[]})
    install();s.preservation()
    print('Host transport frozen; both zero-dispatch startup attempts unchanged.',flush=True)


def preservation():
    binding=s.a.read(RUN/'host-transport-binding.json')
    assert s.sha(SELF)==binding['adapter_sha256'] and s.sha(NOTE)==binding['note_sha256']
    for name,expected in binding['parent_files'].items():assert s.sha(s.ROOT/name)==expected,name
    return c.preservation()


def install():
    c.install()
    s.RUN=RUN
    s.preservation=preservation


def main():
    action=sys.argv[1]
    if action=='prepare':prepare();return
    install()
    if action in ('preflight','generate'):
        assert not (RUN/'stop.json').exists(),'Retained stop; separate review required'
        with c.local_lock():
            try:s.preflight() if action=='preflight' else s.generate()
            except BaseException as exc:
                s.write(RUN/'stop.json',{'at':s.a.now(),'action':action,'error':str(exc),'automatic_retries':0})
                raise
    elif action=='prepare-judges':s.prepare_judges()
    elif action=='judge':s.judge()
    elif action=='check':print({'definitions_verified':len(s.preservation()['spec_ids'])})
    else:raise ValueError(action)


if __name__=='__main__':main()
