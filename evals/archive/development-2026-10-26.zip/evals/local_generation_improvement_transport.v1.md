# Generation improvement: technical startup adapter v1

2026-10-25. The first preflight stopped with WinError2 before starting the
llama server and before any completion dispatch. The sandbox redirects
LOCALAPPDATA; the inherited launcher consequently constructed a nonexistent
runtime path. Definitions already verified the real, pinned executable and
DLL identities. The adapter selects that exact executable from those identities,
verifies its hash, and changes only the launcher's executable path.

The failed attempt, stop, resource log, definitions and frozen scripts remain
unchanged. A child revision-02 copies the exact prepared definitions, baseline,
control bindings and progress snapshots. Its adapter binding seals the original
attempt plus this note and adapter before preflight. No generated output exists
to recover or repeat. This is a startup repair within the authorized experiment,
not a memory-guard retry, runtime update or change to experimental variables.

The adapter also closes its own exclusive lock handle before unlinking the
lock, as required by Windows. It verifies the lock path and owning PID. The
original launcher tried to unlink its still-open handle, causing a secondary
WinError32 during cleanup. The stale lock was removed only after its PID had
exited; no live inference process was interrupted.

All original memory, timing, native-input, sampling, source, judge and response
limits remain in force. Any subsequent stop is retained and requires a separate
technical review; no automatic unsealed completion retry is introduced.
