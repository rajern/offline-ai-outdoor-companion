"""Independent, inference-free recomputation from sealed raw decisions."""
from collections import Counter, defaultdict
import json
import statistics

import answer_revision_continue_v1 as c

r = c.r


def analyze():
    r.RUN = c.TARGET
    frozen = r.check_freeze()
    assert all((r.RUN / f'{e}-complete.json').exists() for e in ('medium', 'high'))
    cases = {x['id']: x for x in r.read(r.PUBLIC / 'answer_rubric.v1.json')['cases']}
    mapping = {x['answer_id']: x for x in r.read(r.RUN / 'private-answer-map.json')}
    rows = {}
    aggregates = defaultdict(Counter)
    macros = defaultdict(list)
    latency = defaultdict(list)
    resources = defaultdict(list)
    for effort in ('medium', 'high'):
        for group in frozen['controls'] + frozen['groups']:
            record = r.read(r.RUN / 'results' / effort / group / 'record.json')
            assert record['success']
            resource = r.read(r.RUN / 'results' / effort / group / 'resources.json')
            latency[effort].append(resource['elapsed_seconds'])
            resources[effort].append(resource)
            if group in frozen['controls']:
                continue
            for answer in record['returned_decisions']['answers']:
                aid = answer['answer_id']
                meta = mapping[aid]
                case = cases[meta['case_id']]
                rows[effort, aid] = answer
                rubric = {x['id']: x for x in case['criteria']}
                slice_name = 'diagnostic' if meta['diagnostic'] else 'full25' if meta['model'] == 'historical-qwen' else 'screen8'
                slices = [slice_name]
                if not meta['diagnostic'] and meta['case_id'] in {'case-19','case-05','case-08','case-17','case-21','case-23','case-15','case-25'}:
                    slices.append('matched-screen8')
                for slice_ in slices:
                    key = '|'.join((slice_, meta['model'], effort))
                    agg = aggregates[key]
                    agg['answers'] += 1
                    for kind in {x['type'] for x in answer['findings']}:
                        agg['flag_' + kind] += 1
                    if case['expected_result'] == 'insufficient_coverage':
                        agg['gaps'] += 1
                        agg['safe_abstention'] += answer['gap_behavior'] == 'safe_abstention'
                        continue
                    agg['supported_answers'] += 1
                    old = {x['id']: x for x in answer['historical']}
                    required = [x for x in answer['revised'] if rubric[x['id']]['classification'] == 'required']
                    conditional = [x for x in answer['revised'] if rubric[x['id']]['classification'] == 'conditional']
                    for x in old.values():
                        agg['old_' + x['decision']] += 1
                        agg['old_total'] += 1
                    for x in required:
                        old_id = f"{case['id']}/old{rubric[x['id']]['old_item']}"
                        agg['new_' + x['decision']] += 1
                        agg['new_total'] += 1
                        agg['retained_old_' + old[old_id]['decision']] += 1
                        agg['retained_transition_' + old[old_id]['decision'] + '_to_' + x['decision']] += 1
                        if x['decision'] in {'full', 'partial'}:
                            agg['positive_support_' + x['support']] += 1
                    for x in conditional:
                        agg['conditional_' + x['decision']] += 1
                    core_complete = all(x['decision'] == 'full' for x in required)
                    agg['new_complete'] += core_complete
                    agg['old_complete'] += all(x['decision'] == 'full' for x in old.values())
                    agg['new_core_and_conditional_complete'] += core_complete and all(
                        x['decision'] in {'full', 'not_applicable'} for x in conditional)
                    agg['new_core_complete_and_fully_supported'] += core_complete and all(x['support'] == 'full' for x in required)
                    macros[key + '|old'].append(sum(x['decision'] == 'full' for x in old.values()) / len(old))
                    macros[key + '|new'].append(sum(x['decision'] == 'full' for x in required) / len(required))
    agreement = Counter()
    discrepancies = []
    finding_types = Counter()
    for aid, meta in mapping.items():
        m, h = rows['medium', aid], rows['high', aid]
        for version in ('historical', 'revised'):
            hh = {x['id']: x for x in h[version]}
            for x in m[version]:
                y = hh[x['id']]
                agreement[version + '_items'] += 1
                agreement[version + '_decision_equal'] += x['decision'] == y['decision']
                if version == 'revised':
                    agreement['revised_support_equal'] += x['support'] == y['support']
                    if x['decision'] in {'full', 'partial'} and y['decision'] in {'full', 'partial'}:
                        agreement['revised_both_positive_items'] += 1
                        agreement['revised_both_positive_support_equal'] += x['support'] == y['support']
                if x['decision'] != y['decision'] or (version == 'revised' and x['support'] != y['support']):
                    discrepancies.append({'answer_id': aid, 'case': meta['case_id'], 'rubric': version,
                        'criterion_id': x['id'], 'decision_differs': x['decision'] != y['decision'],
                        'support_differs': version == 'revised' and x['support'] != y['support']})
        mt = {x['type'] for x in m['findings']}
        ht = {x['type'] for x in h['findings']}
        finding_types['answers_with_different_flag_type_sets'] += mt != ht
        if cases[meta['case_id']]['expected_result'] == 'insufficient_coverage':
            agreement['gap_answers'] += 1
            agreement['gap_behavior_equal'] += m['gap_behavior'] == h['gap_behavior']
    summaries = sorted(r.PUBLIC.glob('answer_revision_results.v*.json'), key=lambda p: int(p.stem.split('.v')[-1]))
    summary = r.read(summaries[-1])
    assert summary['complete'] and summary['freeze_sha256'] == r.digest(r.RUN / 'freeze.json')
    # Independent loops above must reproduce every common aggregate field.
    for key, counts in summary['aggregates'].items():
        for field, value in counts.items():
            assert aggregates[key][field] == value, (key, field, value, aggregates[key][field])
    assert len(rows) == 100 and len(discrepancies) == summary['medium_high_disagreements']
    artifact = {'at': r.now(), 'freeze_sha256': r.digest(r.RUN / 'freeze.json'),
        'summary_cross_checked': summaries[-1].name, 'all_common_aggregates_recomputed': True,
        'aggregates': {k: dict(v) for k,v in aggregates.items()},
        'macro_full_requirement_coverage': {k: statistics.mean(v) for k,v in macros.items()},
        'effort_agreement': dict(agreement), 'disagreements': discrepancies,
        'finding_type_comparison': dict(finding_types),
        'latency_seconds': {e: {'calls_including_reused': len(v), 'total': sum(v),
            'median': statistics.median(v), 'minimum': min(v), 'maximum': max(v)} for e,v in latency.items()},
        'resource_extremes': {e: {'peak_rss_bytes': max(x['peak_rss'] for x in v),
            'minimum_available_bytes': min(x['minimum_available_ram'] for x in v)} for e,v in resources.items()},
        'interpretation_limits': ['Repeated criteria/answers are not independent observations',
            'Changed rubric is not changed product output', 'Agreement is not correctness',
            'Core complete does not imply clinical safety', 'Original timeout usage is unknown'],
        'analysis_code_sha256': r.digest(__file__)}
    n = 1
    while (r.PUBLIC / f'answer_revision_analysis.v{n}.json').exists():
        n += 1
    r.write(r.PUBLIC / f'answer_revision_analysis.v{n}.json', artifact)
    print(json.dumps({'analysis_version': n, 'aggregate_check': True, 'paired_saved_answers': 50,
        'disagreement_items': len(discrepancies), 'agreement': dict(agreement)}, ensure_ascii=False))


if __name__ == '__main__':
    analyze()
