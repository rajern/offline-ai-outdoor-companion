"""Source-bound workspace review and old/new definition bridge; no inference."""
from collections import Counter
import json

import retrieval_rescore_progress_path_adapter_v1 as adapter

s = adapter.s
r = s.r

NOTES = {
 1:'Hele konteksten kontrollert for de to negative/delvise kravene: manglende belastningsevne kobles ikke til brudd, og mulig brudd kobles ikke til legekontakt. Ro/avlastning er fullt levert.',
 2:'Vått tøy, isolasjon/vind/fukt, sikker varmetilførsel, overvåking og113 finnes direkte i kildene. Enkelte pakkelisteelementer kan være nyttige supplementer snarere enn støy; annen irrelevant tekst er tydelig.',
 3:'Hele konteksten kontrollert: generelle behandlingsråd og kjemikaliebegrensning er levert; de to koketidene/høydegrensen finnes ikke. Ikke fyll dette fra corpus eller diagnosekonteksten.',
 4:'De fem bortkomsthandlingene står samlet og eksplisitt i blokk4. Skred- og annen-situasjonstekst gir ikke motstrid bare fordi den også er handlingsrettet.',
 5:'Eksplisitt lynly, avvisning av overheng og ned fra høyt terreng er levert. Begge betingede begrensninger finnes i universalregelen og kildebeskrevet reserveplan.',
 6:'Alle faktiske blokker kontrollert: direkte trykk, utenpåbandasje og økt trykk, varme/overvåking/113 ved forverring er levert. Ingen regel om initial113-varsling for stor ytre blødning finnes i pakken.',
 7:'Fire kjernekrav har direkte og komplett støtte. Den allerede deklarerte kremuklarheten beholdes som egen kildemerknad uten endring av kjernepoeng eller medisinsk avgjørelse.',
 8:'Luftvei/pustesjekk/10sekunder og sideleie med normal-pust-vilkår og munnen ned er faktisk levert. Bare videre overvåking, ikke HLR-oppstart ved ingen/unormal pust, finnes for r4. Risikoetiketten for113/sideleie-sammendrag er usikker fordi operatørveiledning og vilkåret finnes andre steder i samme pakke.',
 9:'Alle tre forebyggende varmekrav har direkte kildebevis. Merket nedkjølings-/is-/brannskadestoff vurderes som andre scenarioer, ikke som automatisk anvendelig motstrid.',
10:'Den faktisk leverte overskriften gir varmt tøy; utstyrslisten gir sovepose, overlevelsesteppe og nødly. Overskriften er tekst i input, ikke en utledet faktaopplysning fra kilde-ID.',
11:'Alle avstands-/dybdeledd, nedstrømsplassering og håndhygieneledd er levert. Omregningene er omtrentlige slik kriteriet tillater. Kravets relevansbredde er allerede et dokumentert rubrikkforbehold; definisjonen endres ikke her.',
12:'Kryssingsforbud ved flom/usikkerhet/manglende erfaring og vent/snu er eksplisitt kildebeskrevet. Ingen slutning fra uspesifiserte naturforhold er nødvendig.',
13:'PLB beskrives som en aktiverbar nødopsjon, men ikke med klar beskjed om straks å aktivere fremfor å vente. Behold delvis r1 og fraværende betinget tvilsregel. Telefonrådets potensielle misvisning er uavklart: teksten sier ikke at telefon er eneste valg, og mulig nødanrop er ikke avgjort av kildene.',
14:'Bare det støttede delsettet av kunnskapshullet vurderes. Generelle faretegn/endret plan finnes; ingen levert instruks om begrenset skredterreng uten erfaring. Ingen komplett lokal retrettprosedyre eller automatisk gap-pass hevdes.',
15:'Ingen kjernekrav på dette deklarerte kunnskapshullet; tom liste er ikke100prosent. Kildene gir ikke båljuss. Kremmerknaden gjelder kildetekst i annet scenario, ikke et påvist aktuelt bålproblem.',
16:'Vask av sår/hud, lunkent vann og mild/nøytral/uparfymert såpe samt bandasje mot ny skitt er direkte levert. Historisk risikotvist gjenåpnes ikke som en endring av rå historiske funn.',
17:'Generisk113-instruks ved pustevansker/tidskritisk tilstand godtas for det reviderte akutte varslingskravet i den oppgitte situasjonen. Dette beviser ikke at anafylaksiforklaring eller stikkspesifikk prosedyre er levert; de finnes ikke i denne pakken.',
18:'To faktiske kildeblokker gir hodet over vann/returretning, bryte svak kant og minst én komplett oppstigningsmetode etter solid kant. Den oppgitte betingelsen er bevart.',
19:'Utstyrslisten i blokk8 og den faktisk leverte overskriften om de andre i følget i blokk2 dekker hver-person-betydningen sammen. Blokk2 beskriver også praktisk øving. Ingen fakta legges til fra originalartikkelen utenfor pakken.',
20:'Rute/ferdigheter og vær/endre-plan er direkte sitert. Skredspesifikke avsnitt er ikke nødvendigvis nyttige her; generelle planleggingsledd kan være relevante selv i samme blokk.',
21:'Filterets mikrobestørrelse/virusbegrensning og filtrer-før-desinfiser finnes. Produktets bruksanvisning finnes ikke; den delvise dekningen må ikke omtales som bare en LLM-utelatelse.',
22:'Offline NZ-topografikart, nedlasting/testing før avreise, batteri og papirreserve finnes eksplisitt. Ingen slutning fra en utenlandsk kilde til feil jurisdiksjon gjøres.',
23:'30minutter etter siste torden, elektrisk kontaktutstyr og røranlegg er direkte levert. Eksempeloppramsingen brukes ikke som et ekstra krav utover den generelle kategorien.',
24:'Begge avstandskrav har direkte tekstbevis. Denne kildescoren avklarer ikke eller overskriver den tidligere rå LLM-vurderingens kjente konteksttolkningsproblem.',
25:'Ingen kjernekrav på deklarert konstruksjonshull. Utstyrslister og generelle ly-/værord er ikke en kildebeskrevet greinelyprosedyre. Ingen tom-listesuksess.'}


def main():
    frozen = adapter.check_freeze()
    assert (s.RUN/'complete.json').exists()
    old = r.read(s.PUBLIC/'qwen_rag_system_results.v1.json')['rows']
    prior = {x['case_id']:x for x in old}
    rubric = {x['id']:x for x in r.read(s.PUBLIC/'answer_rubric.v1.json')['cases']}
    all_reviews = []
    case_reviews = []
    bridge = Counter()
    changes = []
    flags = Counter()
    for meta in r.read(s.RUN/'case-map.json'):
        case_id = meta['case_id']
        inp = r.read(s.RUN/'inputs'/(meta['context_id']+'.json'))
        record = r.read(s.RUN/'results'/meta['context_id']/'record.json')
        assert record['success']
        value = record['returned_decisions']
        note = NOTES[int(case_id[-2:])]
        for item in value['items']:
            all_reviews.append({'case_id':case_id,'criterion_id':item['id'],
                'raw_decision':item['decision'],'review_disposition':'retain_raw',
                'reviewed':True,'note':note,'input_sha256':r.canonical(inp),
                'record_sha256':r.digest(s.RUN/'results'/meta['context_id']/'record.json')})
        types = {x['type'] for x in value['findings']}
        flags.update(types)
        case_reviews.append({'case_id':case_id,'all_finding_lists_reviewed':True,
            'raw_finding_types':sorted(types),'note':note})
        if inp['expected_result']!='supported_context':
            continue
        raw_new = {x['id']:x['decision'] for x in value['items']}
        old_decisions = prior[case_id]['retrieval_decisions']
        for criterion in rubric[case_id]['criteria']:
            old_full = old_decisions[criterion['old_item']-1]=='covered'
            bridge['old_total'] += 1
            bridge['old_full'] += old_full
            if criterion['classification']=='required':
                bridge['retained_total'] += 1
                bridge['retained_old_full'] += old_full
                new_full = raw_new[criterion['id']]=='full'
                bridge['new_full'] += new_full
                if old_full != new_full:
                    changes.append({'case_id':case_id,'criterion_id':criterion['id'],
                        'old_full':old_full,'new_full':new_full,
                        'old_text':criterion['historical_text'],'new_text':criterion['criterion']})
            else:
                bridge['excluded_total'] += 1
                bridge['excluded_old_full'] += old_full
    assert len(all_reviews)==69 and len(case_reviews)==25
    assert bridge['old_total']==72 and bridge['old_full']==60
    assert bridge['retained_total']==63
    summary = r.read(s.PUBLIC/'retrieval_rubric_rescore_results.v1.json')
    assert bridge['new_full']==summary['core_counts']['full']
    risk_notes = [
        {'case_id':'case-08','raw_type':'potentially_misleading','review_disposition':'uncertain_applicability',
         'reason':'113/sideleie-sammendraget kan leses for bredt, men viser til operatørhjelp og samme pakke gir normal-pust-vilkåret. Ikke en uavhengig påvist klinisk kildefeil.'},
        {'case_id':'case-13','raw_type':'potentially_misleading','review_disposition':'uncertain_applicability',
         'reason':'Telefonrådet kan avlede fra nødpeiler, men sier ikke eksplisitt at telefon er eneste varsling. Fullstendig nettutfall versus mulig nødanrop avgjøres ikke her.'}]
    result = {'at':r.now(),'raw_scores_changed':False,'clinical_validation':False,
        'reviewer':'Current workspace agent, not independent expert; actual model/effort not exposed',
        'scope':'All69 actual main items and25 finding lists inspected. Full positive quote evidence checked against criterion wording; absent/partial actual source contexts checked, with notes below. No exhaustive clinical validation.',
        'criterion_reviews':all_reviews,'case_reviews':case_reviews,
        'raw_finding_context_counts':dict(flags),'risk_review_notes':risk_notes,
        'core_corrections_applied':0,'definition_bridge':dict(bridge),'changed_retained_coverage':changes,
        'answer_linkage_caveat':'Raw Medium judgments are reused. Known case24 inference issue can affect historical full25 retention by one item; this is not silently corrected. Matched screen8 does not include case24.',
        'measurement_uncertainty':'Zero uncertain labels from this judge is not zero epistemic uncertainty. Risk labels and criterion applicability remain author/source-bound judgments.',
        'freeze_sha256':r.digest(s.RUN/'freeze.json'),'review_code_sha256':r.digest(__file__)}
    r.write(s.PUBLIC/'retrieval_rubric_rescore_review.v1.json',result)
    print(json.dumps({'reviewed_items':69,'reviewed_contexts':25,'bridge':dict(bridge),
        'changed_retained':changes,'raw_flags':dict(flags),'risk_ambiguities':2},ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
