"""Offline binding/paired-design audit. Does not invoke any inference."""
from collections import Counter
from pathlib import Path
import json

import answer_rubric_revision_v1 as r

RUN=r.RUN/'transport-v3'


def audit():
    r.RUN=RUN
    freeze=r.check_freeze();checks=[];usage={};paired=0
    paths=[]
    for effort in ('medium','high'):
        tokens=Counter();count=0
        for group in freeze['controls']+freeze['groups']:
            out=RUN/'results'/effort/group
            if not (out/'record.json').exists():continue
            record=r.read(out/'record.json');inp=r.read(RUN/'inputs'/f'{group}.json')
            assert r.read(out/'input.json')==inp
            assert record['input_sha256']==r.canonical(inp)
            assert record['raw_sha256']==r.digest(out/'stdout.jsonl')
            assert record['requested']['model']==r.MODEL
            assert record['requested']['reasoning_effort']==effort
            cmd=r.read(out/'command.json')['argv']
            assert cmd[cmd.index('--model')+1]==r.MODEL
            assert f'model_reasoning_effort="{effort}"' in cmd
            assert '--ignore-user-config' in cmd and '--ignore-rules' in cmd
            assert cmd[cmd.index('--sandbox')+1]=='read-only'
            assert 'features.shell_tool=false' in cmd and 'features.apps=false' in cmd
            assert 'forced_login_method="chatgpt"' in cmd
            if record['success']:assert not r.validate(record['returned_decisions'],inp)
            tokens.update(record.get('usage') or {});count+=1
            checks.append({'group':group,'effort':effort,'success':record['success'],'errors':record['errors']})
            paths += list(out.glob('*.json'))+[out/'stdout.jsonl',out/'stderr.txt']
        usage[effort]={'completed_records':count,'tokens':dict(tokens)}
    for group in freeze['groups']:
        m=RUN/'results/medium'/group/'input.json';h=RUN/'results/high'/group/'input.json'
        if m.exists() and h.exists():assert r.read(m)==r.read(h);paired+=1
    current=r.read(RUN/'private-answer-map.json')
    assert len(current)==50 and len({x['answer_id'] for x in current})==50
    public={'version':1,'at':r.now(),'complete':all((RUN/f'{e}-complete.json').exists() for e in ('medium','high')),
       'frozen_checks_passed':True,'historical_preserved_files':len(r.read(RUN/'preserved-files.json')),
       'answers_bound':50,'paired_main_inputs_verified':paired,'expected_paired_main_inputs':28,
       'per_call_checks':checks,'usage':usage,'new_product_model_calls':0,'paid_api_calls':0,
       'server_revision_verified':False,'requested_model':r.MODEL,'requested_efforts':['medium','high'],
       'source_and_answer_quotes_checked_for_occurrence':True,'semantic_entailment_automatically_proven':False,
       'holdout_accessed':False,'production_changes':False,
       'frozen_sha256':r.digest(RUN/'freeze.json'),
       'public_artifact_hashes':{str(p.relative_to(r.ROOT)):r.digest(p) for p in r.PUBLIC.glob('answer_*v1.*')}}
    r.write(RUN/'final-record-seals.json',{str(p.relative_to(r.ROOT)):r.digest(p) for p in paths})
    r.write(r.PUBLIC/'answer_revision_audit.v1.json',public)
    print(json.dumps({'complete':public['complete'],'answers_bound':50,'paired_inputs':paired,'preserved':public['historical_preserved_files'],'records':len(checks)}))


if __name__=='__main__':audit()
