"""Behavioral checks for experimental isolation and durable-call safety."""
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path
import run_generation_improvement_v1 as r


@contextmanager
def workspace_temp():
    parent=r.ROOT/'knowledge/local'
    obj=tempfile.TemporaryDirectory(prefix='generation-improvement-test-',dir=parent)
    target=Path(obj.name).resolve()
    assert target.is_relative_to(parent.resolve()) and target!=parent.resolve()
    try:yield str(target)
    finally:obj.cleanup()


class ImprovementChecks(unittest.TestCase):
    def test_only_approved_sampling_changes(self):
        for model in r.MODELS:
            old=r.settings(model,'B');new=r.settings(model,'A')
            changed={k for k in old if old[k]!=new[k]}
            expected={'temperature','top_p','min_p','presence_penalty'} if model=='qwen-2b' else {'temperature','top_p','top_k','min_p'}
            self.assertEqual(changed,expected)
            for key in ('seed','n_predict','samplers','repeat_last_n','ignore_eos'):
                self.assertEqual(old[key],new[key])

    def test_effective_sampling_mismatch_detected(self):
        expected=r.settings('qwen-2b','B')
        actual={k:v for k,v in expected.items() if k!='cache_prompt'}
        self.assertFalse(r.close_settings(actual,expected))
        actual['min_p']=0.0
        self.assertTrue(r.close_settings(actual,expected))

    def test_dispatched_unsealed_answer_never_retried(self):
        with workspace_temp() as name:
            folder=Path(name);(folder/'dispatched.json').write_text('{}')
            with self.assertRaisesRegex(RuntimeError,'no automatic retry'):
                r.assert_no_dispatch(folder)

    def test_sealed_raw_modification_detected(self):
        with workspace_temp() as name:
            folder=Path(name);raw=folder/'response.json';raw.write_text('original')
            r.write(folder/'seal.json',{'response.json':r.sha(raw)})
            r.verify_seal(folder);raw.write_text('changed')
            with self.assertRaises(AssertionError):r.verify_seal(folder)

    def test_existing_judge_control_and_schema_unchanged(self):
        inp=r.a.read(r.PARENT/'inputs/control-equipment.json')
        out=r.a.read(r.PARENT/'results/medium/control-equipment/record.json')['returned_decisions']
        self.assertFalse(r.a.validate(out,inp))
        out['answers'][0]['revised'][0]['answer_quote']='not in the actual answer'
        self.assertIn('answer quote mismatch',r.a.validate(out,inp))


if __name__=='__main__':unittest.main()
