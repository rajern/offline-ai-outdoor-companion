"""One frozen 32-answer A/B experiment; saved-context generation and Medium judging."""
from __future__ import annotations
import gc
import json
import random
import re
import shutil
import subprocess
import sys
import tempfile
import time
from collections import Counter
from pathlib import Path

import answer_rubric_revision_v1 as a
import resume_local_generation_v1 as g

ROOT, PUBLIC = a.ROOT, a.PUBLIC
RUN = ROOT/'knowledge/local/diagnostics/local-generation-improvement-v1-2026-10-25'
BASE = ROOT/'knowledge/local/diagnostics/local-generation-eligible-2026-10-24'
PARENT = ROOT/'knowledge/local/diagnostics/answer-rubric-revision-v1-2026-10-24/continuation-v1'
RETRIEVAL = ROOT/'knowledge/local/diagnostics/retrieval-rubric-locked-v1-2026-10-25'
PROTOCOL = PUBLIC/'local_generation_improvement_protocol.v1.md'
CASES = ['case-19','case-05','case-08','case-17','case-21','case-23','case-15','case-25']
MODELS = ['qwen-2b','gemma-e2b']
ALLOWED = {'TASKS.md','evals/AGENTS.md'}
SAMPLERS = ['penalties','dry','top_n_sigma','top_k','typ_p','top_p','min_p','xtc','temperature']
COMMON = dict(n_predict=512, seed=42, stream=False, cache_prompt=False,
    dynatemp_range=0.0, dynatemp_exponent=1.0, top_n_sigma=-1.0,
    xtc_probability=0.0, xtc_threshold=0.1, typical_p=1.0,
    repeat_last_n=64, repeat_penalty=1.0, presence_penalty=0.0, frequency_penalty=0.0,
    dry_multiplier=0.0, dry_base=1.75, dry_allowed_length=2, dry_penalty_last_n=64,
    dry_sequence_breakers=['\n',':','"','*'], mirostat=0, mirostat_tau=5.0,
    mirostat_eta=0.1, adaptive_target=-1.0, adaptive_decay=0.9,
    stop=[], ignore_eos=False, samplers=SAMPLERS)


def sha(p):
    return g.q.sha(Path(p))


def write(p, value):
    a.write(p, value)


def settings(model, arm):
    result = {**COMMON, 'temperature':0.2,'top_p':0.8,'top_k':20,'min_p':0.05}
    if arm == 'A':
        result.update(temperature=1.0,top_p=1.0 if model=='qwen-2b' else .95,
            top_k=20 if model=='qwen-2b' else 64,min_p=0.0,
            presence_penalty=2.0 if model=='qwen-2b' else 0.0)
    assert model in MODELS and arm in ('A','B')
    return result


def close_settings(actual, expected):
    errors=[]
    for key, value in expected.items():
        if key in ('cache_prompt',):
            continue  # Request property, not returned generation setting.
        got=actual.get(key)
        if isinstance(value,float):
            ok=isinstance(got,(int,float)) and abs(got-value)<1e-6
        else:
            ok=got==value
        if not ok:
            errors.append(f'{key}: expected {value!r}; actual {got!r}')
    return errors


def verify_seal(folder):
    for name, expected in a.read(folder/'seal.json').items():
        assert sha(folder/name)==expected, str(folder/name)


def assert_no_dispatch(folder):
    if (folder/'dispatched.json').exists() and not (folder/'seal.json').exists():
        raise RuntimeError('Previously dispatched unsealed call; no automatic retry: '+str(folder))


def preservation():
    frozen=a.read(RUN/'definitions.json')
    for name, expected in frozen['protected'].items():
        normalized=name.replace('\\','/')
        path=RUN/'before'/normalized if normalized in ALLOWED else ROOT/name
        assert sha(path)==expected, name
    for name,expected in frozen['hashes'].items():
        assert sha(ROOT/name)==expected,name
    return frozen


def prepare():
    assert not RUN.exists(), 'Existing run must not be overwritten'
    parent=a.read(RETRIEVAL/'closeout-seals.json')
    protected=dict(parent['hashes'])
    for folder in ['generation-improvement-research-v1-2026-10-25','generation-prompt-research-v1-2026-10-25']:
        manifest=ROOT/'knowledge/local/diagnostics'/folder/'closeout.json'
        protected.update(a.read(manifest)['hashes'])
        protected[str(manifest.relative_to(ROOT))]=sha(manifest)
    for name,expected in protected.items():
        assert sha(ROOT/name)==expected,name
    oldfreeze=a.read(BASE/'experiment-freeze.json')
    for name,expected in oldfreeze['identities'].items():
        assert sha(name)==expected,name
    pre=a.runtime.preflight(); pre['cli_sha256']=sha(pre['cli'])
    assert pre['cli_sha256']==a.read(PARENT/'freeze.json')['preflight']['cli_sha256']
    RUN.mkdir(parents=True)
    for name in ALLOWED:
        dest=RUN/'before'/name; dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(ROOT/name,dest)
    old_system=(PUBLIC/'local_generation_prompt.v1.md').read_text(encoding='utf-8').strip()
    proposal=(PUBLIC/'local_generation_prompt_proposal.v1.md').read_text(encoding='utf-8')
    new_system=re.findall(r'```text\n(.*?)\n```',proposal,re.S)[0].strip()
    (RUN/'system.A.txt').write_text(old_system,encoding='utf-8')
    (RUN/'system.B.txt').write_text(new_system,encoding='utf-8')
    oldplans=a.read(g.p.RUN/'input-freeze.json')['inputs']
    spec=[]; oldmap=a.read(PARENT/'private-answer-map.json'); baseline=[]
    rng=random.Random(20261025)
    identifiers=list(range(1,33));rng.shuffle(identifiers)
    for model in MODELS:
        for arm in ('A','B'):
            for cid in CASES:
                original=next(i for i in oldplans if i['id']==cid)
                verify_seal(BASE/'responses'/model/cid)
                raw=a.read(BASE/'responses'/model/cid/'response.json')
                assert not close_settings(raw['generation_settings'],settings(model,'B'))
                messages=[{'role':'system','content':old_system if arm=='A' else new_system},original['messages'][1]]
                assert messages[1]==original['messages'][1]
                if arm=='A':assert messages==original['messages']
                item={'id':f'{model}-{arm}-{cid}','case_id':cid,'model':model,'arm':arm,
                    'anonymous_id':f'N{identifiers.pop():03d}','question':original['question'],
                    'context_path':original['context_path'],'context_sha256':original['context_sha256'],
                    'messages':messages,'seed':42,'settings':settings(model,arm)}
                write(RUN/'definitions'/f'{item["id"]}.json',item);spec.append(item['id'])
        for cid in CASES:
            entry=next(x for x in oldmap if x['case_id']==cid and not x['diagnostic'] and x['model']==model)
            record=a.read(PARENT/'results/medium'/cid/'record.json')
            assert record['success']
            row=next(x for x in record['returned_decisions']['answers'] if x['answer_id']==entry['answer_id'])
            assert sha(ROOT/entry['answer_path'])==entry['answer_sha256']
            baseline.append({**entry,'assessment':row,'record_sha256':sha(PARENT/'results/medium'/cid/'record.json')})
    write(RUN/'baseline.json',baseline)
    for cid in CASES:
        inp=a.read(PARENT/'inputs'/f'{cid}.json')
        inp['answers']=[]
        write(RUN/'judge-definitions'/f'{cid}.json',inp)
    # Byte-identical previously passed control, same evaluator assets and CLI.
    control=a.read(PARENT/'results/medium/control-equipment/record.json')
    assert control['success'] and not a.validate(control['returned_decisions'],a.read(PARENT/'inputs/control-equipment.json'))
    assert not a.read(PARENT/'control-medium.json')['differences']
    write(RUN/'reused-control.json',{'record_path':str((PARENT/'results/medium/control-equipment/record.json').relative_to(ROOT)),
        'record_sha256':sha(PARENT/'results/medium/control-equipment/record.json'),
        'input_sha256':sha(PARENT/'inputs/control-equipment.json'),'new_inference':0})
    for p in PARENT.rglob('*'):
        if p.is_file():protected.setdefault(str(p.relative_to(ROOT)),sha(p))
    paths=[PROTOCOL,Path(__file__),PUBLIC/'test_generation_improvement_v1.py',PUBLIC/'local_generation_prompt_proposal.v1.md',
        PUBLIC/'answer_rubric.v1.json',PUBLIC/'answer_revision_judge.v1.md',PUBLIC/'answer_revision_schema.v1.json']
    for module in list(sys.modules.values()):
        f=getattr(module,'__file__',None)
        if f:
            p=Path(f).resolve()
            if p.suffix=='.py' and (p.is_relative_to(PUBLIC) or p.is_relative_to(ROOT/'backend/outwise')):
                paths.append(p)
    paths+=list(RUN.rglob('*.json'))+[RUN/'system.A.txt',RUN/'system.B.txt']
    write(RUN/'definitions.json',{'at':a.now(),'authorization':'2026-10-25 owner execute agreed 32-answer round',
        'models':MODELS,'cases':CASES,'arms':['A','B'],'spec_ids':spec,'maximum_product_answers':32,
        'maximum_judge_calls':8,'judge_group_size':4,'judge_timeout':1200,'preflight':pre,
        'protected':protected,'allowed_progress_changes':sorted(ALLOWED),
        'hashes':{str(p.relative_to(ROOT)):sha(p) for p in set(paths)},
        'model_runtime_identities':oldfreeze['identities'],
        'control_reuse':'same prompt/schema/CLI/identical passed control',
        'no_paid_api':True,'no_reset':True,'no_holdout':True})
    preservation()
    print(json.dumps({'prepared':True,'product_definitions':len(spec),'baseline':len(baseline),'judge_calls_max':8}),flush=True)


def preflight():
    frozen=preservation();g.p.windows.offline()
    for model in MODELS:
        folder=RUN/'preflight'/model
        if (folder/'seal.json').exists():verify_seal(folder);continue
        assert not folder.exists(), 'Uncompleted load preserved; no automatic retry'
        with g.Resources() as resources:
            try:
                resources.check(); embedder=g.p.LocalEmbedder(g.q.t.s.runtime.LOCAL/'embedding-model')
                with g.server(g.MODELS[model]['path'],folder,resources) as request:
                    props=request('/props');write(folder/'props.json',props)
                    actual=props['default_generation_settings']['n_ctx']
                    metadata=g.gguf_metadata(g.MODELS[model]['path']);write(folder/'metadata.json',metadata)
                    training=metadata[metadata['general.architecture']+'.context_length']
                    assert actual==4096
                    for key in frozen['spec_ids']:
                        item=a.read(RUN/'definitions'/f'{key}.json')
                        if item['model']!=model:continue
                        native=g.native_input(request,item,actual,training,model)
                        if model=='gemma-e2b':assert native['tokens'].count(metadata['tokenizer.ggml.bos_token_id'])==1
                        old=a.read(BASE/'preflight'/model/'inputs'/f'{item["case_id"]}.json')
                        if item['arm']=='A':assert native['prompt']==old['prompt'] and native['tokens']==old['tokens']
                        write(folder/'inputs'/f'{key}.json',native)
                    assert embedder is not None
            finally:write(folder/'resources.json',resources.result())
        g.seal(folder,[p for p in folder.rglob('*') if p.is_file()]);del embedder;gc.collect()
        print(json.dumps({'preflight':model,'inputs':16,'resources':resources.result()}),flush=True)
    paths=[p for p in (RUN/'preflight').rglob('*') if p.is_file()]
    write(RUN/'runtime-freeze.json',{'at':a.now(),'definitions_sha256':sha(RUN/'definitions.json'),
        'hashes':{str(p.relative_to(ROOT)):sha(p) for p in paths},'no_product_answers_yet':not (RUN/'responses').exists()})


def check_runtime():
    f=preservation();v=a.read(RUN/'runtime-freeze.json')
    assert v['definitions_sha256']==sha(RUN/'definitions.json')
    for name,h in v['hashes'].items():assert sha(ROOT/name)==h,name
    for name,h in f['model_runtime_identities'].items():assert sha(name)==h,name
    return f


def generate():
    frozen=check_runtime();g.p.windows.offline()
    for model in MODELS:
        ordered=[f'{model}-{arm}-{cid}' for arm in (('A','B') if model=='qwen-2b' else ('B','A')) for cid in CASES]
        if all((RUN/'responses'/key/'seal.json').exists() for key in ordered):
            for key in ordered:verify_seal(RUN/'responses'/key)
            continue
        folder=RUN/'runtime'/model
        assert not folder.exists(), 'Prior runtime retained; reviewed resume required'
        with g.Resources() as resources:
            try:
                resources.check();embedder=g.p.LocalEmbedder(g.q.t.s.runtime.LOCAL/'embedding-model')
                with g.server(g.MODELS[model]['path'],folder,resources) as request:
                    props=request('/props');write(folder/'props.json',props)
                    assert props['default_generation_settings']['n_ctx']==4096
                    for key in ordered:
                        item=a.read(RUN/'definitions'/f'{key}.json');out=RUN/'responses'/key
                        if (out/'seal.json').exists():verify_seal(out);continue
                        assert_no_dispatch(out)
                        native=a.read(RUN/'preflight'/model/'inputs'/f'{key}.json')
                        payload={**item['settings'],'prompt':native['tokens']}
                        write(out/'request.json',payload)
                        write(out/'dispatched.json',{'at':a.now(),'input_sha256':a.canonical(payload),
                            'definitions_sha256':sha(RUN/'definitions.json'),'runtime_freeze_sha256':sha(RUN/'runtime-freeze.json')})
                        start=time.monotonic()
                        raw=g.guarded_completion(request,payload,resources)
                        write(out/'response.json',raw)  # Always preserve before validating.
                        current=request('/props');write(out/'props-after.json',current)
                        assert current['default_generation_settings']['n_ctx']==4096
                        assert not raw.get('truncated') and raw['tokens_evaluated']==native['input_tokens']
                        assert raw['tokens_predicted']<=512 and raw['stop_type'] in ('eos','word','limit')
                        assert not close_settings(raw['generation_settings'],item['settings']),close_settings(raw['generation_settings'],item['settings'])
                        assert raw['content'].strip()
                        (out/'answer.txt').write_text(raw['content'],encoding='utf-8')
                        write(out/'result.json',{'at':a.now(),'key':key,'anonymous_id':item['anonymous_id'],
                            'elapsed_seconds':time.monotonic()-start,'tokens_in':raw['tokens_evaluated'],
                            'tokens_out':raw['tokens_predicted'],'stop_type':raw['stop_type'],'resources':resources.result()})
                        g.seal(out,[p for p in out.iterdir() if p.is_file()])
                        print(json.dumps({'generated':key,'output_tokens':raw['tokens_predicted'],'stop':raw['stop_type']}),flush=True)
                    assert embedder is not None
            finally:write(folder/'resources.json',resources.result())
        del embedder;gc.collect()
    check_runtime()
    write(RUN/'generation-complete.json',{'at':a.now(),'new_answers':32,'automatic_retries':0})


def prepare_judges():
    frozen=check_runtime();assert (RUN/'generation-complete.json').exists()
    assert not (RUN/'judge-freeze.json').exists()
    for cid in CASES:
        inp=a.read(RUN/'judge-definitions'/f'{cid}.json')
        for key in frozen['spec_ids']:
            item=a.read(RUN/'definitions'/f'{key}.json')
            if item['case_id']!=cid:continue
            out=RUN/'responses'/key;verify_seal(out)
            inp['answers'].append({'answer_id':item['anonymous_id'],'text':(out/'answer.txt').read_text(encoding='utf-8')})
        inp['answers'].sort(key=lambda x:x['answer_id'])
        assert len(inp['answers'])==4
        write(RUN/'judge-inputs'/f'{cid}.json',inp)
    paths=list((RUN/'judge-inputs').glob('*.json'))
    paths+=[p for p in (RUN/'responses').rglob('*') if p.is_file()]
    write(RUN/'judge-freeze.json',{'at':a.now(),'runtime_freeze_sha256':sha(RUN/'runtime-freeze.json'),
        'model':a.MODEL,'effort':'medium','timeout_seconds':1200,'maximum_calls':8,
        'prompt_sha256':sha(PUBLIC/'answer_revision_judge.v1.md'),'schema_sha256':sha(PUBLIC/'answer_revision_schema.v1.json'),
        'hashes':{str(p.relative_to(ROOT)):sha(p) for p in paths}})
    print('All32 answers sealed; eight blinded judge inputs frozen.',flush=True)


def judge_one(cid,pre):
    inp=a.read(RUN/'judge-inputs'/f'{cid}.json');out=RUN/'judges'/cid
    if (out/'record.json').exists():return a.read(out/'record.json')
    if (out/'intent.json').exists():
        raise RuntimeError('Prior judge dispatch retained; inspect completed output before reviewed recovery')
    assert a.psutil.virtual_memory().available>=256*1024**2
    write(out/'intent.json',{'at':a.now(),'model':a.MODEL,'reasoning_effort':'medium',
        'input_sha256':a.canonical(inp),'cli_sha256':sha(pre['cli']),'timeout_seconds':1200})
    write(out/'input.json',inp)
    wire=json.dumps(inp,ensure_ascii=False).encode('utf-8');(out/'stdin.json').write_bytes(wire)
    temp_root=RUN/'temp';temp_root.mkdir(exist_ok=True)
    started=time.monotonic();error=None;samples=[]
    with tempfile.TemporaryDirectory(prefix='gen-judge-',dir=temp_root) as tmp:
        temp=Path(tmp)
        assert temp.resolve().is_relative_to(temp_root.resolve()) and temp.resolve()!=temp_root.resolve()
        shutil.copyfile(PUBLIC/'answer_revision_judge.v1.md',temp/'instructions.md')
        shutil.copyfile(PUBLIC/'answer_revision_schema.v1.json',temp/'schema.json')
        command=a.command(pre,temp,'medium');write(out/'command.json',{'argv':command})
        with (out/'stdout.jsonl').open('xb') as stdout,(out/'stderr.txt').open('xb') as stderr:
            proc=subprocess.Popen(command,cwd=temp,env=a.legacy.codex_environment(),stdin=subprocess.PIPE,stdout=stdout,stderr=stderr)
            proc.stdin.write(wire);proc.stdin.close()
            while proc.poll() is None:
                try:
                    tree=[a.psutil.Process(proc.pid)]+a.psutil.Process(proc.pid).children(recursive=True)
                    rss=sum(p.memory_info().rss for p in tree if p.is_running());avail=a.psutil.virtual_memory().available
                    samples.append((rss,avail))
                    if rss>4*1024**3 or avail<256*1024**2:error='memory guard';proc.kill();break
                except a.psutil.Error:pass
                if time.monotonic()-started>1200:error='timeout; no automatic retry';proc.kill();break
                time.sleep(.1)
            rc=proc.wait();stdout.flush();stderr.flush()
    write(out/'resources.json',{'elapsed_seconds':time.monotonic()-started,
        'peak_rss':max((x for x,y in samples),default=None),'minimum_available_ram':min((y for x,y in samples),default=None)})
    result=a.finalize_call(out,inp,rc,error)
    return result


def judge():
    f=check_runtime();j=a.read(RUN/'judge-freeze.json')
    assert sha(f['preflight']['cli'])==f['preflight']['cli_sha256']
    assert j['prompt_sha256']==sha(PUBLIC/'answer_revision_judge.v1.md')
    assert j['schema_sha256']==sha(PUBLIC/'answer_revision_schema.v1.json')
    for name,h in j['hashes'].items():assert sha(ROOT/name)==h,name
    with a.runtime.JudgeLock():
        for cid in CASES:
            record=judge_one(cid,f['preflight'])
            print(json.dumps({'judged':cid,'success':record['success'],'errors':record['errors'],'usage':record['usage']}),flush=True)
            if not record['success']:raise RuntimeError('Judge stopped: '+cid)
    write(RUN/'judging-complete.json',{'at':a.now(),'new_judge_calls':8,'new_answers_assessed':32})


def main():
    action=sys.argv[1]
    if action=='prepare':prepare();return
    if action in ('preflight','generate'):
        assert not (RUN/'stop.json').exists(),'Retained stop; reviewed adapter required'
        with g.q.LOCK.open('x',encoding='utf-8') as lock:
            lock.write(str(__import__('os').getpid()))
            try:
                preflight() if action=='preflight' else generate()
            except BaseException as exc:
                write(RUN/'stop.json',{'at':a.now(),'action':action,'error':str(exc),'automatic_retries':0})
                raise
            finally:g.q.LOCK.unlink()
    elif action=='prepare-judges':prepare_judges()
    elif action=='judge':judge()
    elif action=='check':print({'definitions_verified':len(preservation()['spec_ids'])})
    else:raise ValueError(action)


if __name__=='__main__':main()
