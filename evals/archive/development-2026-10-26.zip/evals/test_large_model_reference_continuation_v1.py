import json
import unittest
from continue_large_model_reference_v1 import retry_policy


class RetryPolicyTests(unittest.TestCase):
    def test_only_one_short_pretext429_retry(self):
        warning='stream disconnected - retrying sampling request (1/5 in 201.99s)... last status: 429 Too Many Requests'
        self.assertTrue(retry_policy(warning,'').startswith('allow'))
        self.assertTrue(retry_policy(warning+'\n'+warning,'').startswith('stop'))
        message=json.dumps({'item':{'type':'agent_message','text':'partial answer'}})
        self.assertTrue(retry_policy(warning,message).startswith('stop'))
        self.assertTrue(retry_policy(warning.replace('201.99','301'),'').startswith('stop'))
        self.assertEqual(retry_policy('',''),'none')


if __name__=='__main__':unittest.main()
