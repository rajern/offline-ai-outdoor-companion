"""Independent offline recomputation of input, response and judge bindings."""
import json
import subprocess
import sys
import generation_improvement_host_transport_v1 as h

s=h.s
RUN=h.RUN


def main():
    h.install();f=s.check_runtime()
    result=s.a.read(s.PUBLIC/'local_generation_improvement_results.v1.json')
    checks=[];native_tokens=[];output_tokens=[]
    for key in f['spec_ids']:
        item=s.a.read(RUN/'definitions'/f'{key}.json')
        folder=RUN/'responses'/key;s.verify_seal(folder)
        native=s.a.read(RUN/'preflight'/item['model']/'inputs'/f'{key}.json')
        old=s.a.read(s.BASE/'preflight'/item['model']/'inputs'/f'{item["case_id"]}.json')
        raw=s.a.read(folder/'response.json');request=s.a.read(folder/'request.json')
        assert request=={**item['settings'],'prompt':native['tokens']}
        assert s.a.canonical(request)==s.a.read(folder/'dispatched.json')['input_sha256']
        assert raw['content']==(folder/'answer.txt').read_text(encoding='utf-8')
        assert not raw.get('truncated') and raw['tokens_evaluated']==len(native['tokens'])==native['input_tokens']
        assert len(native['tokens'])<=3200 and len(native['tokens'])+512<=4096
        assert native['actual_context']==4096 and native['context_sha256']==item['context_sha256']
        assert not s.close_settings(raw['generation_settings'],item['settings'])
        assert raw['tokens_predicted']<=512 and raw['stop_type'] in ['eos','word','limit']
        if item['arm']=='A':assert native['tokens']==old['tokens'] and native['prompt']==old['prompt']
        assert all(message['content'] in native['prompt'] for message in item['messages'])
        native_tokens.append(native['input_tokens']);output_tokens.append(raw['tokens_predicted'])
    checks.append('32 exact requests/raw responses/native inputs/effective sampler fields and sealed answer texts')
    usage={};judge_seconds=0
    for cid in s.CASES:
        folder=RUN/'judges'/cid
        inp=s.a.read(folder/'input.json');record=s.a.read(folder/'record.json')
        expected=s.a.read(RUN/'judge-definitions'/f'{cid}.json')
        assert {k:v for k,v in inp.items() if k!='answers'}=={k:v for k,v in expected.items() if k!='answers'}
        assert len(inp['answers'])==4
        assert record['success'] and record['input_sha256']==s.a.canonical(inp)
        assert record['raw_sha256']==s.sha(folder/'stdout.jsonl')
        assert record['requested']['model']==s.a.MODEL and record['requested']['reasoning_effort']=='medium'
        assert record['requested']['timeout_seconds']==1200
        events,malformed,actual_usage=s.a.runtime.events_and_usage(folder/'stdout.jsonl')
        assert not malformed and actual_usage==record['usage']
        assert any(x.get('type')=='turn.completed' for x in events)
        assert not [e for e in events if e.get('item',{}).get('type') not in {None,'agent_message','reasoning','error'}]
        messages=[e['item']['text'] for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message']
        assert json.loads(messages[-1])==record['returned_decisions']
        assert not s.a.validate(record['returned_decisions'],inp)
        command=s.a.read(folder/'command.json')['argv']
        assert 'model_reasoning_effort="medium"' in command and 'read-only' in command
        resources=s.a.read(folder/'resources.json')
        assert resources['peak_rss']<=4*1024**3 and resources['minimum_available_ram']>=256*1024**2
        assert resources['elapsed_seconds']<=1200
        judge_seconds+=resources['elapsed_seconds']
        for key,value in actual_usage.items():usage[key]=usage.get(key,0)+value
    assert usage==result['known_judge_usage']
    checks.append('Eight complete no-tools raw judge streams independently parsed; all decisions/usage/schema/quotes match')
    assert len(list((RUN/'responses').glob('*/dispatched.json')))==32
    assert len(list((RUN/'judges').glob('*/intent.json')))==8
    assert not list((h.PARENT/'responses').glob('**/dispatched.json'))
    assert not list((h.c.ORIGINAL/'responses').glob('**/dispatched.json'))
    checks.append('Exactly32 product dispatches and8 sequential judge dispatches; both old startup attempts zero')
    assert s.a.read(RUN/'source-review-before-final-scores.json')['all_new_answers_read']==32
    review=s.a.read(s.PUBLIC/'local_generation_improvement_review.v1.json')
    assert len(review['answers'])==32 and all(x['reviewed_against_sources'] for x in review['answers'])
    assert review['raw_scores_changed'] is False
    checks.append('All32 new answers/criterion decisions/findings source-reviewed; caveats separate from raw scores')
    for model in s.MODELS:
        for phase in ['preflight','runtime']:
            resources=s.a.read(RUN/phase/model/'resources.json')
            assert resources['peak_process_tree_rss_bytes']<=4*1024**3
            assert resources['minimum_available_ram_bytes']>=256*1024**2
    checks.append('Both preflight and generation groups and all judge guards within unchanged sampled RAM limits')
    changed=subprocess.check_output(['git','diff','--name-only'],cwd=s.ROOT,text=True).splitlines()
    assert set(changed).issubset(s.ALLOWED),changed
    assert not s.g.q.LOCK.exists() and not (RUN/'stop.json').exists()
    checks.append('Protected historical hashes unchanged; only allowed tracked progress documents differ; no remaining local lock')
    audit={'at':s.a.now(),'passed':True,'checks':checks,'definitions_sha256':s.sha(RUN/'definitions.json'),
        'runtime_freeze_sha256':s.sha(RUN/'runtime-freeze.json'),'judge_freeze_sha256':s.sha(RUN/'judge-freeze.json'),
        'protected_historical_files':len(f['protected']),'native_input_tokens_min':min(native_tokens),
        'native_input_tokens_max':max(native_tokens),'new_output_tokens':sum(output_tokens),
        'judge_seconds':judge_seconds,'known_judge_usage':usage,'new_answers':32,'judge_calls':8,
        'automatic_completion_retries':0,'paid_api_calls':0,'reset_credits_used':0,
        'independent_clinical_review':False,'holdout_accessed':False}
    if '--check' in sys.argv:
        existing=s.a.read(s.PUBLIC/'local_generation_improvement_audit.v1.json')
        assert {k:v for k,v in existing.items() if k!='at'}=={k:v for k,v in audit.items() if k!='at'}
        closeout=RUN/'closeout.json'
        if closeout.exists():
            for name,expected in s.a.read(closeout)['hashes'].items():assert s.sha(s.ROOT/name)==expected,name
        print('Existing audit recomputed successfully; no inference or file replacement.',flush=True)
        return
    s.write(s.PUBLIC/'local_generation_improvement_audit.v1.json',audit)
    print(json.dumps(audit,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
