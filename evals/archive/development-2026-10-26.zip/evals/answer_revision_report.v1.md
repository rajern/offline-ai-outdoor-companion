# Retrospective answer rubric: prepared, comparison incomplete

Date: 2026-10-24. **Partial; do not use as a completed rubric or Medium/High
comparison.** Owner authorized the complete workflow and waived the intermediate
rubric review, but execution stopped before the requested experiment completed.
No product answer was generated. Production, source corpus, historical gold,
historical scores and M3 remain unchanged. No commit or push was performed.

## Completed

- All 25 development definitions reviewed. All 74 historical requirements have
  an individually recorded classification, replacement wording, omission rationale,
  trigger, source identities, author and uncertainty. Two belong to the supported
  subset of gap case14 and are excluded from ordinary full-answer coverage.
- The 72 historical supported-case requirements map to **63 required, four
  conditional and five optional** revised criteria. This is a retrospective author
  convention, not a medically established minimum or a safety approval.
- Source assertions, questions, all 50 saved answers and old annotations bound to
  hashes. Private source-bearing evidence/logs remain under ignored knowledge/local.
- Old and revised criteria assessed together for each anonymous answer. Matched
  grouping/order/settings were frozen for Medium then High. Historical agent
  scoring remains a distinct assessor and is not a controlled Medium baseline.
- One three-answer equipment control passed at Medium: equivalent concise wording,
  missing equipment and wrong shared-equipment/negated-practice advice. These are
  author-defined controls, not clinical gold or broad judge calibration.
- **12/50 saved answers assessed at Medium**, with both rubric versions: seven
  historical primary answers, all three water sufficient-context answers, and two
  newer lightning answers. This is not a complete screen8, diagnostic or full25 slice.
- Four behavior tests pass. Exact quote occurrence, input bindings and historical
  preservation are checked offline. Such checks do not prove semantic correctness.

## Technical stop

Two initial transport failures happened before model dispatch: sandbox temp writes
were denied; then Codex CLI could not initialize its in-process app-server client.
The frozen original/transport-v2 logs are retained. Transport-v3 changed execution
permissions/location only; judge instructions, source order, criteria and answers
remained identical. Host execution was approved while each grader retained a
read-only, no-tools ephemeral session.

Transport-v3 made nine successful judge calls: one control plus eight question
groups containing 12 saved answers. The next Medium group, **case-08**, timed out
after the predeclared 420 seconds without a completed answer. Its raw stream has
thread/turn startup and a Code Mode unavailable warning, but no completed judging
response or usage. The warning also occurs in successful calls and is not proven
to cause this timeout. The failed call is retained, not automatically retried.
No experiment Codex process remained after the stop. **High has not started.**

The shared five-hour account window was last observed at 96% used. A separate
question requesting explicit permission to use one of two free resets remains
pending. No reset credit was consumed. A reset alone would not supply the missing
case08 judgment or change the frozen timeout/retry policy.

Known usage is summed from completed JSONL turns. Failed case08 usage is unknown,
not zero; account percentages must not be attributed entirely to this experiment.
See `answer_revision_results.v2.json` and `answer_revision_audit.v1.json`.

## An observed issue, not a High comparison

In lightning case05, Medium marks the HISTORICAL shelter criterion partial despite
acknowledging one fully specified correct alternative, because a second proposed
alternative lacks a qualification. The historical report explicitly allowed one
valid shelter route with problematic additions flagged separately. The frozen
paired prompt also separates positive coverage from wrong additional advice.
This is a concrete rubric-adherence issue to adjudicate, not evidence that High is
better. The raw decisions are retained unchanged. The revised criterion states the
one-alternative rule more explicitly, illustrating why criterion wording matters.

Positive core coverage is never a whole-answer safety pass. For example, a case
can cover all revised core needs while failing active conditional safeguards and
having harmful extra advice. `new_complete` in machine aggregates means only all
fixed required criteria full; conditional/grounding/risk flags remain separate.

## Audit trail and files

- `answer_rubric_revision.v1.md`: authorized protocol, rationale and limits.
- `answer_rubric.v1.json`: machine-readable criteria and full historical mapping.
- `answer_rubric_decisions.v1.md`: human-readable per-requirement decision ledger.
- `answer_revision_judge.v1.md` / schema v1: frozen grader contract.
- `answer_rubric_revision_v1.py`: prepare, run and inference-free summary.
- transport adapters v2/v3: narrowly recorded pre-inference Windows repairs.
- `review_answer_judge_differences_v1.py`: prepares effort-blinded review after BOTH
  complete runs; it has not been run and makes no calls.
- `audit_answer_revision_v1.py`: binding/quote/identity audit without inference.
- private run root: `knowledge/local/diagnostics/answer-rubric-revision-v1-2026-10-24/`.
  Current transport: `transport-v3/`; every successful and failed intent, exact
  input, command, raw stdout/stderr, resources, usage and assessment are retained.

The human-readable ledger is a view generated from the frozen rubric after the
first successful control, not a separate post-result change to the rubric. Its
hash is recorded in the audit. Existing result snapshots v1/v2 are partial and
remain immutable. Generated answers/criteria have not been revised after judging.

## Remaining work

Resolve the technical stop and account capacity before a separately documented
continuation. Reuse all successful exact-identity results; preserve failed attempts.
Finish Medium, then High with unchanged judging inputs/prompt/rubrics, and review
all effort disagreements plus agreed high-consequence findings. Record any timeout
or retry amendment explicitly before its use. Do not automatically rerun case08,
start High, change acceptance policy, or infer a winner from these partial data.
Only then publish a complete paired comparison. No holdout, new sources, retrieval
experiment, local answer generation, final safety policy or M3 is involved.

Research basis and source links are recorded in the protocol. Relevant principles
are situation-specific, justified requirements; distinguishing examples from
obligatory details; and separating completeness, grounding and critical risk.
Neither HealthBench nor another model establishes Outwise's clinical sufficiency.
