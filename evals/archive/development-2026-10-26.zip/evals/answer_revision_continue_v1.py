"""One explicitly authorized timeout continuation; original attempts stay frozen."""
import json
from pathlib import Path
import shutil
import sys

import answer_revision_transport_v2 as transport

r = transport.r
BASE = r.RUN
PARENT = BASE / 'transport-v3'
TARGET = BASE / 'continuation-v1'
TIMEOUT_SECONDS = 1200


def prepare():
    r.RUN = PARENT
    original = r.check_freeze()
    failed = PARENT / 'results/medium/case-08'
    record = r.read(failed / 'record.json')
    events, malformed, usage = r.runtime.events_and_usage(failed / 'stdout.jsonl')
    assert not record['success'] and usage is None and not malformed
    assert not any(e.get('type') == 'turn.completed' or
                   e.get('item', {}).get('type') == 'agent_message' for e in events)
    assert not TARGET.exists(), 'Continuation already prepared'
    seals = {str(p.relative_to(r.ROOT)): r.digest(p)
             for p in PARENT.rglob('*') if p.is_file()}
    for name in ('private-answer-map.json', 'control-expected.json', 'preserved-files.json'):
        dest = TARGET / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(PARENT / name, dest)
    shutil.copytree(PARENT / 'inputs', TARGET / 'inputs')
    reused = []
    answers = 0
    for path in sorted((PARENT / 'results/medium').glob('*/record.json')):
        value = r.read(path)
        if not value['success']:
            continue
        inp = r.read(PARENT / 'inputs' / (path.parent.name + '.json'))
        assert not r.validate(value['returned_decisions'], inp)
        assert value['input_sha256'] == r.canonical(inp)
        assert value['raw_sha256'] == r.digest(path.with_name('stdout.jsonl'))
        shutil.copytree(path.parent, TARGET / 'results/medium' / path.parent.name)
        reused.append(path.parent.name)
        if path.parent.name not in original['controls']:
            answers += len(value['returned_decisions']['answers'])
    assert len(reused) == 9 and answers == 12
    shutil.copyfile(PARENT / 'control-medium.json', TARGET / 'control-medium.json')
    r.write(TARGET / 'recovery-and-reuse.json', {
        'at': r.now(), 'failed_attempt': str(failed.relative_to(r.ROOT)),
        'raw_sha256': r.digest(failed / 'stdout.jsonl'), 'events': len(events),
        'completed_answer_recoverable': False, 'usage': None,
        'reused_groups': reused, 'reused_main_answers': answers,
        'authorized_new_dispatches_maximum': 49, 'automatic_retries': 0})
    hashes = {**original['hashes'], **seals}
    for p in (Path(__file__), r.PUBLIC / 'answer_revision_continuation.v1.md'):
        hashes[str(p.relative_to(r.ROOT))] = r.digest(p)
    for p in TARGET.rglob('*'):
        if p.is_file():
            hashes[str(p.relative_to(r.ROOT))] = r.digest(p)
    frozen = {**original, 'continuation_prepared_at': r.now(),
              'parent_freeze_sha256': r.digest(PARENT / 'freeze.json'),
              'authorization': 'Owner one-shot heartbeat 2026-10-24 21:15 Europe/Oslo; no resets or paid API',
              'settings': {**original['settings'], 'timeout_seconds': TIMEOUT_SECONDS},
              'timeout_scope': 'new calls only, both efforts; nine reused calls retain 420 seconds',
              'new_dispatches_maximum': 49, 'hashes': hashes}
    r.write(TARGET / 'freeze.json', frozen)
    print(json.dumps({'prepared': True, 'reused_calls': len(reused),
                      'reused_answers': answers, 'new_timeout_seconds': TIMEOUT_SECONDS}), flush=True)


def call(group, effort, pre):
    inp = r.read(r.RUN / 'inputs' / f'{group}.json')
    out = r.RUN / 'results' / effort / group
    if (out / 'record.json').exists():
        return r.read(out / 'record.json')
    if (out / 'intent.json').exists():
        return r.finalize_call(out, inp)
    r.write(out / 'intent.json', {'started_at': r.now(), 'model': r.MODEL,
        'reasoning_effort': effort, 'input_sha256': r.canonical(inp),
        'cli_sha256': pre['cli_sha256'], 'timeout_seconds': TIMEOUT_SECONDS,
        'continuation_addendum_sha256': r.digest(r.PUBLIC / 'answer_revision_continuation.v1.md')})
    r.write(out / 'input.json', inp)
    started = r.time.monotonic()
    error = None
    samples = []
    with r.tempfile.TemporaryDirectory(prefix='outwise-answer-judge-') as tmp:
        temp = Path(tmp)
        (temp / 'instructions.md').write_text(
            (r.PUBLIC / 'answer_revision_judge.v1.md').read_text(encoding='utf-8'), encoding='utf-8')
        r.write(temp / 'schema.json', r.schema())
        cmd = r.command(pre, temp, effort)
        r.write(out / 'command.json', {'argv': cmd})
        with (out / 'stdout.jsonl').open('xb') as stdout, (out / 'stderr.txt').open('xb') as stderr:
            proc = r.subprocess.Popen(cmd, cwd=temp, env=r.legacy.codex_environment(),
                stdin=r.subprocess.PIPE, stdout=stdout, stderr=stderr)
            proc.stdin.write(json.dumps(inp, ensure_ascii=False).encode('utf-8'))
            proc.stdin.close()
            while proc.poll() is None:
                try:
                    tree = [r.psutil.Process(proc.pid)] + r.psutil.Process(proc.pid).children(recursive=True)
                    rss = sum(p.memory_info().rss for p in tree if p.is_running())
                    avail = r.psutil.virtual_memory().available
                    samples.append((rss, avail))
                    if rss > 4 * 1024**3 or avail < 256 * 1024**2:
                        error = 'historical memory guard'
                        proc.kill()
                        break
                except r.psutil.Error:
                    pass
                if r.time.monotonic() - started > TIMEOUT_SECONDS:
                    error = 'timeout; no automatic retry'
                    proc.kill()
                    break
                r.time.sleep(.1)
            rc = proc.wait()
            stdout.flush()
            stderr.flush()
            r.os.fsync(stdout.fileno())
            r.os.fsync(stderr.fileno())
    r.write(out / 'resources.json', {'elapsed_seconds': r.time.monotonic() - started,
        'peak_rss': max((rss for rss, avail in samples), default=None),
        'minimum_available_ram': min((avail for rss, avail in samples), default=None),
        'sample_interval': .1, 'timeout_seconds': TIMEOUT_SECONDS})
    return r.finalize_call(out, inp, rc, error)


def run(effort):
    frozen = r.check_freeze()
    pre = frozen['preflight']
    if effort == 'high' and not (r.RUN / 'medium-complete.json').exists():
        raise RuntimeError('Medium must complete before High')
    assert r.digest(pre['cli']) == pre['cli_sha256'], 'CLI binary changed'
    with r.runtime.JudgeLock():
        for group in frozen['controls'] + frozen['groups']:
            value = call(group, effort, pre)
            if not value['success']:
                print(json.dumps({'stopped': True, 'effort': effort, 'group': group,
                                  'errors': value['errors']}, ensure_ascii=False), flush=True)
                return False
            if group in frozen['controls']:
                expected = r.read(r.RUN / 'control-expected.json')
                diff = []
                for row in value['returned_decisions']['answers']:
                    labels = [x['decision'] for x in sorted(row['revised'], key=lambda x: x['id'])]
                    if labels != expected[row['answer_id']]:
                        diff.append({'id': row['answer_id'], 'expected': expected[row['answer_id']], 'actual': labels})
                path = r.RUN / f'control-{effort}.json'
                result = {'differences': diff, 'agent_authored_control': True}
                if path.exists():
                    assert r.read(path) == result
                else:
                    r.write(path, result)
                if diff:
                    print(json.dumps({'control_failed': diff, 'effort': effort}), flush=True)
                    return False
            print(json.dumps({'completed': group, 'effort': effort,
                              'answers': len(value['returned_decisions']['answers']),
                              'usage': value['usage']}, ensure_ascii=False), flush=True)
        marker = r.RUN / f'{effort}-complete.json'
        if not marker.exists():
            r.write(marker, {'at': r.now(), 'groups': len(frozen['groups']), 'controls': len(frozen['controls'])})
    return True


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
    else:
        r.RUN = TARGET
        transport.TEMP_ROOT = TARGET / 'temp'
        r.tempfile.TemporaryDirectory = transport.workspace_temporary_directory
        if action == 'summarize':
            r.summarize()
        elif action == 'both':
            if run('medium'):
                run('high')
        elif action in ('medium', 'high'):
            run(action)
        else:
            raise ValueError(action)
