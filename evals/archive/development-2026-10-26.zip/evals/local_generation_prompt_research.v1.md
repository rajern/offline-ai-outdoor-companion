# Prompt, kildegjengivelse og generering: fordypet forskningsrunde

25. oktober 2026. Brukeren ba om å undersøke prompttype/struktur, eksempler,
svarlengde, sampling/thinking og om mer direkte kildegjengivelse kan gi bedre
svar. «Kjør alle» er forstått i sammenheng med den avtalte forskningsrunden før
implementering og eksperimenter. Ingen nye lokale svar, dommerkall, retrieval,
nedlastinger eller produksjonsendringer er gjort. Den forrige forskningsrapporten
og alle tidligere forsøk er bevart.

**Resultat:** Det er grunnlag for en ny, avgrenset prompttest. Den beste praktiske
hypotesen er en tydelig kildebevarende oppgave med fullstendighet før forkorting,
korrekt native format og eksplisitte modelltilpassede samplere. Forskningen
støtter ikke en universell «kort prompt + lav temperatur»-oppskrift. Mer direkte
gjengivelse har støtte for bedre sporbarhet og enkelte kvalitetsmål; en ren
promptendring på våre kvantiserte modeller er fortsatt uprøvd.

## 1. Hva denne runden avklarer utover forrige rapport

- En studie med akkurat Qwen3.5-2B og Gemma 4 E2B finnes. Den er mer relevant enn
  generelle råd om «små modeller», men oppgaven og inferensoppsettet er andre.
- Det finnes publisert prompting-basert forskning på å velge kildebevis før
  svargenerering; det er ikke bare et resultat fra finjustering.
- Sitatformat og ordrett uttrekk må skilles fra riktig bruk av sitatet.
- Det finnes ikke et forskningsbestemt riktig tokentall for Outwise.
- Eksempler, kortere prompt og thinking kan både hjelpe og koste kvalitet.
  Derfor legges ikke alle grep inn i ett stort oppsett.

Grunnlaget fra før er uendret: siste screening omfatter åtte spørsmål per nyere
modell, mens full25-scoren er fra det eldre Qwen-oppsettet. Rubrikk v1 og Sol
Medium er låst. Begge nyere modeller dekker 7/8 kjernekrav i tre utvalgte
tilstrekkelig-kontekstkontroller; dette er et diagnostisk signal, ikke en full
kvalitetsscore. Se [forrige forskningsrapport](local_generation_improvement_research.v1.md).

## 2. Hva slags prompt passer små modeller?

### Ingen universell beste struktur

En preprint med 24 promptvarianter på Qwen2.5-3B og Gemma3-4B finner ulike
vinnere for kvalitet og tidsbruk. Den enkle instruction-tuned-varianten er rask,
men på Gemma har den lavere rapportert kvalitet enn standardprompten. På Qwen er
forskjellen liten i samme sammenligning. Scoren er en vektet LLM-vurdering, ikke
andel fullstendige prosedyrer. De 18 720 evalueringene bygger på 390 spørsmål
gjentatt over modell/prompt. Dette er støtte for å teste en promptpakke, ikke
bevis for at kortest er best. [Metode og tabeller 2/4, samt fulltabeller](https://arxiv.org/pdf/2602.13890).

En separat formatstudie finner følsomhet for vanlig tekst, Markdown, JSON og
YAML. Den bruker eldre GPT-modeller. Den viser ingen universell formatvinner og
validerer ikke XML, Markdown eller JSON som optimalt for våre små modeller.
[Does Prompt Formatting Have Any Impact on LLM Performance?](https://arxiv.org/abs/2411.10541).

**Min vurdering for Outwise:** Vi bør prioritere tydelig oppgave, stabile
avgrensninger og en enkel svarform. Ordgrensen på prompten er ikke målet.
Nødvendige regler om kilder, vilkår og kunnskapshull skal bevares.

### Ny og direkte relevant studie: modellfamiliene vi bruker

Instruction Retrieval v3 tester Qwen3.5-2B og Gemma 4 E2B. På MedQA gir tabellene:

| Modell | Uten ekstra kontekst | Hentede lærebokpassasjer | Hentede instruksjoner |
|---|---:|---:|---:|
| Qwen3.5-2B | 51,8 % | 58,5 % | 67,6 % |
| Gemma 4 E2B | 57,2 % | 62,0 % | 69,4 % |

Instruksjonene inneholder lærerlaget fagkunnskap og fremgangsmåter. Dette endrer
informasjonen, ikke bare formuleringen av systemprompten. Vanlige fem-eksempel-
prompter gir ikke tilsvarende gevinst. Studien bruker flervalgsoppgaver, FP16,
GPU og store outputbudsjetter; ikke norsk Q4-prosedyregenerering. Tallene er fra
avrundede tabeller, ikke et forventningsnivå for Outwise. Nyeste v3 er brukt;
eldre treff med tittelen «Big Reasoning…» beskriver en annen versjon.
[Fulltekst, metode og tabell C.1](https://arxiv.org/html/2510.13935v3).

**Min slutning:** Dette støtter at modeller i vår størrelse kan ha nytte av
eksplisitt tilgjengelig kunnskap og klare handlingsinstrukser. Det gir ingen
fullmakt til å generere nye førstehjelpsprosedyrer som kildegrunnlag. Hos oss skal
eventuell omstrukturering bevare informasjon fra de allerede godkjente kildene.

### Bør vi legge inn eksempler?

InstructRAG-ICL bruker eksempler som viser hvordan et svar utledes fra støyete
kilder, uten å trene svarmodellen. På Llama 3 8B/70B forbedrer dette flere mål
sammenlignet med enklere RAG. Antall og type eksempler betyr noe; vanlige
svar-eksempler har ikke samme mønster som eksempler med begrunnet kildeutvalg.
Dette er andre størrelser og krever utarbeidede demonstrasjoner.
[InstructRAG, særlig 2.3 og 3.2–3.4](https://arxiv.org/html/2406.13629).

Googles generelle Gemini-veiledning anbefaler eksempler og konsistent struktur,
men advarer også mot for mange eksempler. Det er Gemini-råd, ikke en direkte
effektmåling på Gemma E2B. [Prompt design strategies](https://ai.google.dev/gemini-api/docs/prompting-strategies).

**Anbefaling:** Ingen demonstrasjoner i første kandidat. Ett kort syntetisk,
ikke-medisinsk eksempel kan senere teste bevaring av et vilkår og riktig
erkjennelse av kildehull. Det må ikke inneholde våre utviklingssvar, gullkrav
eller holdout. Eksempler er ekstra input og kan også trekke modellen mot feil
scenario; de er ikke gratis forbedring.

## 3. Kan mer direkte kildegjengivelse gi bedre svar?

### Ja, det finnes belegg — men kvalitet betyr flere ting

Attribute First, then Generate har en prompting-basert variant med Gemini Pro:
kildeutvalg, planlegging og setningsvis generering. På langform-QA forbedres
flere mål for kildestøtte og svarkvalitet, og kildebelegg blir enklere å
kontrollere. Resultatet er ikke entydig på alle oppgaver: på oppsummering er
enkelte mål for kildeunderstøttelse lavere enn baselinen. Metoden bruker flere
kall og eksempler; den dokumenterer ikke én-prompt-effekt på 2B.
[ACL 2024, fulltekst og resultattabeller](https://arxiv.org/html/2403.17104v3).

SEMQA undersøker svar som blander ordrette kildespenn med korte forbindelser.
Brukerstudien finner slike svar enklere å kontrollere og mer komplette i den
undersøkte sammenligningen med PaLM2 Bison og fire eksempler. Studien bruker
engelske spørsmål og Wikipedia-kilder. Både prompting og trening inngår i
arbeidet; selve oppgaven viser seg krevende. Dette støtter en mulig svarform,
ikke at kopiering alltid løser utelatelser eller situasjonstilpasning på 2B.
[SEMQA, NAACL 2024](https://aclanthology.org/2024.naacl-long.74/).

CHyD undersøker en teknisk begrensning som tvinger sitatspenn til å finnes ordrett
i konteksten. Det oppnår langt mer pålitelig bokstavrett uttrekk enn et fritt
sitatformat i de undersøkte oppsettene, men svarmål forbedres ikke overalt.
Forskjellen er viktig: riktig kopiert tekst kan fortsatt være feil avsnitt eller
feil råd for situasjonen. Metoden krever endring i dekoderen og har blant annet
tokeniseringsforbehold. Den er ikke en promptoppskrift vi kan kopiere direkte.
[CHyD, metode, tabell 4 og begrensninger](https://arxiv.org/html/2609.10046v1).

**Min vurdering:** Vi har nå bedre grunnlag for å teste en mer kildebevarende
svaroppgave. Jeg ville likevel moderere påstanden om at dette nødvendigvis gir
størst bedring i fullstendighet. Belegget er sterkere for sporbarhet og mindre
fri omskriving enn for en bestemt dekningsgevinst hos oss.

To ulike løsninger må holdes fra hverandre:

1. **Nær gjengivelse i norsk svar.** Modellen velger og formulerer fortsatt,
   særlig når engelske kilder oversettes. Dette er billig å teste, men gir
   ingen teknisk garanti for at ordlyd eller mening er bevart.
2. **Ordrett kildevisning.** Programmet kan hente faktisk tekst fra en gyldig
   passasje-ID og vise den direkte. Det kan garantere hva som er kopiert, men
   ikke at passasjen er riktig valgt eller at den utgjør en komplett prosedyre.
   Dette er et mulig senere produktvalg; ikke implementert her.

Første forsøkskandidat bruker løsning 1, med samme fulle kildepakke og samme
enkle svarformat som før. Vi legger ikke på en egen sitatblokk som bruker av
outputbudsjettet eller gjør en engelsk kopi til en tilsynelatende norsk fasit.
Kildeetterlevelse vurderes mot teksten, ikke ut fra om svaret har en referanse.

## 4. Hvordan bør inputen struktureres?

Gemma 4 har egne system-/brukerroller og andre kontrolltokens enn eldre Gemma.
Eldre råd om at Gemma ikke støtter systemrollen gjelder derfor ikke vårt
Gemma 4-oppsett. Det er viktig å bruke den faktiske modellens template.
[Offisiell Gemma 4-formatering](https://ai.google.dev/gemma/docs/core/prompt-formatting-gemma4).

Dette er allerede kontrollert i våre forsøk. Neste kandidat beholder:

1. **Systemrolle:** Oppgave, hva som skal bevares, hva som gjøres ved kildehull,
   og enkel svarform.
2. **Brukerrolle:** `[KILDEUTDRAG]` med uendrede blokker, deretter
   `[BRUKERSPØRSMÅL]` med uendret spørsmål.
3. **Native assistant-start:** Runtime lager riktig prefiks, én BOS og
   thinking av. Vi finner ikke opp egne modellkontrolltokens.

Prompt Repetition rapporterer gevinst ved å gjenta input på flere API-modeller,
men undersøker ikke disse lokale 2B-oppsettene. Dobling av vår kildepakke kan
overskride 4096-konteksten og øker CPU-arbeidet ved innlesing. Derfor anbefaler
jeg ikke repetisjon eller ny plassering som et ekstra grep i første kandidat.
[Prompt Repetition](https://arxiv.org/html/2512.14982v1).

Dette er et begrunnet formatvalg som holder en allerede fungerende del fast.
Det er ikke et forskningsbevis på at kilder-før-spørsmål er universelt best.

## 5. Svarlengde: hva bør vi gjøre med 512 tokens?

llama.cpp beskriver `n_predict` som maksimum antall nye tokens. `eos` betyr at
modellen avsluttet, mens `limit` betyr at tokenbegrensningen stoppet den.
Å øke maksimum tvinger ikke et EOS-avsluttet svar til å fortsette. Faktiske
effektive innstillinger kan avvike fra forespørselen og må leses fra loggen.
[Offisiell serverdokumentasjon](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md).

RAG-replikasjonen Powerless Noise viser at stramme instruksjoner og avkortede
svar kan påvirke målte resultater betydelig. Den øker blant annet en opprinnelig
15-token-grense til 100 i sine oppgaver; det er ingen anbefaling om 100 eller
noe annet bestemt antall for Outwise. [Metode og analyse](https://arxiv.org/html/2607.03615v2).

Qwen-kortet anbefaler generelt romslig output, ofte titusener av tokens i
benchmarking. Det gjelder ikke automatisk våre korte, lokale svar med
4096 runtime-kontekst. [Qwen3.5-2B, Best Practices](https://huggingface.co/Qwen/Qwen3.5-2B#best-practices).

**Konkrete observasjoner hos oss:** Qwen har to limit-stopp av elleve lagrede
svar, hvor pustesvaret er en tydelig løkke. Gemma har elleve EOS-stopp, med
24–218 outputtokens på de åtte primærsvarene. Metadataene er verifisert i
[forrige evidensfil](local_generation_improvement_evidence.v1.json).

**Anbefaling:** Behold 512 i den første isolerte sammenligningen. Det gjør
svarbudsjettet konstant; det hevder ikke at 512 er optimalt. Logg og gjennomgå
alle limit-stopp. Hvis et nytt svar gjør fremdrift og blir kuttet, er en
forhåndsdefinert 1024-kontroll relevant. Hvis det går i løkke, er ekstra plass
alene et dårlig svar på den feilen. Hvis det avsluttes tidlig, må oppgave og
generering undersøkes.

En lengdekontroll må være et separat forsøk med samme prompt, sampler og seed;
den opprinnelige responsen beholdes. Ingen automatisk skjult fortsettelse.
Teknisk krever 1024-reservasjon innen 4096 at hele inputen er høyst 3072 tokens,
inkludert template. Den gamle øvre inputgrensen 3200 kan ikke brukes ukritisk.
512→1024 betyr ekstra kapasitet, ikke et krav om et langt brukersvar.

## 6. Sampling og thinking

Det er fortsatt én konkret uprøvd parametergruppe. Nåværende foreslåtte profiler
for tekst uten thinking er:

| Parameter | Gammel testprofil, begge | Qwen-kandidat | Gemma-kandidat |
|---|---:|---:|---:|
| Temperatur | 0,2 | 1,0 | 1,0 |
| top-p | 0,8 | 1,0 | 0,95 |
| top-k | 20 | 20 | 64 |
| min-p | 0,05 | 0 | 0 |
| presence penalty | 0 | 2,0 | 0 |
| repeat penalty | 1,0 | 1,0 | 1,0 |

Qwen-verdiene er fra modellkortets tekstprofil; høy presence penalty kan også
gi språkblanding eller svakere ytelse. Gemmas temperatur/top-p/top-k er fra
Google. Dens øvrige verdier er eksplisitte forsøksvalg: ingen ekstra min-p-
filtrering eller ny repetisjonsstraff. Dette er ikke dokumentert optimale
Outwise-profiler. [Qwen](https://huggingface.co/Qwen/Qwen3.5-2B#best-practices),
[Gemma 4 E2B-modellkort](https://huggingface.co/google/gemma-4-E2B-it).

Samplerkjede, penalty-vindu, seed og effektive verdier må bindes til forsøket.
I de lagrede råsvarene er `repeat_last_n=64`; det må ikke bli en skjult ny
variabel. Lik parameternavn er ikke bevis på lik sampling mellom rammeverk.
Ingen modell- eller runtime-oppgradering inngår i forslaget.

Gemma har en offisiell thinking-mekanisme som må aktiveres i template, ikke
bare med ordene «tenk steg for steg». Resonering og slutttekst må håndteres
hver for seg. Dokumentasjonseksempler med 1024 tokens er eksempler, ikke
anbefalt budsjett for vår oppgave.
[Offisiell thinking-dokumentasjon](https://ai.google.dev/gemma/docs/capabilities/thinking).

**Anbefaling:** Thinking av i første runde. Det er en egen testvariabel med
ekstra tids- og budsjettkostnad. Vi har ingen direkte dokumentasjon på at det
løser kildeutelatelsene våre. Sol Medium for dommeren beholdes uavhengig av dette.

## 7. Konkret forslag og liten sammenligning

[Promptutkastet](local_generation_prompt_proposal.v1.md) er en konkret kandidat,
ikke tatt i bruk. Det beholder nødvendige kildekrav og endrer prioriteten fra
kort svar til å bevare instruksledd før forkorting. Det lover ikke å være
kortere eller bedre. Det legger ikke til eksempler, JSON, ekstra sitater,
referansekrav, egenretting eller nye modellkall.

Den tidligere foreslåtte lille sammenligningen er fortsatt fornuftig:

| Variant | Systemprompt | Sampling | Outputtak | Hva den sammenlignes med |
|---|---|---|---:|---|
| Lagret baseline | Siste testede v1 | Gammel | 512 | Gjenbrukte åtte svar per modell |
| A | Samme v1 | Modelltilpasset | 512 | Effekten av samplingprofilen samlet |
| B | Foreslått promptpakke | Gammel | 512 | Effekten av promptpakken samlet |

Samme spørsmål, kildeblokker/rekkefølge, modellfiler, runtime, seed og
ressursgrenser brukes. Åtte spørsmål × to modeller × to nye varianter gir
høyst 32 nye produktsvar ved én gjennomføring per input. Dette er ingen
robusthetsmåling. Eventuelle lengdekontroller, kombinasjon A+B, eksempler,
thinking eller full25 er ikke automatisk inkludert; de må ha egne avgrensede
inputdefinisjoner og budsjetter før kjøring.

Opplegget måler heller ikke samspillet mellom ny prompt og ny sampling. En
negativ B viser ikke at prompten ville feile med A-profilen. En lovende
kombinasjon må testes som en egen kandidat før den kan velges.

Runden må vurdere bevaring av tilgjengelige krav, delvis dekning, tapte vilkår,
udokumenterte tillegg, kritiske feil og avståelse. Mer kopiert tekst eller flere
ord er ingen suksessdefinisjon. Samme rubrikk og Medium-dommer brukes, og ny
tolkning eller justering av poengreglene etter resultatene unngås.

## 8. Enkel oppsummering av forskningsresultatet

- **Prompt:** Tydelig oppgave og kildeavgrensning er et rimelig utgangspunkt.
  Kortest prompt er ikke et dokumentert kvalitetsmål.
- **Direkte gjengivelse:** Verdt å teste; bedre støtte for sporbarhet enn for en
  bestemt dekningsgevinst på våre modeller. Ordrett betyr ikke situasjonsriktig.
- **Eksempler:** Kan hjelpe, men er ikke standardtiltak nå. Mange er ikke bedre
  enn få, og nytten må testes på vår oppgave.
- **Svarlengde:** Maksimum, tidlig EOS og løkker er forskjellige problemer.
  512 beholdes først for sammenlignbarhet; legitim avkorting kan undersøkes
  separat med mer plass.
- **Sampling:** Modelltilpassede profiler er det enkleste konkrete tiltaket å
  prøve mot de observerte genereringsfeilene.
- **Thinking:** En senere, separat hypotese — ikke en forutsetning for denne
  runden.

Det jeg mest vil prøve er den nye promptpakken og profilene, hver for seg.
Forskningen gir bedre begrunnelse for valgene, men ingen målt Outwise-forbedring
før de faktiske forsøkene er kjørt.

## Metode og begrensninger

Målrettet primærkildesøk og fulltekstkontroll av sentrale metoder, tabeller og
inferensinnstillinger. Dette er ikke en systematisk metaanalyse. Offisielle
modellkort er produsentråd; publiserte studier og preprints er skilt i
[kilderegisteret](local_generation_prompt_research_sources.v1.json). Sekundære
søketreff er brukt til å finne originalene, ikke som evidens for anbefalingene.
Ingen ekstern kilde gir en klinisk eller generell kvalitetsgodkjenning av Outwise.

Historisk rubrikk, scorer, privat kildetekst, forsøk og statusdokumenter er
uendret. Ingen holdout er åpnet. Ingen betalt API, gratis kvotetilbakestilling,
modellserver eller ny inferens er brukt. Forslaget er ikke produksjonsintegrert
og endrer ikke M3 eller låste produktvalg.
