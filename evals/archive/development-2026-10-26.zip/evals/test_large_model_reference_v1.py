"""Checks prevent evaluator leakage, changed source input and tool-assisted output."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import run_large_model_reference_v1 as r


class ReferenceChecks(unittest.TestCase):
    def test_generator_is_high_without_judge_schema(self):
        pre=r.a.read(r.PARENT/'definitions.json')['preflight']
        command=r.generation_command(pre,r.RUN/'test-temp')
        self.assertIn('model_reasoning_effort="high"',command)
        self.assertNotIn('--output-schema',command)
        self.assertIn('web_search="disabled"',command)
        self.assertIn('read-only',command)

    def test_inputs_equal_local_baseline_not_prompt_variant(self):
        for cid in r.CASES:
            one=r.a.read(r.PARENT/'definitions'/f'qwen-2b-A-{cid}.json')
            two=r.a.read(r.PARENT/'definitions'/f'gemma-e2b-A-{cid}.json')
            self.assertEqual(one['messages'],two['messages'])
            self.assertEqual([m['role'] for m in one['messages']],['system','user'])
            self.assertIn(one['question'],one['messages'][1]['content'])

    def test_parser_rejects_tools_and_incomplete_turn(self):
        events=[{'type':'item.completed','item':{'type':'agent_message','text':'answer'}},
            {'type':'item.completed','item':{'type':'command_execution'}}, {'type':'turn.completed','usage':{}}]
        with patch.object(r.a.runtime,'events_and_usage',return_value=(events,0,{})),patch.object(r,'sha',return_value='x'):
            self.assertIn('forbidden tool event',r.parse_generation(Path('unused'),0)['errors'])
        with patch.object(r.a.runtime,'events_and_usage',return_value=(events[:1],0,{})),patch.object(r,'sha',return_value='x'):
            self.assertIn('incomplete turn',r.parse_generation(Path('unused'),0)['errors'])

    def test_prior_dispatch_is_never_automatically_repeated(self):
        with tempfile.TemporaryDirectory(dir=r.ROOT/'knowledge/local',prefix='reference-test-') as tmp:
            folder=Path(tmp);self.assertTrue(folder.resolve().is_relative_to((r.ROOT/'knowledge/local').resolve()))
            (folder/'inputs').mkdir();(folder/'responses/case-19').mkdir(parents=True)
            r.write(folder/'inputs/case-19.json',{})
            r.write(folder/'responses/case-19/intent.json',{})
            with patch.object(r,'RUN',folder):
                with self.assertRaisesRegex(AssertionError,'Prior dispatch'):r.generate_one('case-19',{})


if __name__=='__main__':unittest.main()
