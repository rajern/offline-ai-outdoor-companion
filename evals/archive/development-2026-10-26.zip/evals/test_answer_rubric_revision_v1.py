"""Behavior checks for quote isolation and stable assessment denominators."""
import copy
import unittest

import answer_rubric_revision_v1 as r


class RevisionTests(unittest.TestCase):
    def fixture(self):
        inp={'answers':[{'answer_id':'a','text':'Ring 113 nå.'},{'answer_id':'b','text':'Vent til i morgen.'}],
             'historical_criteria':[{'id':'old'}],
             'revised_criteria':[{'id':'new','classification':'required'}],
             'blocks':[{'block':1,'text':'Ring 113 straks.'}]}
        def row(aid,quote):
            item={'id':'old','decision':'full','answer_quote':quote,'reason':'','support':'not_assessed','source_block':0,'source_quote':''}
            new={**item,'id':'new','support':'full','source_block':1,'source_quote':'Ring 113 straks.'}
            return {'answer_id':aid,'historical':[item],'revised':[new],'findings':[],'gap_behavior':'not_gap'}
        return inp,{'answers':[row('a','Ring 113 nå.'),row('b','Vent til i morgen.')]}

    def test_quotes_cannot_be_borrowed_from_another_answer(self):
        inp,out=self.fixture();self.assertEqual(r.validate(out,inp),[])
        out['answers'][1]['revised'][0]['answer_quote']='Ring 113 nå.'
        self.assertIn('answer quote mismatch',r.validate(out,inp))

    def test_source_quote_and_required_applicability_are_enforced(self):
        inp,out=self.fixture();out['answers'][0]['revised'][0]['source_quote']='Invented source'
        self.assertIn('source quote mismatch',r.validate(out,inp))
        out['answers'][0]['revised'][0]['decision']='not_applicable'
        self.assertIn('required not applicable',r.validate(out,inp))

    def test_missing_or_duplicate_decisions_cannot_shrink_denominator(self):
        inp,out=self.fixture();out['answers'][0]['revised']=[]
        self.assertIn('revised criterion IDs mismatch',r.validate(out,inp))
        inp,out=self.fixture();out['answers'].append(copy.deepcopy(out['answers'][0]))
        self.assertIn('answer ID mismatch',r.validate(out,inp))

    def test_historical_requirements_have_traceable_revision(self):
        rb=r.rubric();self.assertEqual(len(rb['cases']),25)
        for case in rb['cases']:
            self.assertTrue(case['source_evidence'] or case['expected_result']=='insufficient_coverage')
            for criterion in case['criteria']:
                self.assertTrue(criterion['historical_text'])
                self.assertTrue(criterion['omission_rationale'])
                self.assertTrue(criterion['criterion'])
                self.assertIn(criterion['classification'],{'required','conditional','optional'})


if __name__=='__main__':unittest.main()
