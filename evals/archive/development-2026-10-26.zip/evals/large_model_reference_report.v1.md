# GPT-6.1 Sol-referanse — delvis kjøring, 25. oktober 2026

**Kjøringen stoppet på HTTP429 ved femte spørsmål. Fire av åtte svar er ferdige.
Ingen nye Medium-vurderinger er kjørt, og ingen samlet score foreligger.**

## Avtalt sammenligning

Åtte uavhengige GPT-6.1 Sol High-svar med samme opprinnelige systemprompt,
brukerspørsmål og kildeblokker/rekkefølge som den lokale screeningen. Deretter
uendret rubrikk og Sol Medium-dommer, og kildegjennomgang. Tidligere lokale svar
og vurderinger gjenbrukes. Ingen fasit, rubrikk eller vurderingsresultater gis
til svarmodellen. Nett-/filverktøy, historikk, prosjektinstrukser og andre verktøy
er deaktivert i den isolerte kjøringen.

Codex bruker en annen modellinnpakning og High-resonnering. Seed og den lokale
512-token-grensen ble ikke forsøkt satt via udokumenterte alternativer.
Slutttekst blir ikke klippet. Dette er derfor en praktisk sterk referanse,
ikke en ren test av modellstørrelse. Faktisk servermodell/-revisjon og hele
den skjulte modellinnpakningen er ikke uavhengig eksponert.

## Presist stoppunkt

| Spørsmål | Status | Ord i ferdig svar |
|---|---|---:|
| 19: skredutstyr | Ferdig og forseglet | 71 |
| 05: torden på fjellrygg | Ferdig og forseglet | 96 |
| 08: bevisstløshet/pust | Ferdig og forseglet | 170 |
| 17: reaksjon etter vepsestikk | Ferdig og forseglet | 33 |
| 21: filter/desinfisering | HTTP429, ingen ferdig svartekst | — |
| 23: torden innendørs | Ikke startet | — |
| 15: bålregler/kunnskapshull | Ikke startet | — |
| 25: bygging av ly/kunnskapshull | Ikke startet | — |

På21 logget CLI-en `429 Too Many Requests` og varslet et internt nytt forsøk
etter omtrent202 sekunder. Den identifiserte, egne CLI-prosessen ble stoppet
mens den ventet, for å unngå automatisk gjentakelse. Prosessen ble identifisert
ved eksakt programfil, High-innstilling og arbeidsmappe under denne kjøringens
tempmappe. Ingen annen prosess ble avsluttet. Foreldrekjøringen lagret feil,
rålogger og stoppfil og avsluttet uten å starte neste spørsmål.

Det finnes ingen fullført21-tekst å gjenbruke. Ingen ytterligere dispatch er
observert i råloggen. Intern retry ble varslet, men et nytt inferensforsøk ble
ikke observert før prosessen ble stoppet. Ressursgrensene ble ikke brutt.

Kontoverktøyet viste etterpå at ordinær bruk fortsatt var tillatt, med12%
brukt av femtimerskvoten og18% av ukekvoten. **Det er derfor ikke dokumentert
at abonnementskvoten er brukt opp.** Årsak og varighet for HTTP429 er ukjent;
vi kan ikke utlede den av disse tallene. Ingen kvotetilbakestilling, betalt API
eller modellbytte ble forsøkt.

## Hva vi foreløpig kan si

De fire tekstene er mer presise enn flere av de lokale svarene: de svarer
tydeligere på den aktuelle situasjonen, bevarer flere viktige detaljer og
blander i liten grad inn de uvedkommende treffene. Dette er en foreløpig
tekstobservasjon, ikke en rubrikkscore eller sikkerhetsgodkjenning.

Pustesvaret er fortsatt begrenset av kildepakken; god kildefølging betyr ikke
automatisk fullstendig veiledning. De to kunnskapshullene er ikke kjørt ennå.
Dermed kan vi verken vurdere samlet avståelse eller konkludere om hele screen8.
Samme modell som generator og dommer kan dessuten favorisere egen svarstil;
senere kildegjennomgang er nødvendig og er ikke uavhengig klinisk fasit.

## Kontroll og forbruk

Fire automatiserte kontroller besto før frysingen: likt lokalt input,
High/ingen dommerskjema til generator, avvisning av verktøy/ufullførte strømmer
og ingen automatisk gjentakelse av en lagret dispatch. Alle åtte innganger,
kode, protokoll og tidligere resultater ble bundet før første kall.

De fire komplette råstrømmene er lest på nytt og kontrollert mot eksakt
stdin/systemprompt, svartekst, modellforespørsel og ressursgrenser.1270
beskyttede tidligere filer er kontrollert uendret, med de to tillatte
fremdriftsdokumentene bevart som kopier før oppdatering.

Fem CLI-forsøk ble startet: fire vellykkede og ett avbrutt etter429. De fire
vellykkede rapporterte27437 inputtokens og1405 outputtokens, totalt28842.
734 rapporterte reasoning-outputtokens inngår i outputtotalen og legges ikke
oppå en gang til. Det avbrutte forsøket rapporterte ikke tokenbruk; total bruk
for hele forsøket er derfor ikke kjent. Manglende bruk er ikke satt til null.
Klient-RAM sier ingenting om minne eller energibruk hos skymodellen.

## Videre fortsettelse

Fire forseglete svar skal gjenbrukes byteidentisk. Ikke regenerer dem.
En senere fortsettelse må dokumenteres separat, beholde avbrutt21-forsøk og
rålogger, og avklare et nytt forsøk mot den opprinnelige grensen på åtte
genereringskall. Bare21,23,15 og25 mangler svar. Alle åtte svar må være lagret
før de planlagte Medium-vurderingene starter. Prompt, kilder og rubrikk skal
fortsatt være uendret.

Kjøringen er ikke fullført. Ingen produksjonsendring, ny retrieval, holdout,
sikkerhetspolicy eller M3 er gjennomført. M2-06-kvalitet er fortsatt åpen.

- [Forhåndslåst protokoll](large_model_reference_protocol.v1.md)
- [Kontrollert delstatus og kjent bruk](large_model_reference_partial_results.v1.json)
- Private input, svar, rålogger og stopp:
  `knowledge/local/diagnostics/large-model-reference-v1-2026-10-25/`

CLI-oppsettet bygger på [OpenAIs offisielle dokumentasjon](https://learn.chatgpt.com/docs/non-interactive-mode)
og det tidligere verifiserte, verktøyfrie evalueringsoppsettet i repoet.
