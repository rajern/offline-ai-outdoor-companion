"""Eight isolated High answers, then unchanged Medium judges; no API key path."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import subprocess
import sys
import tempfile
import time

import run_generation_improvement_v1 as g

a=g.a
ROOT,PUBLIC=g.ROOT,g.PUBLIC
PARENT=ROOT/'knowledge/local/diagnostics/local-generation-improvement-v1-2026-10-25/revision-03'
RUN=ROOT/'knowledge/local/diagnostics/large-model-reference-v1-2026-10-25'
PROTOCOL=PUBLIC/'large_model_reference_protocol.v1.md'
SELF=Path(__file__).resolve()
CASES=g.CASES
ALLOWED=g.ALLOWED
sha=g.sha
write=a.write


def generation_command(pre,temp):
    command=a.command(pre,temp,'high')
    pos=command.index('--output-schema')
    del command[pos:pos+2]
    return command


def parse_generation(path,returncode,error=None):
    events,malformed,usage=a.runtime.events_and_usage(path)
    messages=[e['item']['text'] for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message']
    errors=[]
    if malformed:errors.append('malformed JSONL')
    if returncode!=0:errors.append('nonzero CLI exit')
    if error:errors.append(error)
    if not any(e.get('type')=='turn.completed' for e in events):errors.append('incomplete turn')
    if any(e.get('item',{}).get('type') not in {None,'agent_message','reasoning','error'} for e in events):errors.append('forbidden tool event')
    if len(messages)!=1 or not messages[-1].strip():errors.append('expected one nonempty final answer')
    return {'success':not errors,'errors':errors,'answer':messages[-1] if messages else None,
        'usage':usage,'raw_sha256':sha(path),'returncode':returncode}


def preservation():
    frozen=a.read(RUN/'freeze.json')
    for name,expected in frozen['protected'].items():
        path=RUN/'before'/name if name in ALLOWED else ROOT/name
        assert sha(path)==expected,name
    for name,expected in frozen['hashes'].items():assert sha(ROOT/name)==expected,name
    assert sha(frozen['preflight']['cli'])==frozen['preflight']['cli_sha256']
    return frozen


def prepare():
    assert not RUN.exists(),'No overwrite or unreviewed retry'
    previous=a.read(PARENT/'closeout.json')
    protected={name.replace('\\','/'):value for name,value in previous['hashes'].items()}
    protected[str((PARENT/'closeout.json').relative_to(ROOT)).replace('\\','/')]=sha(PARENT/'closeout.json')
    for name,value in protected.items():assert sha(ROOT/name)==value,name
    old=a.read(PARENT/'definitions.json')
    for name,value in old['protected'].items():
        normalized=name.replace('\\','/')
        path=PARENT/'before'/normalized if normalized in ALLOWED else ROOT/name
        assert sha(path)==value,name
        if normalized not in ALLOWED:protected.setdefault(normalized,value)
    pre=a.runtime.preflight();pre['cli_sha256']=sha(pre['cli'])
    assert pre['cli_sha256']==old['preflight']['cli_sha256']
    catalog=a.read(Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))/'models_cache.json')
    entry=next(x for x in catalog['models'] if x['slug']==a.MODEL)
    assert {'medium','high'} <= {x['effort'] for x in entry['supported_reasoning_levels']}
    RUN.mkdir(parents=True)
    for name in ALLOWED:
        dest=RUN/'before'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,dest)
    rng=random.Random(202610251);identifiers=rng.sample(range(100,999),8)
    for cid,number in zip(CASES,identifiers):
        item=a.read(PARENT/'definitions'/f'qwen-2b-A-{cid}.json')
        messages=item['messages']
        assert len(messages)==2 and [x['role'] for x in messages]==['system','user']
        assert messages[0]['content']==(PARENT/'system.A.txt').read_text(encoding='utf-8')
        write(RUN/'inputs'/f'{cid}.json',{'case_id':cid,'anonymous_id':f'X{number}',
            'messages':messages,'question':item['question'],'source_context_sha256':item['context_sha256']})
        definition=a.read(PARENT/'judge-definitions'/f'{cid}.json');assert definition['answers']==[]
        write(RUN/'judge-definitions'/f'{cid}.json',definition)
    shutil.copyfile(PARENT/'baseline.json',RUN/'baseline.json')
    shutil.copyfile(PARENT/'reused-control.json',RUN/'reused-control.json')
    paths=[SELF,PROTOCOL,PUBLIC/'test_large_model_reference_v1.py',PUBLIC/'answer_rubric.v1.json',
        PUBLIC/'answer_revision_judge.v1.md',PUBLIC/'answer_revision_schema.v1.json']
    paths+=list((RUN/'inputs').glob('*.json'))+list((RUN/'judge-definitions').glob('*.json'))
    paths += [RUN/'baseline.json',RUN/'reused-control.json']
    write(RUN/'freeze.json',{'at':a.now(),'authorization':'owner: ok kjør det; Sol High reference, Medium judge',
        'preflight':pre,'generation_effort':'high','judge_effort':'medium','cases':CASES,
        'maximum_generation_calls':8,'maximum_judge_calls':8,'timeout_seconds':1200,
        'protected':protected,'hashes':{str(p.relative_to(ROOT)):sha(p) for p in paths},
        'no_paid_api':True,'no_reset_credits':True,'generator_has_rubric':False,
        'limitations':['CLI wrapper/High versus local template/thinking off','no seed or512-token cap exposed',
            'one-answer judge grouping','same model generator and judge; source review not independent clinical gold']})
    preservation();print('Eight source-identical inputs frozen; no inference yet.',flush=True)


def generate_one(cid,pre):
    inp=a.read(RUN/'inputs'/f'{cid}.json');out=RUN/'responses'/cid
    if (out/'seal.json').exists():g.verify_seal(out);return a.read(out/'record.json')
    assert not (out/'intent.json').exists(),'Prior dispatch retained; review before any retry'
    assert a.psutil.virtual_memory().available>=256*1024**2
    wire=inp['messages'][1]['content'].encode('utf-8')
    write(out/'intent.json',{'at':a.now(),'model':a.MODEL,'reasoning_effort':'high',
        'input_sha256':a.canonical(inp),'stdin_sha256':hashlib.sha256(wire).hexdigest(),
        'system_sha256':hashlib.sha256(inp['messages'][0]['content'].encode()).hexdigest(),
        'cli_sha256':pre['cli_sha256'],'timeout_seconds':1200})
    (out/'stdin.txt').write_bytes(wire)
    (out/'instructions.md').write_bytes(inp['messages'][0]['content'].encode('utf-8'))
    temp_root=RUN/'temp';temp_root.mkdir(exist_ok=True)
    started=time.monotonic();samples=[];error=None
    with tempfile.TemporaryDirectory(prefix='reference-',dir=temp_root) as tmp:
        temp=Path(tmp);assert temp.resolve().is_relative_to(temp_root.resolve())
        shutil.copyfile(out/'instructions.md',temp/'instructions.md')
        command=generation_command(pre,temp);write(out/'command.json',{'argv':command})
        with (out/'stdout.jsonl').open('xb') as stdout,(out/'stderr.txt').open('xb') as stderr:
            proc=subprocess.Popen(command,cwd=temp,env=a.legacy.codex_environment(),stdin=subprocess.PIPE,stdout=stdout,stderr=stderr)
            proc.stdin.write(wire);proc.stdin.close()
            while proc.poll() is None:
                try:
                    process=a.psutil.Process(proc.pid);tree=[process]+process.children(recursive=True)
                    rss=sum(p.memory_info().rss for p in tree if p.is_running());available=a.psutil.virtual_memory().available
                    samples.append((rss,available))
                    if rss>4*1024**3 or available<256*1024**2:error='memory guard'
                    if time.monotonic()-started>1200:error='timeout'
                    if error:
                        for child in reversed(tree):
                            try:child.kill()
                            except a.psutil.Error:pass
                        break
                except a.psutil.Error:pass
                time.sleep(.1)
            rc=proc.wait()
    record=parse_generation(out/'stdout.jsonl',rc,error)
    record.update(finished_at=a.now(),requested=a.read(out/'intent.json'),server_model_revision=None,
        resources={'elapsed_seconds':time.monotonic()-started,'peak_rss':max((r for r,v in samples),default=None),
            'minimum_available_ram':min((v for r,v in samples),default=None)},
        final_words=len((record['answer'] or '').split()),final_utf8_bytes=len((record['answer'] or '').encode()))
    write(out/'record.json',record)
    if record['success']:
        (out/'answer.txt').write_bytes(record['answer'].encode('utf-8'))
        g.g.seal(out,[p for p in out.iterdir() if p.is_file()])
    return record


def generate():
    frozen=preservation()
    with a.runtime.JudgeLock():
        for cid in CASES:
            result=generate_one(cid,frozen['preflight'])
            print(json.dumps({'generated':cid,'success':result['success'],'words':result['final_words'],'usage':result['usage']}),flush=True)
            if not result['success']:raise RuntimeError('Generation stopped: '+cid+' '+str(result['errors']))
    write(RUN/'generation-complete.json',{'at':a.now(),'answers':8,'automatic_retries':0})


def prepare_judges():
    preservation();assert (RUN/'generation-complete.json').exists()
    assert not (RUN/'judge-freeze.json').exists()
    for cid in CASES:
        folder=RUN/'responses'/cid;g.verify_seal(folder)
        inp=a.read(RUN/'judge-definitions'/f'{cid}.json')
        item=a.read(RUN/'inputs'/f'{cid}.json')
        inp['answers']=[{'answer_id':item['anonymous_id'],'text':(folder/'answer.txt').read_text(encoding='utf-8')}]
        write(RUN/'judge-inputs'/f'{cid}.json',inp)
    paths=list((RUN/'responses').rglob('*'))+list((RUN/'judge-inputs').glob('*.json'))
    write(RUN/'judge-freeze.json',{'at':a.now(),'model':a.MODEL,'reasoning_effort':'medium',
        'hashes':{str(p.relative_to(ROOT)):sha(p) for p in paths if p.is_file()}})
    print('Eight anonymous judge inputs frozen after all generation.',flush=True)


def judge():
    frozen=preservation()
    for name,value in a.read(RUN/'judge-freeze.json')['hashes'].items():assert sha(ROOT/name)==value,name
    g.RUN=RUN
    with a.runtime.JudgeLock():
        for cid in CASES:
            record=g.judge_one(cid,frozen['preflight'])
            print(json.dumps({'judged':cid,'success':record['success'],'errors':record['errors'],'usage':record['usage']}),flush=True)
            if not record['success']:raise RuntimeError('Judge stopped: '+cid)
    write(RUN/'judging-complete.json',{'at':a.now(),'new_judge_calls':8})


def main():
    action=sys.argv[1]
    if action=='prepare':prepare();return
    if action=='check':preservation();print('Frozen inputs and parent artifacts verified.');return
    assert not (RUN/'stop.json').exists(),'Retained stop requires separate review'
    try:
        {'generate':generate,'prepare-judges':prepare_judges,'judge':judge}[action]()
    except BaseException as exc:
        if not (RUN/'stop.json').exists():write(RUN/'stop.json',{'at':a.now(),'action':action,'error':str(exc),'automatic_retries':0})
        raise


if __name__=='__main__':main()
