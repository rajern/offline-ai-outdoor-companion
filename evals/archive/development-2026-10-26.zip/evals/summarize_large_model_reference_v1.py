"""Offline score recomputation and audit; emits no source text or product advice."""
from collections import Counter
import json
import statistics
import sys
import run_large_model_reference_v1 as r
from summarize_generation_improvement_v1 import coverage

a=r.a
ROOT,PUBLIC,RUN=r.ROOT,r.PUBLIC,r.RUN


def main():
    frozen=r.preservation()
    assert a.read(RUN/'generation-complete.json')['answers']==8
    assert a.read(RUN/'judging-complete.json')['new_judge_calls']==8
    for name,value in a.read(RUN/'judge-freeze.json')['hashes'].items():assert r.sha(ROOT/name)==value,name
    rubric={x['id']:x for x in a.read(PUBLIC/'answer_rubric.v1.json')['cases']}
    retrieval={x['case_id']:x for x in a.read(PUBLIC/'retrieval_rubric_rescore_results.v1.json')['rows']}
    rows=[];usage={'generation':Counter(),'judge':Counter()};resources={'generation':[],'judge':[]}
    full=Counter();flags=Counter();gaps=Counter();conditional=Counter()
    for cid in r.CASES:
        folder=RUN/'responses'/cid;r.g.verify_seal(folder)
        inp=a.read(RUN/'inputs'/f'{cid}.json');record=a.read(folder/'record.json')
        assert record['success']
        assert (folder/'instructions.md').read_bytes()==inp['messages'][0]['content'].encode('utf-8')
        assert (folder/'stdin.txt').read_bytes()==inp['messages'][1]['content'].encode('utf-8')
        old=a.read(r.PARENT/'definitions'/f'qwen-2b-A-{cid}.json')
        assert inp['messages']==old['messages'] and inp['question']==old['question']
        recomputed=r.parse_generation(folder/'stdout.jsonl',record['returncode'])
        for key,value in recomputed.items():assert value==record[key],(cid,key)
        assert record['requested']['model']==a.MODEL and record['requested']['reasoning_effort']=='high'
        assert record['requested']['cli_sha256']==frozen['preflight']['cli_sha256']
        assert (folder/'answer.txt').read_text(encoding='utf-8')==record['answer']
        command=a.read(folder/'command.json')['argv']
        assert 'model_reasoning_effort="high"' in command and '--output-schema' not in command
        assert 'read-only' in command and 'web_search="disabled"' in command
        judge_folder=RUN/'judges'/cid;j=a.read(judge_folder/'record.json')
        judge_inp=a.read(RUN/'judge-inputs'/f'{cid}.json')
        assert j['success'] and not a.validate(j['returned_decisions'],judge_inp)
        expected=a.read(RUN/'judge-definitions'/f'{cid}.json')
        assert {k:v for k,v in judge_inp.items() if k!='answers'}=={k:v for k,v in expected.items() if k!='answers'}
        assert judge_inp['answers']==[{'answer_id':inp['anonymous_id'],'text':record['answer']}]
        assert (judge_folder/'stdin.json').read_bytes()==json.dumps(judge_inp,ensure_ascii=False).encode('utf-8')
        assert j['requested']['model']==a.MODEL and j['requested']['reasoning_effort']=='medium'
        assert j['raw_sha256']==r.sha(judge_folder/'stdout.jsonl')
        events,malformed,tokens=a.runtime.events_and_usage(judge_folder/'stdout.jsonl')
        assert not malformed and tokens==j['usage']
        assert not [e for e in events if e.get('item',{}).get('type') not in {None,'agent_message','reasoning','error'}]
        messages=[e['item']['text'] for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message']
        assert json.loads(messages[-1])==j['returned_decisions']
        assert len(j['returned_decisions']['answers'])==1
        answer=j['returned_decisions']['answers'][0]
        required=[x['id'] for x in rubric[cid]['criteria'] if x['classification']=='required']
        available=[key for key,value in retrieval[cid]['required'].items() if value=='full']
        item=coverage(required,answer,available)
        row={'case_id':cid,**item,'decisions':[{k:x[k] for k in ['id','decision','support']} for x in answer['revised']],
            'conditional':[{k:x[k] for k in ['id','decision','support']} for x in answer['revised']
                if next(z['classification'] for z in rubric[cid]['criteria'] if z['id']==x['id'])=='conditional'],
            'finding_types':sorted(set(x['type'] for x in answer['findings'])),
            'gap_behavior':answer['gap_behavior'],'final_words':record['final_words'],'final_utf8_bytes':record['final_utf8_bytes'],
            'response_sha256':r.sha(folder/'record.json'),'judge_record_sha256':r.sha(judge_folder/'record.json')}
        rows.append(row);full.update(item['core_counts']);flags.update(row['finding_types'])
        if row['gap_behavior']!='not_gap':gaps.update([row['gap_behavior']])
        conditional.update(x['decision'] for x in row['conditional'])
        usage['generation'].update(record['usage']);usage['judge'].update(j['usage'])
        resources['generation'].append(record['resources']);resources['judge'].append(a.read(judge_folder/'resources.json'))
    group={'answers':8,'supported_cases':6,'core_denominator':sum(x['core_denominator'] for x in rows),
        'core_counts':dict(full),'available':sum(len(x['available_ids']) for x in rows),
        'retained':sum(len(x['retained_ids']) for x in rows),'fully_supported_full':sum(len(x['fully_supported_full_ids']) for x in rows),
        'core_complete_cases':sum(x['core_complete'] for x in rows),'answers_with_finding':dict(flags),
        'gap_behavior':dict(gaps),'conditional':dict(conditional),'final_words':sum(x['final_words'] for x in rows),
        'median_final_words':statistics.median(x['final_words'] for x in rows)}
    assert group['core_denominator']==15 and group['available']==13
    prior=a.read(PUBLIC/'local_generation_improvement_results.v1.json')
    differences={}
    for model in r.g.MODELS:
        gains=[];losses=[]
        for row in rows:
            old=next(x for x in prior['rows'] if x['model']==model and x['arm']=='baseline' and x['case_id']==row['case_id'])
            gains+=sorted(set(row['full_ids'])-set(old['full_ids']))
            losses+=sorted(set(old['full_ids'])-set(row['full_ids']))
        differences[model]={'gained_full_ids':gains,'lost_full_ids':losses}
    for kind,samples in resources.items():
        for item in samples:
            assert item['peak_rss']<=4*1024**3 and item['minimum_available_ram']>=256*1024**2
            assert item['elapsed_seconds']<=1200
    assert len(list((RUN/'responses').glob('*/intent.json')))==8
    assert len(list((RUN/'judges').glob('*/intent.json')))==8 and not (RUN/'stop.json').exists()
    result={'version':1,'at':a.now(),'complete':True,'model':a.MODEL,'generation_effort':'high','judge_effort':'medium',
        'gpt_group':group,'previous_groups':prior['groups'],'differences_from_local_baselines':differences,'rows':rows,
        'usage':{k:dict(v) for k,v in usage.items()},'resources':resources,
        'rubric_sha256':r.sha(PUBLIC/'answer_rubric.v1.json'),'limitations':frozen['limitations'],
        'new_generation_calls':8,'new_judge_calls':8,'paid_api_calls':0,'reset_credits_used':0}
    if '--check' in sys.argv:
        existing=a.read(PUBLIC/'large_model_reference_results.v1.json')
        assert {k:v for k,v in existing.items() if k!='at'}=={k:v for k,v in result.items() if k!='at'}
        if (RUN/'closeout.json').exists():
            for name,value in a.read(RUN/'closeout.json')['hashes'].items():assert r.sha(ROOT/name)==value,name
        print('Reference results independently recomputed; all frozen/raw bindings verified.');return
    write=a.write
    write(PUBLIC/'large_model_reference_results.v1.json',result)
    audit={'at':a.now(),'passed':True,'parent_protected_files':len(frozen['protected']),
        'same_eight_system_user_messages':True,'generator_input_rubric_free':True,
        'generation_raw_reparsed':8,'judge_raw_reparsed':8,'judged_answer_text_matches':8,
        'all_tool_free_and_resources_pass':True,'new_generation_calls':8,'new_judge_calls':8,
        'freeze_sha256':r.sha(RUN/'freeze.json'),'judge_freeze_sha256':r.sha(RUN/'judge-freeze.json'),
        'independent_clinical_review':False,'limitation':'Client guards do not measure remote model memory; hidden wrapper/model revision not independently exposed.'}
    write(PUBLIC/'large_model_reference_audit.v1.json',audit)
    print(json.dumps({'group':group,'differences':differences,'usage':result['usage']},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
