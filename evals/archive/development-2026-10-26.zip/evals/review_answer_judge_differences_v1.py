"""Prepare an effort-blinded review packet; never calls a model or edits scores."""
import json
from pathlib import Path
import random

import answer_rubric_revision_v1 as r

RUN=r.RUN/'transport-v3'


def prepare_review():
    if not all((RUN/f'{e}-complete.json').exists() for e in ('medium','high')):
        raise RuntimeError('Both full runs must finish before paired review')
    rb=r.read(r.PUBLIC/'answer_rubric.v1.json')
    cases={c['id']:c for c in rb['cases']}
    groups=r.read(RUN/'freeze.json')['groups']
    rng=random.Random(20261024)
    packets=[];key=[];counter=0;agreement_checks=[]
    for group in groups:
        inp=r.read(RUN/'inputs'/f'{group}.json')
        medium=r.read(RUN/'results/medium'/group/'record.json')['returned_decisions']['answers']
        high=r.read(RUN/'results/high'/group/'record.json')['returned_decisions']['answers']
        hi={a['answer_id']:a for a in high}
        texts={a['answer_id']:a['text'] for a in inp['answers']}
        cid=group.removeprefix('diagnostic-');case=cases[cid]
        for m in medium:
            h=hi[m['answer_id']]
            for version in ('historical','revised'):
                hh={x['id']:x for x in h[version]}
                for mm in m[version]:
                    item=mm['id'];hv=hh[item]
                    differing=mm['decision']!=hv['decision'] or (version=='revised' and mm['support']!=hv['support'])
                    if not differing:
                        if cid in {'case-08','case-17','case-21'} and version=='revised':
                            agreement_checks.append({'group':group,'answer_id':m['answer_id'],'criterion_id':item,
                             'decision':mm['decision'],'medium':mm,'high':hv})
                        continue
                    counter+=1;review_id=f'D{counter:03}'
                    first,second=(('medium',mm),('high',hv)) if rng.getrandbits(1) else (('high',hv),('medium',mm))
                    criterion=next(x for x in inp[version+'_criteria'] if x['id']==item)
                    packets.append({'review_id':review_id,'group':group,'answer_id':m['answer_id'],'rubric':version,
                       'question':inp['question'],'criterion':criterion,'answer':texts[m['answer_id']],
                       'X':first[1],'Y':second[1],'blocks':inp['blocks']})
                    key.append({'review_id':review_id,'X':first[0],'Y':second[0]})
            mf=sorted((x['type'],x['reason']) for x in m['findings'])
            hf=sorted((x['type'],x['reason']) for x in h['findings'])
            # Store all finding pairs for qualitative review, not an arbitrary
            # difference count based on inevitably different free-text reasons.
            agreement_checks.append({'group':group,'answer_id':m['answer_id'],'finding_comparison':True,
              'medium':m['findings'],'high':h['findings'],
              'gap_medium':m['gap_behavior'],'gap_high':h['gap_behavior']})
    r.write(RUN/'blind-review-packet.json',packets)
    r.write(RUN/'blind-review-key.json',key)
    r.write(RUN/'agreement-and-finding-review.json',agreement_checks)
    print(json.dumps({'disagreement_items':len(packets),'agreement_and_finding_checks':len(agreement_checks)}))


if __name__=='__main__':prepare_review()
