# Local loopback transport repair

2026-10-25: revision-02 used the correct pinned runtime. Its server log confirms
model loaded and listening in 1.61 seconds, but the sandbox denied the Python
client connection to 127.0.0.1 with WinError10013. The inherited readiness loop
then reached its unchanged 120-second deadline. This is an access failure, not
a slow model load or memory-limit failure. No native-input or completion
requests succeeded; zero product responses exist to recover or repeat.

Preserve revision-02 completely. revision-03 copies only its prepared definitions
and snapshots. Run the same startup adapter and frozen implementation with host
execution permission so the local client can reach its own numeric-loopback
server. External Python sockets remain denied; no download or cloud generation
is introduced. All source, native-template, inference, memory and timing rules
remain unchanged. Host execution was also the previously documented transport
for the ChatGPT-subscription judge, whose child remains read-only and tool-free.

The new wrapper binds this note, its own code and all revision-02 artifacts before
dispatch. It delegates the corrected close-before-unlink lock ownership checks.
This adapter authorizes no retry after a future resource or dispatched-response
failure. No model response was dispatched in either failed startup attempt.
