"""Read-only private worksheet; never invokes a model or changes a decision."""
import json
import sys
import generation_improvement_host_transport_v1 as h

s=h.s


def main():
    cid=sys.argv[1];assert cid in s.CASES
    inp=s.a.read(h.RUN/'judge-inputs'/f'{cid}.json')
    print('QUESTION',inp['question'])
    print('CRITERIA',json.dumps(inp['revised_criteria'],ensure_ascii=False))
    for block in inp['blocks']:print('BLOCK',block['block'],block['text'])
    specs={x['anonymous_id']:x for x in [s.a.read(p) for p in (h.RUN/'definitions').glob('*.json')]}
    path=h.RUN/'judges'/cid/'record.json'
    records=s.a.read(path)['returned_decisions']['answers'] if path.exists() and s.a.read(path)['success'] else []
    for answer in inp['answers']:
        spec=specs[answer['answer_id']]
        print('\nANSWER',spec['model'],spec['arm'],answer['answer_id'],answer['text'])
        record=next((x for x in records if x['answer_id']==answer['answer_id']),None)
        if record:
            print('DECISIONS',json.dumps([{k:x[k] for k in ['id','decision','support','reason']} for x in record['revised']],ensure_ascii=False))
            print('FINDINGS',json.dumps(record['findings'],ensure_ascii=False))
            print('GAP',record['gap_behavior'])


if __name__=='__main__':main()
