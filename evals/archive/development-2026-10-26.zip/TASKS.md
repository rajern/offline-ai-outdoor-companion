# Outwise — Tasks

This file contains the active implementation tasks.

Only near-term work should live here.  
Completed work may be archived or removed as the project progresses.

---

# Milestone 1 — Foundation + Local AI

## M1-01 — Scaffold frontend

**Dependencies:** None

Create the Expo + React Native + TypeScript frontend with web support.

Requirements:
- project runs locally on Windows
- mobile-first layout
- basic placeholder chat screen
- no AI logic in the frontend

**Done when:**
- frontend starts successfully
- app renders in the browser
- layout works at phone-sized width

---

## M1-02 — Scaffold backend

**Dependencies:** None

Create the Python + FastAPI backend.

Requirements:
- simple health endpoint
- basic project structure following `ARCHITECTURE.md`
- no model integration yet

**Done when:**
- backend starts locally
- health endpoint responds successfully

---

## M1-03 — Connect frontend and backend

**Dependencies:** M1-01, M1-02

Create the minimal API boundary between the frontend and backend.

Requirements:
- frontend can send a message
- backend can return a temporary/mock response
- loading and basic error states work

**Done when:**
- a message entered in the UI reaches FastAPI
- the returned response appears in the chat

---

## M1-04 — Local model setup

**Dependencies:** None

Set up local inference with:

- Qwen3.5-2B
- Q4_K_M
- GGUF
- llama.cpp

Create the minimum scripts/instructions required to obtain and run the model locally.

Do not commit the model file to Git.

**Done when:**
- the model can be downloaded/setup reproducibly
- a local prompt produces a valid response without internet access

---

## M1-05 — Implement ModelService

**Dependencies:** M1-04

Connect the backend to the local model through a dedicated model service.

Requirements:
- llama.cpp-specific logic remains behind the model service
- backend can submit a prompt and receive generated text
- useful model/loading errors are surfaced

**Done when:**
- FastAPI can obtain a real response from the local Qwen model

---

## M1-06 — Complete local AI vertical slice

**Dependencies:** M1-03, M1-05

Replace the mock response with real local inference.

Flow:

    User
      ↓
    Mobile-first UI
      ↓
    FastAPI
      ↓
    ModelService
      ↓
    Local Qwen model
      ↓
    Response in UI

**Done when:**
- user can chat with the local model through the frontend
- the full flow works with internet disabled after setup
- no cloud AI/API is used
- major setup and runtime errors are handled clearly


# Milestone 2 — RAG + Real Knowledge Base

## M2-01 — Define knowledge fixtures and data contract

**Dependencies:** M1-06

Create a small development knowledge set using synthetic or clearly reusable fixture content.

Requirements:
- follow the common structure defined in `docs/DATA.md`
- include source metadata with every item
- cover several MVP knowledge areas
- keep fixture data intentionally small

**Done when:**
- fixture knowledge can be loaded reproducibly
- every item contains the required source metadata
- no unverified external copyrighted content is committed

---

## M2-02 — Implement local retrieval

**Dependencies:** M2-01

Implement the local retrieval layer.

Requirements:
- retrieve relevant knowledge chunks from the local knowledge store
- keep retrieval logic separate from the model service
- return both retrieved text and source metadata
- remain fully local and offline

**Done when:**
- a query returns relevant fixture chunks
- source identity is preserved
- retrieval can be called independently from the LLM

---

## M2-03 — Integrate RAG into the request flow

**Dependencies:** M2-02, M1-06

Connect retrieval to the orchestrator and local model.

Expected flow:

    User
      ↓
    Orchestrator
      ↓
    Retrieval
      ↓
    Relevant chunks + source metadata
      ↓
    Local Qwen model
      ↓
    Natural answer + sources

Requirements:
- the model receives only the relevant retrieved context
- the model may combine several retrieved chunks into one natural response
- displayed sources must come from stored metadata, not generated URLs or citations

**Done when:**
- the user can ask a question through the UI
- relevant local knowledge is retrieved
- Qwen uses the retrieved context
- the UI displays the supporting sources
- the full flow works offline

---

## M2-04 — Approve real knowledge sources

**Status:** Complete — owner approved the 22-URL source manifest on 2026-10-06.

**Dependencies:** M2-03

**Human approval checkpoint**

The final knowledge sources must be researched, reviewed and approved by the project owner before ingestion work begins.

Do not autonomously select or approve the final source set.

The approved source documentation should record:
- source and URL
- intended knowledge coverage
- authority/reliability
- licence and redistribution rights
- attribution requirements
- language
- ingestion method

Codex must not begin M2-05 until the project owner has explicitly approved and documented the final source set.

Prefer:
- downloadable datasets
- structured APIs
- manuals or document collections
- sources that can be ingested automatically

Avoid large manual copy/paste or article-by-article scraping workflows.

**Done when:**
- the final source set for the MVP is documented
- licence/usage status is recorded for every selected source
- required attribution is known
- the selected sources cover the intended MVP knowledge areas sufficiently
- the project owner has explicitly approved the documented source set

---

## M2-05 — Build ingestion for approved sources

**Status:** Complete — frozen ingestion, local embedding assets and offline rebuild verified on 2026-10-06.

**Dependencies:** M2-04

Create reproducible ingestion pipelines for the approved real sources.

Requirements:
- convert each source into the common Outwise data contract
- preserve provenance and licence metadata
- automate parsing, normalization and chunking
- generate the required local retrieval assets
- keep source-specific logic outside the retrieval layer

**Done when:**
- the real knowledge base can be rebuilt from approved sources without manual copy/paste
- the output follows the Outwise data contract
- provenance is preserved throughout the pipeline

---

## M2-06 — Replace fixtures with the real knowledge base

**Dependencies:** M2-05

**Status:** In progress — retrieval optimization is paused by owner decision
(2026-10-11). The original 31 configurations / 775 case judgments are complete;
see `evals/retrieval_optimization_report.v7.md`. The targeted round evaluated
T-ranking and T-packing; T-combined has saved contexts but is **not judged**.
See `evals/retrieval_targeted_report.v1.md`. Historical execution statuses are
preserved in `docs/M2-06_HISTORY_2026-10-11.md`.

Frozen provisional system-test candidate: MiniLM, full-body window T-ranking,
k16, no threshold, original P3, complete grounded prompt <=2,000 locked tokens.
Retrieval coverage: 60/72 (83.33%), macro 81.14%, 15/22 supported cases complete.
This is a development baseline, not an approved production configuration.
Case 16 remains `requires_review` under V3; isolated Qwen testing may proceed,
but this ambiguity must be resolved or explicitly handled before quality approval.

M2-06 system-test status, 2026-10-11: one unchanged 25-question Qwen baseline
and three separate sufficient-context diagnostics are complete. All 28 model calls
passed the original resource guards. Exact live candidate inputs and API source
metadata match all 25 saved contexts. Existing 68 backend tests and 13 Qwen-related
tests pass. See `evals/qwen_rag_system_report.v1.md`, results/audit v1 and the
separate answer-review file. No production replacement or T-combined judging.

Owner-authorized next task: one bounded local model/generation comparison.
The old answer review fully reproduces 15 of the 60 retrieval-covered requirements;
the other 45 are partial or absent. Principal failures are scenario mixing,
changed conditions/order and missing safe abstention. No historical score changed.
Generation-only input budget is now 3,200 native-template tokens, runtime context
4,096 and output reservation 512; saved retrieval contexts/order stay unchanged.
All 25 originals, three sufficient-context inputs, four paraphrases and four
repeats were bound before inference. Critical supported-source errors override
the 54/60 development target; Windows performance is not mobile validation.

Comparison stopped in preflight, 2026-10-11: available host RAM fell to 140.72 MiB
while loading existing 2B plus MiniLM, below the unchanged 256 MiB reserve.
Process-tree RSS peaked at 748.72 MiB, below 4 GiB. No new response or paid API
call occurred; larger model downloads, native-token budget checks and inference
remain pending. See `evals/local_generation_comparison_report.v1.md` and audit.
Preserve both pre-inference technical history and the memory stop. Free host RAM
before an explicitly resumed preflight; do not remove the failed record or retry
automatically. M2-06 is still open, production and M3 unchanged.

Owner resume, 2026-10-24: the saved 36 inputs and historical identities verify.
Qwen 2B now passes all 36 native-template/token checks (777–2,233 input tokens,
512 reserved output, actual slot 4,096; GGUF context metadata 262,144).
Resident MiniLM + 2B peak RSS 2,570.20 MiB / available RAM minimum 1,087.68 MiB.
The approved 4B Q4_K_M was downloaded at a pinned revision and SHA-256 verified.
Its loading then breached the unchanged host reserve: 148.07 MiB available,
3,898.40 MiB peak RSS (still below 4 GiB). No new answer was generated.
Gemma download and all new generation/quality comparisons remain pending;
the 2B pass is not evidence that 4B cannot fit on a less occupied host.
See `evals/local_generation_comparison_report.v2.md` and preflight/audit v2.
Retain the new resource stop and successful 2B checks for the next explicit
resume. More host RAM must be freed; do not raise limits or auto-retry.

Second explicit retry, 2026-10-24 ("prøv igjen"): reused sealed 2B input checks
and the verified 4B file in a separate retry directory. 4B loading again hit the
host reserve: 158.79 MiB available (<256 MiB), 749.08 MiB sampled process-tree
RSS (<4 GiB). This attempt stopped earlier in loading, so RSS is not a model
footprint measurement. Server terminated; zero generated responses. See
`evals/local_generation_comparison_retry.v1.md` and JSON audit. Original attempts
remain unchanged. No automatic retry, model substitution or production change.

Further explicit retry, 2026-10-24 ("prøv nå"): with host reserve intact,
4B + MiniLM exceeded 4 GiB process-group RSS. The already-frozen protocol permits
excluding a candidate proven incompatible with this limit. 4B is excluded for
this fixed CPU/configuration test, without changing limits or model variant.
Gemma official QAT Q4_0 download/hash and all 36 native-token checks now pass.
2B and Gemma proceed to the preplanned screening (at most 22 responses); no
retrieval/gold/prompt change. See local_generation_comparison_execution.v1.md.

Bounded generation comparison COMPLETE, 2026-10-24: 22 new local responses,
11 each from 2B/Gemma; 4B excluded only after >4 GiB RSS with host reserve intact.
All executed generation guards pass. Same-screen8/19 requirements: old 2B 2/19,
new 2B 4/19, Gemma 6/19. Gemma safely abstains in both tested gaps; 2B in neither.
Both omit supported critical airway/breathing assessment in primary case08,
so neither passes the frozen finalist gate. No finalist or further tuning run.
Full25 remains historical 15/72; these eight-case scores cannot replace it.
See `evals/local_generation_comparison_report.v3.md`, results v1 and final audit.
Actual usage 41,704 input /4,400 output tokens, no paid API/Codex judge calls;
first raw response reused after metadata-only n_ctx check repair, no repeat.
Recommendation for OWNER REVIEW: restrict generation, use source-preserved
critical procedures, consider Gemma only for bounded summaries/abstention.
No final model/source-first safety policy or production integration approved.
Remaining M2-06 work: owner chooses bounded prototype scope, then separately
authorized integration/startup and UI/offline/quality review before M3.

Retrospective evaluation review, 2026-10-24: owner authorized all-25 rubric review
and paired Sol Medium then High on the 50 already-saved answers, without a separate
rubric review checkpoint. New answer rubric/decision ledger are frozen, old gold
and scores preserved. The owner-authorized 21:15 one-shot continuation is COMPLETE:
50/50 answers at each effort, all 18 criterion/support disagreements and 50 finding
pairs reviewed. Nine successful calls were reused; 49 new calls used the separately
documented 1,200s timeout. The old 420s timeout/raw logs and unknown usage remain.
Both controls and final integrity/recomputation checks pass. No reset or paid API;
one-shot automation deleted. See `evals/answer_revision_report.v2.md`, results v3,
analysis/review v1 and audit v2. Raw full25 old12/72 Medium,11/72 High; new13/63,
12/63, zero core-complete questions. Revised screen8 core favors Qwen8/15 over
Gemma6/15, but Qwen has more unsupported additions; coverage is not overall quality.
Diagnostics reach7/8 new core for each new model on three selected questions.
Rubric/judge review is complete; M2-06 quality remains unapproved. No new product
answer generation, retrieval, production integration or M3 is authorized by this work.

Owner-authorized steps1/2 COMPLETE, 2026-10-25: unchanged revised rubric/63 core
and Sol Medium locked; three authored controls pass,25 saved primary contexts
re-assessed. Retrieval55/63 (87.3%), four partial/four absent,16/22 core-complete;
conditional availability3/4. Historical Qwen full25 preserves13/55 (23.6%).
Matched screening available13/15: old Qwen preserves4/13, new Qwen8/13, Gemma6/13;
coverage is not overall quality. All69 main items and25 finding lists reviewed.
28 successful sequential calls,250614 known tokens; no retries, reset or paid API.
See `evals/evaluation_lock.v1.md` and `retrieval_rubric_rescore_report.v1.md`,
results/review/audit v1. A separately bound offline adapter fixes only normalization
of the already-allowed progress paths; original data/code/raw scores preserved.
No search, product generation, GPT answer comparison, holdout, production or M3.
This finishes the measurement task; M2-06 quality and later steps remain open.

Owner-authorized generation improvement COMPLETE, 2026-10-25:32 new screen8
answers, existing Qwen2B/Gemma, sampler-only A and prompt-only B; eight successful
sequential Sol Medium calls/100458 reported tokens. Latest16 baseline judgments
and locked rubric reused. Qwen baseline8/15 -> A2/15, B3/15; Gemma6/15 in all
three, gap abstention2/2 -> A2/2, B0/2. No clear overall improvement; no production
winner. All32 source-reviewed with raw decisions intact; five tests/final audit
pass,745 protected files unchanged, original input/settings/resource guards pass.
Two zero-dispatch startup stops and separately frozen transport adapters retained.
Current run: local-generation-improvement-v1-2026-10-25/revision-03. See improvement
report/results/review/audit v1. No paid API/reset, new retrieval, GPT answers,
holdout, production/safety-policy change or M3. Stop for owner next-step decision;
no automatic A+B or further parameter search. M2-06 quality remains unapproved.

Owner-authorized large-model reference STOPPED, 2026-10-25:4/8 sealed High answers
(19,05,08,17), fifth CLI attempt21 HTTP429/no final text or usage. Own waiting
CLI retry cancelled;23/15/25 and all Medium judges not started. No overall score.
Account ordinary use remains allowed,12% five-hour/18% weekly used; exhausted
subscription NOT proven. Preserve five attempts, reuse four successes unchanged;
separate documented continuation required for failed21/original8-call limit.
Four tests/offline partial checks pass,1270 parent files preserved. Known tokens
28842, failed usage unknown. See large_model_reference_report.v1.md/partial results
and protocol; private large-model-reference-v1-2026-10-25. No paid API/reset,
retrieval, holdout, production/safety-policy change or M3. M2-06 quality remains open.

Owner-authorized reference continuation COMPLETE, 2026-10-25: all8 Sol High answers
and8 locked Medium assessments. GPT13/15 core,13/13 fully delivered retained;
two partial match source gaps08/r4 and21/r2,4/6 core-complete, safe gaps2/2.
No raw unsupported/conflict/critical-omission flag, one source-insufficiency review.
All8 texts/17 revised decisions/finding lists source-reviewed; scores unchanged.
Baseline Qwen8/15/Gemma6/15 reused. Four High successes reused, four new; nine
generation CLI attempts includes original429 of unknown usage. Eight unique
judge CLI attempts; one completed output recovered without inference after a
separately corrected watcher shutdown bug, original false record/raw retained.
Two successful bounded judge429 waits24s/143s; pacing>=60.008s, guards unchanged.
Known usage>=129332 tokens; no paid API/reset. Six test methods/offline checks
pass; prior files/partial report preserved. See large_model_reference_report.v2.md,
results/review/audit/execution v1, private continuation-v2. High/CLI/self-judge and
selected-eight limitations remain. Stop for owner next-step decision: no automatic
tests/integration, retrieval, holdout, production/safety policy or M3. M2-06 open.

Subtasks and acceptance evidence:
- [x] Freeze a separate answer-assessment protocol and run the local ModelService /
  Qwen baseline on the unchanged 25 development cases; three corpus gaps separate.
- [x] Source-review all answers; preserve raw outputs, bind annotations to exact
  contexts, identify retrieval/generation/corpus/constraint failures, and complete
  the three bounded diagnostics without prompt/model tuning.
- [x] Verify isolated candidate API/orchestration/packing/prompt/metadata, document
  unchanged current-app differences and four no-generation integration probes.
- [x] Measure latency, CPU and simultaneous retrieval/Qwen memory; publish sealed
  results and reproducible checks. Python external network is denied; an actual
  OS-disconnected UI review remains below.
- [ ] Resolve generated-answer failures before quality acceptance: critical
  conditions/negations, wrong-scenario advice and reliable insufficiency reporting.
  Current source review finds 0/22 fully covered supported answers; even sufficient
  contexts retain breathing/CPR and anaphylaxis contradictions. No automatic pass.
- [ ] Explicitly handle source/risk review07/16/18 and geography/abstention issues;
  restore normal backend startup and obtain separate approval before permanently
  integrating the candidate. Current app still uses older retrieval defaults.
- [ ] Owner manually reviews representative UI answers/source correctness/gaps,
  performs physical offline testing, and explicitly approves M2-06 quality.

Completion requires all these checks and explicit owner quality approval. Do not
mark M2-06 complete or start M3. No holdout access, new retrieval experiments,
new sources, paid API calls or permanent production configuration changes.

Replace development fixtures in the main RAG flow with the approved Outwise knowledge base.

Requirements:
- keep fixtures available for testing
- use the real knowledge base in the normal application flow
- verify retrieval across the main MVP knowledge areas
- verify that source metadata is shown correctly

**Done when:**
- the application answers using the real local knowledge base
- sources are displayed correctly
- the knowledge base and retrieval flow work with internet disabled
- no unapproved source material is required for the MVP

### Human quality review

After the technical implementation is complete, stop for a manual product review before Milestone 3 begins.

The project owner should test representative real-world questions and review:
- retrieval relevance
- answer quality
- source correctness
- obvious knowledge gaps

Do not begin Milestone 3 until this review has been explicitly approved.

---

# Milestone 3 — Safety + Finished MVP

## M3-01 — Implement the safety layer

**Dependencies:** M2-06

**Human approval checkpoint**

Before implementing the safety layer, define the proposed safety rules and behaviour for the main high-risk situations.

Present the proposed rules to the project owner for review.

Do not implement the final safety behaviour until the project owner has explicitly approved the policy.

Implement the first explicit safety layer outside the LLM itself.

Requirements:
- detect situations that require stronger safety handling
- prioritize emergency or professional help where appropriate
- avoid unsupported high-risk guidance
- surface uncertainty when reliable grounding is missing
- keep safety logic separate from model and retrieval implementations

**Done when:**
- safety handling can be triggered independently of the LLM prompt
- high-risk scenarios receive the intended safety treatment
- unsupported answers are not silently presented as confident guidance

---

## M3-02 — Add safety and legal messaging

**Dependencies:** M3-01

**Human approval checkpoint**

Codex may draft the safety and legal messaging, but the final wording must be reviewed and explicitly approved by the project owner before it is treated as complete or shown as final product copy.

Add clear product messaging about the intended use and limitations of Outwise.

Requirements:
- explain that Outwise is an information and preparedness tool
- clarify that it is not a replacement for emergency services or professional medical help
- make important limitations visible without blocking normal use
- include appropriate source and attribution information where required

**Done when:**
- safety/legal messaging is visible in the relevant parts of the product
- the wording is consistent with `docs/PRODUCT.md` and `docs/DECISIONS.md`
- no feature is presented as providing guaranteed medical or emergency outcomes

---

## M3-03 — Refine the mobile-first product experience

**Dependencies:** M2-06

Turn the technical application into a coherent Outwise experience.

Requirements:
- refine the phone-sized layout
- add the agreed scenario shortcuts
- improve chat, source display, loading and error states
- keep the interface simple and usable under stress
- avoid adding post-MVP features

**Done when:**
- the main user flows are clear without explanation
- the UI works well at phone-sized dimensions
- answers and supporting sources are easy to inspect

---

## M3-04 — Add offline readiness and reliability checks

**Dependencies:** M3-01, M3-03

Make offline operation explicit and testable.

Requirements:
- clearly indicate whether required local assets are available
- fail clearly if model or knowledge assets are missing
- verify that the normal user flow has no hidden internet dependency
- test the application with internet access disabled

**Done when:**
- the application clearly reports its offline-ready state
- the full core flow works with internet disabled
- missing assets produce understandable errors rather than silent failures

---

## M3-05 — Validate core MVP scenarios

**Dependencies:** M3-01, M3-04

Run the completed system through representative scenarios from the MVP scope.

Include examples covering:
- injury / basic first aid
- getting lost
- cold or exposure
- shelter / warmth
- water / hygiene
- emergency signalling
- unsupported or uncertain questions

Focus on:
- retrieval relevance
- grounding
- source correctness
- safety behaviour
- clarity of the final response

**Done when:**
- the main MVP scenarios work end to end
- obvious retrieval or safety failures are fixed
- sources shown to the user match the retrieved source metadata
- known limitations are documented

### Human product review

After automated and technical validation, the project owner should manually test the finished core scenarios and review the product from an end-user perspective.

Any major issues found should be resolved before M3-06 is completed.

---

## M3-06 — Prepare the public MVP

**Dependencies:** M3-05

Prepare Outwise as a complete public learning project.

Requirements:
- clean up setup and run instructions
- update README with the final MVP behaviour
- document model and knowledge setup
- document important limitations
- ensure the public repository contains no prohibited or unlicensed assets
- add a simple demo or screenshots if useful

**Done when:**
- a new developer can understand and run the project from the repository
- the repository accurately reflects the finished MVP
- the MVP is ready to demonstrate publicly
- all three milestones are complete

### Final approval

**Human approval checkpoint**

Codex may prepare the repository and MVP for release, but must not treat the project as finally approved or release-ready until the project owner has completed the final review and explicitly approved it.


---
# Parallelization

The following work can initially run in parallel:

- `M1-01` Frontend
- `M1-02` Backend
- `M1-04` Local model setup

After these are complete:

- `M1-03` depends on frontend + backend
- `M1-05` depends on model setup
- `M1-06` integrates both tracks

Do not begin Milestone 2 tasks until the Milestone 1 vertical slice works end to end.
